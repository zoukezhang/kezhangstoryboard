#!/bin/bash

# 分镜故事板 Docker 停止脚本 v1.0.4
# 作者: 科长分镜故事板
# 日期: 2025-08-29

echo "🛑 分镜故事板 v1.0.4 停止中..."
echo "=================================="

# 停止服务
echo "⏹️  停止Docker服务..."
docker-compose down

if [ $? -eq 0 ]; then
    echo "✅ 服务已停止"
else
    echo "❌ 停止服务时出现错误"
    exit 1
fi

echo ""
echo "📋 服务状态:"
docker-compose ps

echo ""
echo "💡 提示: 如需重新启动，请运行 ./start.sh"
