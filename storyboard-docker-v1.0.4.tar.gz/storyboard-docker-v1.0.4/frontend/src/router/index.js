import { createRouter, createWebHistory } from 'vue-router'
import { useUserStore } from '@/stores/user'

const routes = [
  {
    path: '/',
    redirect: '/projects'
  },
  {
    path: '/login',
    name: 'Login',
    component: () => import('@/views/Login.vue')
  },
  {
    path: '/register',
    name: 'Register', 
    component: () => import('@/views/Register.vue')
  },
  {
    path: '/projects',
    name: 'Projects',
    component: () => import('@/views/Projects.vue'),
    meta: { requiresAuth: true }
  },
  {
    path: '/profile',
    name: 'Profile',
    component: () => import('@/views/Profile.vue'),
    meta: { requiresAuth: true }
  },
  {
    path: '/edit/:projectId',
    name: 'Edit',
    component: () => import('@/views/Edit.vue'),
    meta: { requiresAuth: true }
  },
  {
    path: '/preview/:projectId',
    name: 'Preview',
    component: () => import('@/views/Preview.vue'),
    meta: { requiresAuth: true }
  },
  {
    path: '/share/:token',
    name: 'Share',
    component: () => import('@/views/Share.vue')
    // 注意：分享页面不需要身份验证，任何人都可以访问
  },
  {
    path: '/script-square',
    name: 'ScriptSquare',
    component: () => import('@/views/ScriptSquare.vue'),
    meta: { requiresAuth: true }
  },
  {
    path: '/script-preview/:scriptId',
    name: 'ScriptPreview',
    component: () => import('@/views/ScriptPreview.vue'),
    meta: { 
      title: '脚本预览',
      requiresAuth: false // 脚本预览不需要登录
    }
  },
  {
    path: '/test-router',
    name: 'TestRouter',
    component: () => import('@/views/TestRouter.vue'),
    meta: { requiresAuth: true }
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

// 路由守卫
router.beforeEach((to, from, next) => {
  console.log('路由跳转:', from.path, '->', to.path)
  const userStore = useUserStore()
  
  if (to.meta.requiresAuth && !userStore.isLoggedIn) {
    console.log('需要认证但未登录，跳转到登录页')
    next('/login')
  } else if ((to.name === 'Login' || to.name === 'Register') && userStore.isLoggedIn) {
    console.log('已登录用户访问登录/注册页，跳转到项目页')
    next('/projects')
  } else {
    console.log('正常跳转')
    next()
  }
})

export default router