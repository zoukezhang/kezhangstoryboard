import { defineStore } from 'pinia'
import { ref } from 'vue'
import api from '@/utils/api'

export const useShotStore = defineStore('shot', () => {
  const shots = ref([])
  const currentShot = ref(null)
  const loading = ref(false)

  // 获取分镜列表
  const fetchShots = async (projectId) => {
    loading.value = true
    try {
      const response = await api.get(`/shot/list/${projectId}`)
      const shotsData = response.data.data || []
      
      // 映射后端字段到前端字段
      shots.value = shotsData.map(shot => {
        const mappedShot = { ...shot }
        // 确保前端状态中同时包含下划线命名和驼峰命名的字段
        Object.keys(FIELD_MAPPING).forEach(frontendField => {
          const backendField = FIELD_MAPPING[frontendField]
          if (shot[backendField] !== undefined) {
            mappedShot[frontendField] = shot[backendField]
          }
        })
        return mappedShot
      })
      
      return { success: true }
    } catch (error) {
      console.error('获取分镜列表失败:', error)
      return { 
        success: false, 
        message: error.response?.data?.message || '获取分镜列表失败' 
      }
    } finally {
      loading.value = false
    }
  }

  // 添加分镜
  const addShots = async (projectId, count = 1) => {
    try {
      const response = await api.post('/shot/add', { project_id: projectId, count })
      await fetchShots(projectId) // 重新获取分镜列表
      return { 
        success: true, 
        data: response.data.data,
        message: `成功添加${count}个镜头` 
      }
    } catch (error) {
      console.error('添加分镜失败:', error)
      return { 
        success: false, 
        message: error.response?.data?.message || '添加分镜失败' 
      }
    }
  }

  // 更新分镜
  // 字段验证规则（与后端保持一致）
  const FIELD_VALIDATION_RULES = {
    tag: { maxLength: 100 },
    description: { maxLength: 1000 },
    shot_type: { maxLength: 50 },
    dialogue: { maxLength: 1000 },
    sound_effect: { maxLength: 200 },
    animation: { maxLength: 200 },
    camera_movement: { maxLength: 200 },
    scene: { maxLength: 100 },
    characters: { maxLength: 100 },
    character_state: { maxLength: 100 },
    narration: { maxLength: 1000 },
    shooting_angle: { maxLength: 50 }
  }

  // 前端到后端的字段映射
  const FIELD_MAPPING = {
    tag: 'tag',
    description: 'description',
    shot_type: 'shot_type',
    dialogue: 'dialogue',
    sound_effect: 'sound_effect',
    animation: 'animation',
    camera_movement: 'camera_movement',
    scene: 'scene',
    characters: 'characters',
    character_state: 'character_state',
    narration: 'narration',
    shooting_angle: 'shooting_angle',
    create_time: 'create_time',
    update_time: 'update_time',
    sort_order: 'sort_order',
    image_url: 'image_url'
  }

  // 验证字段值
  const validateFieldValue = (field, value) => {
    const rule = FIELD_VALIDATION_RULES[field]
    if (!rule) return { valid: true }
    
    // 空值检查
    if (value === null || value === undefined || value === '') {
      return { valid: true } // 空值是允许的
    }
    
    // 数字类型检查
    if (rule.type === 'number') {
      const numValue = Number(value)
      if (isNaN(numValue) || numValue < rule.min || numValue > rule.max) {
        return {
          valid: false,
          error: `${field}必须是${rule.min}-${rule.max}之间的数字`
        }
      }
    }
    
    // 长度检查
    if (rule.maxLength && String(value).length > rule.maxLength) {
      return {
        valid: false,
        error: `${field}长度不能超过${rule.maxLength}个字符`
      }
    }
    
    return { valid: true }
  }
  
  // 修改updateShot方法，支持单个字段更新和批量字段更新
  const updateShot = async (shotId, fieldOrData, value) => {
    // 判断是单个字段更新还是批量更新
    if (typeof fieldOrData === 'string' && value !== undefined) {
      // 单个字段更新
      const field = fieldOrData
      console.log(`🔄 shotStore.updateShot: shotId=${shotId}, field=${field}, value=${value} (${typeof value})`)
      
      try {
        // 前端验证
        const validation = validateFieldValue(field, value)
        if (!validation.valid) {
          console.error(`❌ 前端验证失败: ${validation.error}`)
          return { success: false, error: validation.error }
        }
        
        // 字段映射
        const backendField = FIELD_MAPPING[field]
        if (!backendField) {
          console.error(`❌ 字段映射失败: 找不到字段 ${field} 的映射`)
          return { success: false, error: `字段映射失败: ${field}` }
        }
        
        // 处理值：空值转为null，数字字段转换
        let processedValue = value;
        if (value === '' || value === null || value === undefined || 
            (typeof value === 'string' && value.trim() === '')) {
          processedValue = null;
        } else if (typeof value === 'string') {
          processedValue = value.trim();
        }
        
        // 构建请求数据
        const requestData = {
          [backendField]: processedValue
        }
        
        console.log(`📤 发送更新请求:`, requestData)
        
        try {
          const response = await api.put(`/shot/edit/${shotId}`, requestData)
          console.log(`✅ 更新成功:`, response.data)
          
          // 更新本地状态
          const shotIndex = shots.value.findIndex(shot => shot.id === shotId)
          if (shotIndex !== -1) {
            // 更新对应字段
            shots.value[shotIndex][field] = value
            shots.value[shotIndex][backendField] = processedValue
            console.log(`📝 本地状态已更新: ${field} = ${value}`)
          }
          
          return { success: true, data: response.data }
        } catch (error) {
          console.error(`❌ 更新失败:`, error)
          
          // 处理400错误
          if (error.response && error.response.status === 400) {
            const errorMessage = error.response.data?.message || '参数验证失败'
            console.error(`❌ 400错误: ${errorMessage}`)
            return { success: false, error: errorMessage, status: 400 }
          }
          
          // 处理其他错误
          const errorMessage = error.response?.data?.message || error.message || '更新失败'
          return { success: false, error: errorMessage }
        }
      } catch (error) {
        console.error('更新分镜失败:', error)
        return { 
          success: false, 
          message: error.response?.data?.message || '更新分镜失败' 
        }
      }
    } else {
      // 批量字段更新
      const shotData = fieldOrData
      console.log(`🔄 shotStore.updateShot: shotId=${shotId}, 批量更新数据:`, shotData)
      
      try {
        // 构建请求数据，进行字段映射
        const requestData = {}
        for (const [field, value] of Object.entries(shotData)) {
          const backendField = FIELD_MAPPING[field]
          if (backendField) {
            // 处理值：空值转为null，数字字段转换
            let processedValue = value;
            if (value === '' || value === null || value === undefined || 
                (typeof value === 'string' && value.trim() === '')) {
              processedValue = null;
            } else if (typeof value === 'string') {
              processedValue = value.trim();
            }
            requestData[backendField] = processedValue
          }
        }
        
        console.log(`📤 发送批量更新请求:`, requestData)
        
        try {
          const response = await api.put(`/shot/edit/${shotId}`, requestData)
          console.log(`✅ 批量更新成功:`, response.data)
          
          // 更新本地状态
          const shotIndex = shots.value.findIndex(shot => shot.id === shotId)
          if (shotIndex !== -1) {
            // 更新所有字段
            for (const [field, value] of Object.entries(shotData)) {
              const backendField = FIELD_MAPPING[field]
              if (backendField) {
                shots.value[shotIndex][field] = value
                shots.value[shotIndex][backendField] = requestData[backendField]
                console.log(`📝 本地状态已更新: ${field} = ${value}`)
              }
            }
          }
          
          return { success: true, data: response.data }
        } catch (error) {
          console.error(`❌ 批量更新失败:`, error)
          
          // 处理400错误
          if (error.response && error.response.status === 400) {
            const errorMessage = error.response.data?.message || '参数验证失败'
            console.error(`❌ 400错误: ${errorMessage}`)
            return { success: false, error: errorMessage, status: 400 }
          }
          
          // 处理其他错误
          const errorMessage = error.response?.data?.message || error.message || '更新失败'
          return { success: false, error: errorMessage }
        }
      } catch (error) {
        console.error('批量更新分镜失败:', error)
        return { 
          success: false, 
          message: error.response?.data?.message || '批量更新分镜失败' 
        }
      }
    }
  }

  // 删除分镜
  const deleteShot = async (shotId, projectId) => {
    try {
      await api.delete(`/shot/delete/${shotId}`)
      await fetchShots(projectId) // 重新获取分镜列表
      return { success: true, message: '分镜删除成功' }
    } catch (error) {
      console.error('删除分镜失败:', error)
      return { 
        success: false, 
        message: error.response?.data?.message || '删除分镜失败' 
      }
    }
  }

  // 更新分镜排序
  const updateShotsOrder = async (sortedIds) => {
    try {
      await api.put('/shot/sort', { sortedIds })
      return { success: true, message: '排序更新成功' }
    } catch (error) {
      console.error('排序更新失败:', error)
      return { 
        success: false, 
        message: error.response?.data?.message || '排序更新失败' 
      }
    }
  }

  // 上传分镜图片
  const uploadShotImage = async (shotId, file) => {
    try {
      const formData = new FormData()
      formData.append('image', file)
      formData.append('shotId', shotId)
      
      const response = await api.post('/shot/upload-image', formData, {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      })
      
      // 更新本地数据
      const index = shots.value.findIndex(shot => shot.id === shotId)
      if (index !== -1) {
        shots.value[index].image_url = response.data.data.image_url
      }
      
      return { 
        success: true, 
        data: response.data.data,
        message: '图片上传成功' 
      }
    } catch (error) {
      console.error('图片上传失败:', error)
      return { 
        success: false, 
        message: error.response?.data?.message || '图片上传失败' 
      }
    }
  }

  // 设置当前选中的分镜
  const setCurrentShot = (shot) => {
    currentShot.value = shot
  }

  // 清空分镜数据
  const clearShots = () => {
    shots.value = []
    currentShot.value = null
  }

  // 🔑 原始数据管理 - 用于多字段保存时的数据比较
  const originalShotData = ref({})

  // 设置分镜的原始数据
  const setOriginalShotData = (shotId, data) => {
    originalShotData.value[shotId] = data
    console.log(`💾 Store: 保存分镜 ${shotId} 的原始数据`)
  }

  // 获取分镜的原始数据
  const getOriginalShotData = (shotId) => {
    return originalShotData.value[shotId]
  }

  // 更新原始数据中的特定字段
  const updateOriginalShotDataField = (shotId, field, value) => {
    if (originalShotData.value[shotId]) {
      originalShotData.value[shotId][field] = value
      console.log(`💾 Store: 更新分镜 ${shotId} 的字段 ${field} = ${value}`)
    }
  }

  // 清空原始数据
  const clearOriginalShotData = () => {
    originalShotData.value = {}
  }

  return {
    shots,
    currentShot,
    loading,
    fetchShots,
    addShots,
    updateShot,
    deleteShot,
    updateShotsOrder,
    uploadShotImage,
    setCurrentShot,
    clearShots,
    setOriginalShotData,
    getOriginalShotData,
    updateOriginalShotDataField,
    clearOriginalShotData
  }
})