<template>
  <div class="shot-slide-view">
    <div class="slide-container" v-if="shots.length > 0">
      <!-- 导航按钮 -->
      <button 
        class="nav-btn prev-btn" 
        @click="prevSlide"
        :disabled="currentIndex === 0"
      >
        <el-icon size="24"><arrow-left /></el-icon>
      </button>
      
      <button 
        class="nav-btn next-btn" 
        @click="nextSlide"
        :disabled="currentIndex === shots.length - 1"
      >
        <el-icon size="24"><arrow-right /></el-icon>
      </button>
      
      <!-- 幻灯片内容 -->
      <div class="slide-content">
        <div class="slide-item" v-if="currentShot">
          <!-- 图片区域 -->
          <div class="image-section">
            <div class="image-container">
              <img 
                v-if="currentShot.image_url" 
                :src="getImageUrl(currentShot.image_url)" 
                :alt="currentShot.tag || '分镜图片'"
                @error="handleImageError"
              />
              <div v-else class="no-image">
                <el-icon size="48"><picture /></el-icon>
                <p>暂无图片</p>
              </div>
            </div>
            
            <!-- 悬浮缩略图导航 -->
            <div class="floating-thumbnail-section">
              <div class="floating-thumbnail-header">
                <el-icon class="thumbnail-icon"><film /></el-icon>
                <span class="thumbnail-title">分镜缩略图</span>
                <div class="thumbnail-counter">{{ currentIndex + 1 }} / {{ shots.length }}</div>
              </div>
              <div class="floating-thumbnail-nav">
                <div 
                  class="thumbnail-item"
                  v-for="(shot, index) in shots"
                  :key="shot.id"
                  :class="{ active: index === currentIndex }"
                  @click="goToSlide(index)"
                  :title="shot.tag || `分镜 ${index + 1}`"
                >
                  <img 
                    v-if="shot.image_url" 
                    :src="getImageUrl(shot.image_url)" 
                    :alt="shot.tag || '分镜图片'"
                    @error="handleThumbnailError"
                  />
                  <div v-else class="no-thumb">
                    <el-icon><picture /></el-icon>
                  </div>
                  <div class="shot-index">{{ index + 1 }}</div>
                </div>
              </div>
            </div>
          </div>
          
          <!-- 信息区域 -->
          <div class="info-section">
            <div class="shot-header">
              <h2 class="shot-number">镜号: {{ currentIndex + 1 }}/{{ shots.length }}</h2>
              <h3 class="shot-tag" v-if="currentShot.tag">{{ currentShot.tag }}</h3>
            </div>
            
            <div class="shot-fields">
              <div class="field-item" v-if="currentShot.description">
                <label>描述:</label>
                <div class="field-value">{{ currentShot.description }}</div>
              </div>
              
              <!-- 动态字段 -->
              
              
              <div class="field-item" v-if="fieldConfig.shot_type && currentShot.shot_type">
                <label>镜头:</label>
                <div class="field-value">{{ currentShot.shot_type }}</div>
              </div>
              
              <div class="field-item" v-if="fieldConfig.dialogue && currentShot.dialogue">
                <label>台词:</label>
                <div class="field-value">{{ currentShot.dialogue }}</div>
              </div>
              
              <div class="field-item" v-if="fieldConfig.sound_effect && currentShot.sound_effect">
                <label>音效:</label>
                <div class="field-value">{{ currentShot.sound_effect }}</div>
              </div>
              
              <div class="field-item" v-if="fieldConfig.animation && currentShot.animation">
                <label>动效:</label>
                <div class="field-value">{{ currentShot.animation }}</div>
              </div>
              
              <div class="field-item" v-if="fieldConfig.camera_movement && currentShot.camera_movement">
                <label>运镜:</label>
                <div class="field-value">{{ currentShot.camera_movement }}</div>
              </div>
              
              <div class="field-item" v-if="fieldConfig.scene && currentShot.scene">
                <label>场景:</label>
                <div class="field-value">{{ currentShot.scene }}</div>
              </div>
              
              <div class="field-item" v-if="fieldConfig.characters && currentShot.characters">
                <label>角色:</label>
                <div class="field-value">{{ currentShot.characters }}</div>
              </div>
              
              <div class="field-item" v-if="fieldConfig.character_state && currentShot.character_state">
                <label>人物状态:</label>
                <div class="field-value">{{ currentShot.character_state }}</div>
              </div>
              
              <div class="field-item" v-if="fieldConfig.narration && currentShot.narration">
                <label>旁白:</label>
                <div class="field-value">{{ currentShot.narration }}</div>
              </div>
              
              <div class="field-item" v-if="fieldConfig.shooting_angle && currentShot.shooting_angle">
                <label>拍摄角度:</label>
                <div class="field-value">{{ currentShot.shooting_angle }}</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    
    <div v-else class="empty-state">
      <el-icon size="64" color="#ccc"><film /></el-icon>
      <p>暂无分镜内容</p>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, watch } from 'vue'
import { ArrowLeft, ArrowRight, Picture, Film } from '@element-plus/icons-vue'
import { getImageUrl } from '@/utils/common'

const props = defineProps({
  shots: {
    type: Array,
    default: () => []
  },
  fieldConfig: {
    type: Object,
    default: () => ({})
  }
})

const emit = defineEmits(['update:currentIndex'])

const currentIndex = ref(0)

const currentShot = computed(() => {
  return props.shots[currentIndex.value]
})

const prevSlide = () => {
  if (currentIndex.value > 0) {
    currentIndex.value--
    emit('update:currentIndex', currentIndex.value)
  }
}

const nextSlide = () => {
  if (currentIndex.value < props.shots.length - 1) {
    currentIndex.value++
    emit('update:currentIndex', currentIndex.value)
  }
}

const goToSlide = (index) => {
  currentIndex.value = index
  emit('update:currentIndex', currentIndex.value)
}

// 键盘导航
const handleKeydown = (event) => {
  if (event.key === 'ArrowLeft') {
    prevSlide()
  } else if (event.key === 'ArrowRight') {
    nextSlide()
  }
}

// 监听键盘事件
watch(() => props.shots, () => {
  if (props.shots.length > 0) {
    window.addEventListener('keydown', handleKeydown)
  }
  
  return () => {
    window.removeEventListener('keydown', handleKeydown)
  }
})

// 图片加载错误处理
const handleImageError = (event) => {
  event.target.style.display = 'none'
}

const handleThumbnailError = (event) => {
  event.target.parentElement.querySelector('.no-thumb').style.display = 'flex'
  event.target.style.display = 'none'
}

// 监听shots变化，重置索引
watch(() => props.shots, (newShots) => {
  if (newShots.length > 0 && currentIndex.value >= newShots.length) {
    currentIndex.value = newShots.length - 1
  } else if (newShots.length === 0) {
    currentIndex.value = 0
  }
})
</script>

<style scoped>
.shot-slide-view {
  height: 100%;
  display: flex;
  flex-direction: column;
  background: #f5f5f5;
}

.slide-container {
  flex: 1;
  display: flex;
  flex-direction: column;
  position: relative;
}

.nav-btn {
  position: absolute;
  top: 50%;
  transform: translateY(-50%);
  width: 50px;
  height: 50px;
  border: none;
  border-radius: 50%;
  background: rgba(255, 255, 255, 0.8);
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.1);
  z-index: 10;
  transition: all 0.3s ease;
}

.nav-btn:hover:not(:disabled) {
  background: rgba(255, 255, 255, 0.95);
  transform: translateY(-50%) scale(1.1);
}

.nav-btn:disabled {
  background: rgba(255, 255, 255, 0.5);
  cursor: not-allowed;
  opacity: 0.5;
}

.prev-btn {
  left: 20px;
}

.next-btn {
  right: 20px;
}

.slide-content {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 20px;
  overflow: hidden;
}

.slide-item {
  display: flex;
  width: 100%;
  max-width: 1400px;
  height: calc(100vh - 160px);
  background: white;
  border-radius: 12px;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
  overflow: hidden;
}

.image-section {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  background: #000;
  min-width: 0;
  position: relative;
}

.image-container {
  width: 100%;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
}

.image-container img {
  max-width: 100%;
  max-height: 100%;
  object-fit: contain;
}

.no-image {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  color: #ccc;
  height: 100%;
  width: 100%;
}

.no-image p {
  margin-top: 10px;
  font-size: 16px;
}

.info-section {
  width: 400px;
  padding: 30px;
  overflow-y: auto;
  background: white;
  border-left: 1px solid #e4e7ed;
}

.shot-header {
  margin-bottom: 25px;
  padding-bottom: 15px;
  border-bottom: 1px solid #e4e7ed;
}

.shot-number {
  color: #409eff;
  font-size: 18px;
  margin: 0 0 10px 0;
}

.shot-tag {
  color: #333;
  font-size: 24px;
  margin: 0;
  font-weight: 600;
}

.shot-fields {
  display: flex;
  flex-direction: column;
  gap: 15px;
}

.field-item {
  display: flex;
  flex-direction: column;
}

.field-item label {
  font-weight: 600;
  color: #666;
  font-size: 14px;
  margin-bottom: 5px;
}

.field-value {
  color: #333;
  font-size: 16px;
  line-height: 1.5;
  white-space: pre-wrap;
  word-break: break-word;
}

/* 悬浮缩略图样式 */
.floating-thumbnail-section {
  position: absolute;
  bottom: 20px;
  left: 50%;
  transform: translateX(-50%);
  max-width: calc(100% - 40px);
  background: rgba(0, 0, 0, 0.8);
  border-radius: 12px;
  backdrop-filter: blur(10px);
  border: 1px solid rgba(255, 255, 255, 0.1);
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.5);
}

.floating-thumbnail-header {
  display: flex;
  align-items: center;
  padding: 8px 16px;
  background: linear-gradient(135deg, rgba(64, 158, 255, 0.9), rgba(51, 126, 204, 0.9));
  color: white;
  font-weight: 600;
  gap: 8px;
  border-radius: 12px 12px 0 0;
  border-bottom: 1px solid rgba(255, 255, 255, 0.2);
}

.floating-thumbnail-header .thumbnail-icon {
  font-size: 16px;
}

.floating-thumbnail-header .thumbnail-title {
  font-size: 13px;
  flex: 1;
}

.floating-thumbnail-header .thumbnail-counter {
  background: rgba(255, 255, 255, 0.3);
  padding: 2px 8px;
  border-radius: 10px;
  font-size: 11px;
}

.floating-thumbnail-nav {
  padding: 12px 16px;
  display: flex;
  align-items: center;
  gap: 12px;
  overflow-x: auto;
  max-width: 100%;
}

.floating-thumbnail-nav::-webkit-scrollbar {
  height: 4px;
}

.floating-thumbnail-nav::-webkit-scrollbar-track {
  background: rgba(255, 255, 255, 0.1);
  border-radius: 2px;
}

.floating-thumbnail-nav::-webkit-scrollbar-thumb {
  background: rgba(64, 158, 255, 0.8);
  border-radius: 2px;
}

.floating-thumbnail-nav::-webkit-scrollbar-thumb:hover {
  background: rgba(64, 158, 255, 1);
}

.thumbnail-item {
  width: 60px;
  height: 45px;
  border: 2px solid rgba(255, 255, 255, 0.3);
  border-radius: 8px;
  cursor: pointer;
  flex-shrink: 0;
  position: relative;
  overflow: hidden;
  transition: all 0.3s ease;
  background: white;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.3);
}

.thumbnail-item:hover {
  border-color: #409eff;
  transform: scale(1.1);
  box-shadow: 0 4px 16px rgba(64, 158, 255, 0.5);
  z-index: 10;
}

.thumbnail-item.active {
  border-color: #409eff;
  box-shadow: 0 0 0 2px rgba(64, 158, 255, 0.8), 0 4px 16px rgba(64, 158, 255, 0.5);
  transform: scale(1.05);
  z-index: 5;
}

.thumbnail-item img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.no-thumb {
  width: 100%;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  background: #f5f5f5;
  color: #ccc;
}

.shot-index {
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  background: rgba(0, 0, 0, 0.8);
  color: white;
  text-align: center;
  font-size: 10px;
  font-weight: 600;
  padding: 2px;
  border-radius: 0 0 6px 6px;
}

.empty-state {
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  color: #999;
}

.empty-state p {
  margin-top: 20px;
  font-size: 16px;
}

/* 响应式设计 */
@media (max-width: 1024px) {
  .slide-item {
    flex-direction: column;
    height: calc(100vh - 140px);
  }
  
  .image-section {
    height: 60%;
  }
  
  .info-section {
    width: 100%;
    height: 40%;
    border-left: none;
    border-top: 1px solid #e4e7ed;
  }
  
  .floating-thumbnail-section {
    bottom: 10px;
    max-width: calc(100% - 20px);
  }
  
  .floating-thumbnail-nav {
    padding: 8px 12px;
    gap: 8px;
  }
  
  .thumbnail-item {
    width: 50px;
    height: 37px;
  }
  
  .nav-btn {
    width: 40px;
    height: 40px;
  }
  
  .prev-btn {
    left: 10px;
  }
  
  .next-btn {
    right: 10px;
  }
}

@media (max-width: 768px) {
  .slide-content {
    padding: 10px;
  }
  
  .slide-item {
    border-radius: 8px;
    height: calc(100vh - 120px);
  }
  
  .info-section {
    padding: 20px 15px;
  }
  
  .shot-tag {
    font-size: 20px;
  }
  
  .field-value {
    font-size: 14px;
  }
  
  .floating-thumbnail-section {
    bottom: 8px;
    max-width: calc(100% - 16px);
  }
  
  .floating-thumbnail-header {
    padding: 6px 12px;
  }
  
  .floating-thumbnail-header .thumbnail-title {
    font-size: 12px;
  }
  
  .floating-thumbnail-header .thumbnail-counter {
    font-size: 10px;
  }
  
  .floating-thumbnail-nav {
    padding: 6px 12px;
    gap: 6px;
  }
  
  .thumbnail-item {
    width: 42px;
    height: 32px;
  }
  
  .nav-btn {
    width: 36px;
    height: 36px;
  }
}

@media (max-width: 480px) {
  .slide-item {
    height: calc(100vh - 100px);
  }
  
  .info-section {
    padding: 15px 12px;
  }
  
  .shot-header {
    margin-bottom: 15px;
    padding-bottom: 10px;
  }
  
  .shot-number {
    font-size: 16px;
  }
  
  .shot-tag {
    font-size: 18px;
  }
  
  .field-item label {
    font-size: 13px;
  }
  
  .field-value {
    font-size: 13px;
  }
  
  .floating-thumbnail-section {
    bottom: 6px;
    max-width: calc(100% - 12px);
  }
  
  .floating-thumbnail-header {
    padding: 4px 8px;
  }
  
  .floating-thumbnail-header .thumbnail-title {
    font-size: 11px;
  }
  
  .floating-thumbnail-header .thumbnail-counter {
    font-size: 9px;
    padding: 1px 6px;
  }
  
  .floating-thumbnail-nav {
    padding: 4px 8px;
    gap: 4px;
  }
  
  .thumbnail-item {
    width: 36px;
    height: 27px;
  }
  
  .shot-index {
    font-size: 8px;
    padding: 1px;
  }
}
</style>