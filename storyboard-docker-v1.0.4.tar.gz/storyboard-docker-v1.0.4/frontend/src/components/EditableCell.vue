<template>
  <div class="editable-cell" @click="handleClick" :class="{ editing: isEditing, readonly: readonly }">
    <!-- 显示模式 -->
    <div v-if="!isEditing" class="display-mode">
      <span v-if="displayValue" class="cell-value">{{ displayValue }}</span>
      <span v-else class="cell-placeholder">{{ fieldDisplayName }}</span>
    </div>
    
    <!-- 编辑模式 -->
    <div v-else class="edit-mode">
      <!-- 单行输入 -->
      <el-input
        v-if="type === 'input'"
        ref="inputRef"
        v-model="editValue"
        size="small"
        @blur="finishEdit"
        @keyup.enter="finishEdit"
        @keyup.esc="cancelEdit"
        @input="handleInputChange"
      />
      
      <!-- 数字输入 -->
      <el-input
        v-else-if="type === 'number'"
        ref="inputRef"
        v-model="editValue"
        type="number"
        size="small"
        @blur="finishEdit"
        @keyup.enter="finishEdit"
        @keyup.esc="cancelEdit"
        @input="handleInputChange"
      />
      
      <!-- 多行文本 -->
      <el-input
        v-else-if="type === 'textarea'"
        ref="textareaRef"
        v-model="editValue"
        type="textarea"
        :rows="2"
        size="small"
        @blur="finishEdit"
        @keyup.esc="cancelEdit"
        @input="handleInputChange"
      />
    </div>
  </div>
</template>

<script setup>
import { ref, computed, nextTick } from 'vue'
import { ElMessage } from 'element-plus'
import { debounce } from '@/utils/common'

const props = defineProps({
  value: {
    type: [String, Number],
    default: ''
  },
  shotId: {
    type: [Number, String],
    required: true
  },
  field: {
    type: String,
    required: true
  },
  type: {
    type: String,
    default: 'input' // input 或 textarea
  },
  placeholder: {
    type: String,
    default: '点击编辑'
  },
  readonly: {
    type: Boolean,
    default: false
  }
})

const emit = defineEmits(['update', 'startEdit', 'endEdit'])

const isEditing = ref(false)
const editValue = ref('')
const originalValue = ref('')
const inputRef = ref(null)
const textareaRef = ref(null)
const inputChangeTimer = ref(null) // 新增防抖计时器

// 显示值
const displayValue = computed(() => {
  return props.value || ''
})

// 字段验证规则（与后端保持一致）
const FIELD_VALIDATION_RULES = {
  tag: { maxLength: 100 },
  description: { maxLength: 1000 },
  shot_type: { maxLength: 50 },
  dialogue: { maxLength: 1000 },
  sound_effect: { maxLength: 200 },
  animation: { maxLength: 200 },
  camera_movement: { maxLength: 200 },
  scene: { maxLength: 100 },
  characters: { maxLength: 100 },
  character_state: { maxLength: 100 },
  narration: { maxLength: 1000 },
  shooting_angle: { maxLength: 50 }
}

// 字段名称映射
const fieldNameMap = {
  tag: '标签',
  description: '描述',
  shot_type: '镜头类型',
  dialogue: '对话',
  sound_effect: '音效',
  animation: '动画',
  camera_movement: '镜头运动',
  scene: '场景',
  characters: '角色',
  character_state: '角色状态',
  narration: '旁白',
  shooting_angle: '拍摄角度'
}

// 验证字段值
const validateFieldValue = (field, value) => {
  if (!FIELD_VALIDATION_RULES[field]) return { valid: true };
  
  const rules = FIELD_VALIDATION_RULES[field];
  
  // 空值检查
  if (value === null || value === undefined || value === '') {
    return { valid: true }; // 允许空值
  }
  
  // 字符串长度检查
  if (rules.maxLength && typeof value === 'string') {
    if (value.length > rules.maxLength) {
      return {
        valid: false,
        error: `${fieldNameMap[field]}长度不能超过${rules.maxLength}个字符`
      };
    }
  }
  
  return { valid: true };
}

// 字段显示名称
const fieldDisplayName = computed(() => {
  return fieldNameMap[props.field] || props.field
})

// 处理点击事件
const handleClick = () => {
  if (props.readonly) return
  startEdit()
}

// 开始编辑
const startEdit = async () => {
  if (isEditing.value) return
  
  console.log(`🚀 EditableCell startEdit: field=${props.field}, value=${props.value}`)
  
  isEditing.value = true
  editValue.value = props.value || ''
  originalValue.value = props.value || ''
  
  console.log(`📝 初始化编辑: originalValue=${originalValue.value}, editValue=${editValue.value}`)
  
  emit('startEdit', props.shotId, props.field)
  
  // 等待DOM更新后聚焦输入框
  await nextTick()
  const ref = props.type === 'textarea' ? textareaRef.value : inputRef.value
  if (ref) {
    ref.focus()
    // 选中所有文本
    if (ref.$refs?.input) {
      ref.$refs.input.select()
    } else if (ref.$refs?.textarea) {
      ref.$refs.textarea.select()
    }
  }
}

// 处理输入变化
const handleInputChange = (value) => {
  if (!isEditing.value) return
  
  console.log(`🔄 EditableCell 输入变化: field=${props.field}, shotId=${props.shotId}, value=${value}, type=${typeof value}`)
  
  // 使用防抖来避免频繁触发更新
  if (inputChangeTimer.value) {
    clearTimeout(inputChangeTimer.value)
  }
  
  inputChangeTimer.value = setTimeout(() => {
    // 根据字段类型处理数据格式
    let processedValue = value
    
    // 空值处理：统一转换为null
    if (value === '' || value === null || value === undefined) {
      processedValue = null
    } else {
      // 统一转换为字符串类型，确保与后端验证规则匹配
      processedValue = String(value)
    }
    
    // 验证字段值
    const validation = validateFieldValue(props.field, processedValue)
    if (!validation.valid) {
      console.error(`❌ 字段验证失败: ${validation.error}`)
      // 显示错误提示
      ElMessage.error(validation.error)
      return
    }
    
    console.log(`⏰ 发送更新: field=${props.field}, originalValue=${value}(${typeof value}) -> processedValue=${processedValue}(${typeof processedValue})`)
    
    // 实时发送更新事件，确保数据同步
    // 注意：字段映射在shot.js中处理，这里保持前端字段名
    emit('update', props.shotId, props.field, processedValue)
  }, 50)
}

// 完成编辑
const finishEdit = () => {
  if (!isEditing.value) return
  
  console.log(`🔍 EditableCell finishEdit: field=${props.field}, original=${originalValue.value}, current=${editValue.value}`)
  
  // 根据字段类型处理数据格式
  let processedValue = editValue.value
  if (props.type === 'number') {
    // 数字字段转换为字符串，因为后端期望字符串
    processedValue = editValue.value === '' ? null : String(editValue.value)
    console.log(`🔢 数字字段转换: ${editValue.value} -> ${processedValue}`)
  } else {
    // 字符串字段处理空值
    processedValue = editValue.value === '' ? null : String(editValue.value)
  }
  
  // 验证字段值
  const validation = validateFieldValue(props.field, processedValue)
  if (!validation.valid) {
    console.error(`❌ 字段验证失败: ${validation.error}`)
    // 恢复原始值
    editValue.value = originalValue.value
    // 显示错误提示
    ElMessage.error(validation.error)
    return
  }
  
  // 立即发送更新事件，实现即时保存
  emit('update', props.shotId, props.field, processedValue)
  
  isEditing.value = false
  emit('endEdit', props.shotId, props.field)
  
  console.log(`✅ EditableCell 更新完成: ${props.field} = ${processedValue}`)
}

// 取消编辑
const cancelEdit = () => {
  if (!isEditing.value) return
  
  editValue.value = originalValue.value
  isEditing.value = false
  emit('endEdit', props.shotId, props.field)
}
</script>

<style scoped>
.editable-cell {
  width: 100%;
  height: 130px; /* 与行高一致 */
  cursor: pointer;
  transition: all 0.2s ease;
  display: flex;
  align-items: center; /* 垂直居中 */
  box-sizing: border-box;
}

.editable-cell:hover:not(.editing) {
  background: #f0f9ff;
  border-radius: 4px;
}

.display-mode {
  padding: 16px 12px; /* 重新添加内边距 */
  min-height: 40px;
  word-wrap: break-word;
  word-break: break-all;
  overflow: hidden;
  text-overflow: ellipsis;
  max-height: 100px;
  width: 100%;
}

.cell-value {
  color: #303133;
  line-height: 1.4;
}

.cell-placeholder {
  color: #c0c4cc;
}

.edit-mode {
  width: 100%;
}

.editing {
  cursor: default;
}

.readonly {
  cursor: default !important;
  background-color: #f5f7fa;
}

.readonly:hover {
  background: #f5f7fa !important;
}

/* Element Plus 输入框样式调整 */
.edit-mode :deep(.el-input) {
  --el-input-border-color: #409eff;
}

.edit-mode :deep(.el-input__wrapper) {
  box-shadow: 0 0 0 1px #409eff inset;
}

.edit-mode :deep(.el-textarea__inner) {
  border-color: #409eff;
  box-shadow: 0 0 0 1px #409eff inset;
  resize: none;
}
</style>