<template>
  <div class="preview-container">
    <!-- 顶部工具栏 -->
    <div class="toolbar">
      <div class="toolbar-left">
        <el-button :icon="ArrowLeft" @click="goBack">返回编辑</el-button>
        <span class="project-title">{{ projectInfo?.name || '分镜预览' }}</span>
      </div>
      <div class="toolbar-right">
        <el-button :icon="Download" @click="exportPDF">导出PDF</el-button>
        <el-button :icon="Share" @click="shareProject">分享</el-button>
      </div>
    </div>

    <!-- 预览内容 -->
    <div class="preview-content" v-loading="loading">
      <div v-if="shots.length === 0" class="empty-state">
        <el-icon size="64" color="#ccc"><film /></el-icon>
        <p>暂无分镜内容</p>
        <el-button type="primary" @click="goBack">去添加分镜</el-button>
      </div>

      <div v-else class="storyboard">
        <!-- 项目信息头 -->
        <div class="project-header">
          <h1>{{ projectInfo?.name }}</h1>
          <div class="project-meta">
            <p>总镜头数: {{ shots.length }}</p>
            <p>创建时间: {{ formatDate(projectInfo?.create_time) }}</p>
            <p>最后编辑: {{ formatDate(projectInfo?.last_edit_time) }}</p>
          </div>
        </div>

        <!-- 分镜列表 -->
        <div class="shots-grid">
          <div 
            v-for="(shot, index) in shots" 
            :key="shot.id"
            class="shot-card"
          >
            <!-- 镜头编号 -->
            <div class="shot-number">
              镜头 {{ index + 1 }}
            </div>

            <!-- 镜头图片 -->
            <div class="shot-image">
              <img 
                v-if="shot.image_url" 
                :src="getImageUrl(shot.image_url)" 
                :alt="`镜头${index + 1}`"
                @error="handleImageError"
              />
              <div v-else class="no-image">
                <el-icon size="48" color="#ccc"><picture /></el-icon>
                <span>暂无图片</span>
              </div>
            </div>

            <!-- 镜头信息 -->
            <div class="shot-info">
              <div class="shot-tag">
                <strong>标签:</strong> {{ shot.tag || '未命名' }}
              </div>
              <div class="shot-description">
                <strong>描述:</strong>
                <p>{{ shot.description || '暂无描述' }}</p>
              </div>
              
              <!-- 动态字段 -->
              <div v-if="projectStore.currentFieldConfig.duration && shot.duration" class="shot-field">
                <strong>时长:</strong> {{ shot.duration }}
              </div>
              
              <div v-if="projectStore.currentFieldConfig.shot_type && shot.shot_type" class="shot-field">
                <strong>镜头:</strong> {{ shot.shot_type }}
              </div>
              
              <div v-if="projectStore.currentFieldConfig.dialogue && shot.dialogue" class="shot-field">
                <strong>台词:</strong>
                <p class="field-content">{{ shot.dialogue }}</p>
              </div>
              
              <div v-if="projectStore.currentFieldConfig.sound_effect && shot.sound_effect" class="shot-field">
                <strong>音效:</strong> {{ shot.sound_effect }}
              </div>
              
              <div v-if="projectStore.currentFieldConfig.animation && shot.animation" class="shot-field">
                <strong>动效:</strong> {{ shot.animation }}
              </div>
              
              <div v-if="projectStore.currentFieldConfig.camera_movement && shot.camera_movement" class="shot-field">
                <strong>运镜:</strong> {{ shot.camera_movement }}
              </div>
              
              <div v-if="projectStore.currentFieldConfig.scene && shot.scene" class="shot-field">
                <strong>场景:</strong> {{ shot.scene }}
              </div>
              
              <div v-if="projectStore.currentFieldConfig.character && shot.character" class="shot-field">
                <strong>角色:</strong> {{ shot.character }}
              </div>
              
              <div v-if="projectStore.currentFieldConfig.character_state && shot.character_state" class="shot-field">
                <strong>人物状态:</strong> {{ shot.character_state }}
              </div>
              
              <div v-if="projectStore.currentFieldConfig.narration && shot.narration" class="shot-field">
                <strong>旁白:</strong>
                <p class="field-content">{{ shot.narration }}</p>
              </div>
              
              <div v-if="projectStore.currentFieldConfig.shooting_angle && shot.shooting_angle" class="shot-field">
                <strong>拍摄角度:</strong> {{ shot.shooting_angle }}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- 分享对话框 -->
    <el-dialog
      v-model="showShareDialog"
      title="分享项目"
      width="500px"
    >
      <div class="share-content">
        <p>生成的分享链接：</p>
        <el-input
          v-model="shareUrl"
          readonly
          class="share-input"
        >
          <template #append>
            <el-button @click="copyShareUrl">复制</el-button>
          </template>
        </el-input>
        <p class="share-tips">
          <el-icon><info-filled /></el-icon>
          分享链接有效期为7天，过期后需要重新生成
        </p>
      </div>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import { 
  ArrowLeft, Download, Share, Film, Picture, InfoFilled 
} from '@element-plus/icons-vue'
import { useProjectStore } from '@/stores/project'
import { useShotStore } from '@/stores/shot'
import { formatDate, getImageUrl } from '@/utils/common'
import api from '@/utils/api'

const route = useRoute()
const router = useRouter()

const projectStore = useProjectStore()
const shotStore = useShotStore()

const projectId = route.params.projectId
const loading = ref(false)
const showShareDialog = ref(false)
const shareUrl = ref('')

const projectInfo = ref(null)
const shots = ref([])

// 获取项目和分镜数据
const fetchData = async () => {
  loading.value = true
  try {
    // 获取项目信息
    const projectResult = await projectStore.fetchProject(projectId)
    if (projectResult.success) {
      projectInfo.value = projectStore.currentProject
      console.log('项目信息:', projectInfo.value) // 调试日志
      console.log('字段配置:', projectStore.currentFieldConfig) // 调试日志
    } else {
      ElMessage.error(projectResult.message)
    }

    // 确保字段配置已加载
    const fieldConfigResult = await projectStore.fetchFieldConfig(projectId)
    if (fieldConfigResult.success) {
      console.log('字段配置加载成功:', projectStore.currentFieldConfig) // 调试日志
    } else {
      console.error('字段配置加载失败:', fieldConfigResult.message)
    }

    // 获取分镜列表
    const shotsResult = await shotStore.fetchShots(projectId)
    if (shotsResult.success) {
      shots.value = shotStore.shots
      console.log('分镜数据:', shots.value) // 调试日志
    } else {
      ElMessage.error(shotsResult.message)
    }
  } catch (error) {
    console.error('获取数据失败:', error)
    ElMessage.error('获取数据失败')
  } finally {
    loading.value = false
  }
}

// 返回编辑页面
const goBack = () => {
  router.push(`/edit/${projectId}`)
}

// 导出PDF
const exportPDF = async () => {
  try {
    const response = await api.get(`/export/project/${projectId}?format=pdf`, {
      responseType: 'blob'
    })
    
    const url = window.URL.createObjectURL(new Blob([response.data]))
    const link = document.createElement('a')
    link.href = url
    link.download = `${projectInfo.value?.name || '分镜故事板'}.pdf`
    link.click()
    window.URL.revokeObjectURL(url)
    
    ElMessage.success('导出成功')
  } catch (error) {
    console.error('导出失败:', error)
    ElMessage.error('导出失败')
  }
}

// 分享项目
const shareProject = async () => {
  try {
    console.log('开始创建分享链接...')
    const response = await api.post(`/share/create/${projectId}`)
    console.log('分享响应:', response.data)
    
    if (response.data && response.data.data && response.data.data.token) {
      shareUrl.value = `${window.location.origin}/share/${response.data.data.token}`
      showShareDialog.value = true
      console.log('分享链接生成成功:', shareUrl.value)
    } else {
      console.error('分享响应数据格式错误:', response.data)
      ElMessage.error('分享链接格式错误')
    }
  } catch (error) {
    console.error('生成分享链接失败:', error)
    
    // 详细的错误处理
    if (error.response) {
      const status = error.response.status
      const message = error.response.data?.message || '服务器错误'
      console.error('错误响应:', { status, data: error.response.data })
      
      if (status === 401) {
        ElMessage.error('登录已过期，请重新登录')
      } else if (status === 403) {
        ElMessage.error('没有权限分享此项目')
      } else {
        ElMessage.error(`生成分享链接失败: ${message}`)
      }
    } else if (error.request) {
      console.error('网络错误:', error.request)
      ElMessage.error('网络连接失败，请检查网络连接')
    } else {
      console.error('未知错误:', error.message)
      ElMessage.error(`生成分享链接失败: ${error.message || '未知错误'}`)
    }
  }
}

// 复制分享链接
const copyShareUrl = async () => {
  try {
    await navigator.clipboard.writeText(shareUrl.value)
    ElMessage.success('链接已复制到剪贴板')
  } catch (error) {
    console.warn('剪贴板复制失败，使用备用方案:', error)
    // 备用方案：使用传统的选中和复制方式
    const textArea = document.createElement('textarea')
    textArea.value = shareUrl.value
    document.body.appendChild(textArea)
    textArea.select()
    
    try {
      const successful = document.execCommand('copy')
      if (successful) {
        ElMessage.success('链接已复制到剪贴板')
      } else {
        ElMessage.error('复制失败，请手动复制')
      }
    } catch (execError) {
      console.error('传统复制方式也失败:', execError)
      ElMessage.error('复制失败，请手动复制')
    } finally {
      document.body.removeChild(textArea)
    }
  }
}

// 图片加载失败处理
const handleImageError = (event) => {
  event.target.style.display = 'none'
  console.error('图片加载失败:', event.target.src)
}

onMounted(() => {
  fetchData()
})
</script>

<style scoped>
.preview-container {
  height: 100vh;
  display: flex;
  flex-direction: column;
  background: #f5f5f5;
}

.toolbar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 10px 20px;
  background: white;
  border-bottom: 1px solid #e4e7ed;
}

.toolbar-left {
  display: flex;
  align-items: center;
  gap: 15px;
}

.project-title {
  font-size: 18px;
  font-weight: 600;
  color: #333;
}

.toolbar-right {
  display: flex;
  align-items: center;
  gap: 10px;
}

.preview-content {
  flex: 1;
  overflow-y: auto;
  padding: 20px;
}

.empty-state {
  text-align: center;
  padding: 80px 20px;
  color: #999;
}

.empty-state p {
  margin: 20px 0;
  font-size: 16px;
}

.storyboard {
  max-width: 1200px;
  margin: 0 auto;
  background: white;
  border-radius: 8px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  overflow: hidden;
}

.project-header {
  padding: 30px;
  border-bottom: 2px solid #e4e7ed;
  text-align: center;
}

.project-header h1 {
  margin: 0 0 20px 0;
  color: #333;
  font-size: 28px;
}

.project-meta {
  display: flex;
  justify-content: center;
  gap: 30px;
  color: #666;
  font-size: 14px;
}

.project-meta p {
  margin: 0;
}

.shots-grid {
  padding: 30px;
}

.shot-card {
  display: grid;
  grid-template-columns: auto 1fr;
  grid-template-rows: auto 1fr;
  gap: 20px;
  padding: 20px;
  border: 1px solid #e4e7ed;
  border-radius: 8px;
  margin-bottom: 20px;
  background: #fafafa;
}

.shot-number {
  grid-column: 1 / -1;
  font-size: 18px;
  font-weight: 600;
  color: #409eff;
  padding: 10px 15px;
  background: white;
  border-radius: 6px;
  border-left: 4px solid #409eff;
}

.shot-image {
  width: 300px;
  height: 200px;
  border: 1px solid #e4e7ed;
  border-radius: 8px;
  overflow: hidden;
  display: flex;
  align-items: center;
  justify-content: center;
  background: white;
}

.shot-image img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.no-image {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 10px;
  color: #999;
}

.shot-info {
  display: flex;
  flex-direction: column;
  gap: 15px;
}

.shot-tag {
  font-size: 16px;
  color: #333;
}

.shot-description {
  color: #666;
  margin-bottom: 10px;
}

.shot-description p {
  margin: 5px 0 0 0;
  line-height: 1.6;
  white-space: pre-wrap;
}

.shot-field {
  margin-bottom: 10px;
  color: #666;
}

.shot-field strong {
  color: #333;
}

.field-content {
  margin: 5px 0 0 0;
  line-height: 1.6;
  white-space: pre-wrap;
}

.share-content {
  text-align: center;
}

.share-input {
  margin: 15px 0;
}

.share-tips {
  margin-top: 15px;
  color: #999;
  font-size: 14px;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 5px;
}

/* 移动端适配 */
@media (max-width: 768px) {
  .toolbar {
    padding: 8px 12px;
    flex-direction: column;
    gap: 8px;
    align-items: stretch;
  }
  
  .toolbar-left {
    justify-content: flex-start;
    gap: 10px;
  }
  
  .project-title {
    font-size: 16px;
    max-width: 200px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  
  .toolbar-right {
    justify-content: center;
    gap: 8px;
    flex-wrap: wrap;
  }
  
  .toolbar-right .el-button {
    padding: 8px 12px;
    font-size: 12px;
  }
  
  .preview-content {
    padding: 10px;
  }
  
  .storyboard {
    margin: 0;
    border-radius: 0;
  }
  
  .project-header {
    padding: 20px 15px;
  }
  
  .project-header h1 {
    font-size: 22px;
    margin-bottom: 15px;
  }
  
  .project-meta {
    flex-direction: column;
    gap: 10px;
    align-items: center;
  }
  
  .shots-grid {
    padding: 15px;
  }
  
  .shot-card {
    grid-template-columns: 1fr;
    gap: 15px;
    padding: 15px;
    margin-bottom: 15px;
  }
  
  .shot-number {
    grid-column: 1;
    font-size: 16px;
    padding: 8px 12px;
    text-align: center;
  }
  
  .shot-image {
    width: 100%;
    height: 200px;
    max-width: 100%;
  }
  
  .shot-info {
    gap: 12px;
  }
  
  .shot-tag {
    font-size: 14px;
  }
  
  .shot-description,
  .shot-field {
    font-size: 14px;
  }
}

/* 更小屏幕适配 */
@media (max-width: 480px) {
  .toolbar {
    padding: 6px 8px;
  }
  
  .toolbar-left {
    gap: 8px;
  }
  
  .project-title {
    font-size: 14px;
    max-width: 150px;
  }
  
  .toolbar-right {
    gap: 6px;
  }
  
  .toolbar-right .el-button {
    padding: 6px 8px;
    font-size: 11px;
  }
  
  .toolbar-right .el-button span {
    display: none;
  }
  
  .preview-content {
    padding: 8px;
  }
  
  .project-header {
    padding: 15px 10px;
  }
  
  .project-header h1 {
    font-size: 18px;
    margin-bottom: 10px;
  }
  
  .project-meta {
    font-size: 12px;
    gap: 8px;
  }
  
  .shots-grid {
    padding: 10px;
  }
  
  .shot-card {
    padding: 12px;
    margin-bottom: 12px;
  }
  
  .shot-number {
    font-size: 14px;
    padding: 6px 10px;
  }
  
  .shot-image {
    height: 180px;
  }
  
  .shot-info {
    gap: 10px;
  }
  
  .shot-tag,
  .shot-description,
  .shot-field {
    font-size: 13px;
  }
}

/* 打印样式 */
@media print {
  .toolbar {
    display: none;
  }
  
  .preview-content {
    padding: 0;
  }
  
  .shot-card {
    page-break-inside: avoid;
    margin-bottom: 30px;
  }
}
</style>