<template>
  <div class="test-container">
    <h1>路由测试页面</h1>
    <el-button @click="goToProjects">跳转到项目列表</el-button>
    <el-button @click="goToSquare">跳转到脚本广场</el-button>
    <el-button @click="goBack">返回</el-button>
  </div>
</template>

<script setup>
import { useRouter } from 'vue-router'
import { ElButton } from 'element-plus'

const router = useRouter()

const goToProjects = () => {
  console.log('测试跳转到项目列表')
  router.push('/projects')
}

const goToSquare = () => {
  console.log('测试跳转到脚本广场')
  router.push('/script-square')
}

const goBack = () => {
  console.log('测试返回')
  router.go(-1)
}
</script>

<style scoped>
.test-container {
  padding: 20px;
  text-align: center;
}
</style>