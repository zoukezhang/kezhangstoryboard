<template>
  <div class="script-preview-container">
    <!-- 顶部工具栏 -->
    <div class="toolbar">
      <div class="toolbar-left">
        <el-button :icon="ArrowLeft" @click="goBack">返回脚本广场</el-button>
        <span class="script-title">{{ scriptInfo?.description || '脚本预览' }}</span>
      </div>
              <div class="toolbar-right">
          <el-button type="primary" :icon="CopyDocument" @click="createSameScript">一键同款</el-button>
          <el-button :icon="Download" @click="exportPDF">导出PDF</el-button>
          <el-button :icon="Share" @click="shareScript">分享</el-button>
        </div>
    </div>

    <!-- 脚本信息头 -->
    <div class="script-header">
      <div class="script-info">
        <h1>{{ scriptInfo?.description || '未命名脚本' }}</h1>
        <div class="script-meta">
          <span class="author">作者: {{ scriptInfo?.author || '未知' }}</span>
          <span class="category">分类: {{ scriptInfo?.category || '未分类' }}</span>
          <span class="shot-count">分镜数量: {{ shots.length }}</span>
        </div>
      </div>
    </div>

    <!-- 视图切换 -->
    <div class="view-tabs">
      <el-tabs v-model="activeView" @tab-change="handleViewChange">
        <el-tab-pane label="卡片视图" name="preview">
          <div class="shots-grid">
            <div 
              v-for="shot in shots" 
              :key="shot.id" 
              class="shot-card"
            >
              <div class="shot-image">
                <img 
                  v-if="shot.image_url" 
                  :src="getImageUrl(shot.image_url)" 
                  :alt="`分镜 ${shot.sort_order}`"
                />
                <div v-else class="no-image">
                  <el-icon><Picture /></el-icon>
                  <span>无图片</span>
                </div>
              </div>
              <div class="shot-info">
                <div class="shot-number">镜号: {{ shot.sort_order }}</div>
                <div class="shot-tag" v-if="shot.tag">标签: {{ shot.tag }}</div>
                <div class="shot-description" v-if="shot.description">
                  {{ shot.description }}
                </div>
                <div class="shot-dialogue" v-if="shot.dialogue">
                  对白: {{ shot.dialogue }}
                </div>
              </div>
            </div>
          </div>
        </el-tab-pane>
        
        <el-tab-pane label="列表视图" name="list">
          <ShotListView 
            :shots="shots" 
            :field-config="fieldConfig"
            :readonly="true"
          />
        </el-tab-pane>
        
        <el-tab-pane label="幻灯片视图" name="slide">
          <ShotSlideView 
            :shots="shots" 
            :field-config="fieldConfig"
            :readonly="true"
          />
        </el-tab-pane>
      </el-tabs>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, computed } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'
import { ArrowLeft, Download, Share, Picture, CopyDocument } from '@element-plus/icons-vue'
import ShotListView from '@/components/ShotListView.vue'
import ShotSlideView from '@/components/ShotSlideView.vue'
import api from '@/utils/api'

const route = useRoute()
const router = useRouter()

// 响应式数据
const scriptInfo = ref(null)
const shots = ref([])
const fieldConfig = ref({})
const activeView = ref('preview')

// 获取脚本数据
const fetchScriptData = async () => {
  try {
    console.log('🔍 开始获取脚本数据...')
    console.log('🔍 脚本ID:', route.params.scriptId)
    
    const scriptId = route.params.scriptId
    if (!scriptId) {
      ElMessage.error('脚本ID无效')
      router.push('/script-square')
      return
    }
    
    // 调用公开脚本API
    const response = await api.get(`/project/public/${scriptId}`)
    console.log('🔍 API响应:', response.data)
    
    if (response.data && response.data.code === 200) {
      const script = response.data.data
      scriptInfo.value = script
      shots.value = script.shots || []
      fieldConfig.value = script.field_config || {}
      console.log('✅ 脚本数据获取成功:', script)
    } else {
      ElMessage.error('获取脚本数据失败')
      router.push('/script-square')
    }
  } catch (error) {
    console.error('获取脚本数据失败:', error)
    
    if (error.response) {
      const { status, data } = error.response
      if (status === 404) {
        ElMessage.error('脚本不存在或未公开')
      } else {
        ElMessage.error(`获取数据失败: ${data?.message || '未知错误'}`)
      }
    } else {
      ElMessage.error('获取脚本数据失败')
    }
    
    router.push('/script-square')
  }
}

// 视图切换处理
const handleViewChange = (viewName) => {
  console.log('🔍 切换到视图:', viewName)
  activeView.value = viewName
}

// 返回脚本广场
const goBack = () => {
  router.push('/script-square')
}

// 导出PDF
const exportPDF = () => {
  ElMessage.info('PDF导出功能开发中...')
}

// 分享脚本
const shareScript = () => {
  if (!scriptInfo.value) {
    ElMessage.error('脚本信息不完整，无法分享')
    return
  }
  
  // 生成分享链接（永久有效）
  const shareUrl = `${window.location.origin}/script-preview/${route.params.scriptId}`
  
  // 复制链接到剪贴板
  navigator.clipboard.writeText(shareUrl).then(() => {
    ElMessage.success('分享链接已复制到剪贴板！链接永久有效')
  }).catch(() => {
    // 如果剪贴板API不可用，显示链接
    ElMessage.info(`分享链接：${shareUrl}`)
  })
}

// 一键同款 - 复制到我的项目
const createSameScript = async () => {
  if (!scriptInfo.value) {
    ElMessage.error('脚本信息不完整，无法创建同款')
    return
  }
  
  try {
    await ElMessageBox.confirm(
      `确定要将 "${scriptInfo.value.description || '未命名脚本'}" 复制到自己的项目中吗？`,
      '确认操作',
      {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }
    )
    
    const response = await api.post('/project/copy', {
      sourceProjectId: scriptInfo.value.project_id
    })
    
    if (response.data.code === 200) {
      ElMessage.success('复制成功，请到项目列表查看')
      router.push('/projects')
    } else {
      ElMessage.error(response.data.message || '复制失败')
    }
  } catch (error) {
    if (error !== 'cancel') {
      // 更好地处理错误信息
      const errorMessage = error.response?.data?.message || error.message || '复制失败'
      ElMessage.error(errorMessage)
      console.error('复制失败:', error)
    }
  }
}

// 获取图片URL
const getImageUrl = (imagePath) => {
  if (!imagePath) return ''
  if (imagePath.startsWith('http')) return imagePath
  
  // 移除开头的斜杠，避免重复路径
  let cleanPath = imagePath
  if (cleanPath.startsWith('/')) {
    cleanPath = cleanPath.substring(1)
  }
  
  // 如果路径已经包含uploads，直接拼接
  if (cleanPath.startsWith('uploads/')) {
    return `${import.meta.env.VITE_API_BASE_URL || 'http://127.0.0.1:3002'}/${cleanPath}`
  }
  
  // 否则添加uploads前缀
  return `${import.meta.env.VITE_API_BASE_URL || 'http://127.0.0.1:3002'}/uploads/${cleanPath}`
}

// 页面加载时获取数据
onMounted(() => {
  fetchScriptData()
})
</script>

<style scoped>
.script-preview-container {
  min-height: 100vh;
  background: #f5f5f5;
}

.toolbar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 16px 24px;
  background: white;
  border-bottom: 1px solid #e4e7ed;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.toolbar-left {
  display: flex;
  align-items: center;
  gap: 16px;
}

.toolbar-right {
  display: flex;
  align-items: center;
  gap: 16px;
}

.toolbar-right .el-button {
  transition: all 0.3s ease;
}

.toolbar-right .el-button:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
}

.toolbar-right .el-button--primary {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  border: none;
  font-weight: 600;
}

.toolbar-right .el-button--primary:hover {
  background: linear-gradient(135deg, #764ba2 0%, #667eea 100%);
  transform: translateY(-2px) scale(1.05);
  box-shadow: 0 6px 20px rgba(102, 126, 234, 0.4);
}

.script-title {
  font-size: 18px;
  font-weight: 600;
  color: #303133;
}

.script-header {
  background: white;
  padding: 24px;
  border-bottom: 1px solid #e4e7ed;
}

.script-info h1 {
  margin: 0 0 16px 0;
  font-size: 28px;
  color: #303133;
}

.script-meta {
  display: flex;
  gap: 24px;
  color: #606266;
}

.script-meta span {
  display: flex;
  align-items: center;
  gap: 4px;
}

.view-tabs {
  background: white;
  margin: 24px;
  border-radius: 8px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

.shots-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
  gap: 24px;
  padding: 24px;
}

.shot-card {
  background: white;
  border-radius: 8px;
  overflow: hidden;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  transition: transform 0.2s;
}

.shot-card:hover {
  transform: translateY(-2px);
}

.shot-image {
  height: 200px;
  background: #f5f5f5;
  display: flex;
  align-items: center;
  justify-content: center;
  overflow: hidden;
}

.shot-image img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.no-image {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 8px;
  color: #909399;
}

.shot-info {
  padding: 16px;
}

.shot-number {
  font-weight: 600;
  color: #303133;
  margin-bottom: 8px;
}

.shot-tag {
  color: #409eff;
  margin-bottom: 8px;
}

.shot-description,
.shot-dialogue {
  color: #606266;
  margin-bottom: 8px;
  line-height: 1.5;
}

/* 移动端适配 */
@media (max-width: 768px) {
  .toolbar {
    padding: 12px 16px;
  }
  
  .script-header {
    padding: 16px;
  }
  
  .script-info h1 {
    font-size: 24px;
  }
  
  .script-meta {
    flex-direction: column;
    gap: 8px;
  }
  
  .view-tabs {
    margin: 16px;
  }
  
  .shots-grid {
    grid-template-columns: 1fr;
    gap: 16px;
    padding: 16px;
  }
}
</style>
