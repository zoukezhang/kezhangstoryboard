<template>
  <div class="script-square-container">
    <!-- 顶部导航栏 -->
    <div class="header">
      <div class="header-content">
        <el-button 
          :icon="ArrowLeft"
          @click="goBack"
          class="back-btn"
        >
          返回
        </el-button>
        <h1 class="page-title">脚本广场</h1>
        <div class="header-actions">
          <el-button 
            type="primary" 
            :icon="Upload"
            @click="showPublishDialog = true"
            v-if="selectedProjectId"
          >
            发布到广场
          </el-button>
        </div>
      </div>
    </div>

    <div class="square-content">
      <!-- 项目选择区域 -->
      <div class="project-selector" v-if="userProjects.length > 0">
        <h2>选择要发布的项目</h2>
        <el-select 
          v-model="selectedProjectId" 
          placeholder="请选择项目"
          style="width: 300px"
        >
          <el-option
            v-for="project in userProjects"
            :key="project.id"
            :label="project.name"
            :value="project.id"
          />
        </el-select>
      </div>

      <!-- 脚本广场内容 -->
      <div class="scripts-grid">
        <h2>公开脚本</h2>
        
        <!-- 搜索和筛选区域 -->
        <div class="search-filter-section">
          <div class="search-box">
            <el-input
              v-model="searchKeyword"
              placeholder="搜索脚本标题或描述..."
              :prefix-icon="Search"
              clearable
              @input="handleSearch"
              style="width: 300px"
            />
          </div>
          
          <div class="filter-box">
            <el-select
              v-model="selectedCategory"
              placeholder="选择分类"
              clearable
              @change="handleCategoryChange"
              style="width: 200px"
            >
              <el-option label="全部" value="全部" />
              <el-option
                v-for="category in categories"
                :key="category"
                :label="category"
                :value="category"
              />
            </el-select>
          </div>
        </div>
        
        <div class="scripts-list" v-loading="loading">
          <div 
            class="script-card"
            v-for="script in publicScripts"
            :key="script.id"
          >
            <div class="script-header">
              <h3>{{ script.project_name }}</h3>
              <div class="script-meta">
                <span class="author">
                  <img 
                    v-if="script.author_avatar" 
                    :src="getImageUrl(script.author_avatar)" 
                    alt="作者头像" 
                    class="author-avatar"
                  />
                  作者: {{ script.author }}
                </span>
                <span class="shots-count">{{ script.shot_count }} 个镜头</span>
                <span class="publish-time">{{ formatDate(script.publish_time) }}</span>
              </div>
              <div class="script-category">
                <el-tag size="small" type="info">{{ script.category || '其他类别' }}</el-tag>
              </div>
            </div>
            
            <div class="script-preview">
              <div class="preview-image" v-if="script.preview_image">
                <img :src="getImageUrl(script.preview_image)" alt="预览图" />
              </div>
              <div class="no-preview" v-else>
                <el-icon size="40"><picture /></el-icon>
                <p>暂无预览图</p>
              </div>
            </div>
            
            <div class="script-description">
              <p>{{ script.description || '暂无描述' }}</p>
            </div>
            
            <div class="script-actions">
              <el-button 
                type="primary" 
                :icon="CopyDocument"
                @click="copyToMyProject(script)"
              >
                一键同款
              </el-button>
              <el-button 
                :icon="View"
                @click="previewScript(script)"
              >
                预览
              </el-button>
            </div>
          </div>
        </div>
        
        <div class="no-scripts" v-if="!loading && publicScripts.length === 0">
          <el-icon size="60"><document /></el-icon>
          <p>暂无公开脚本</p>
        </div>
      </div>

      <!-- 我的发布 -->
      <div class="scripts-grid" style="margin-top: 20px;">
        <h2>我的发布</h2>
        <div class="scripts-list" v-loading="myPublishedLoading">
          <div 
            class="script-card"
            v-for="item in myPublishedScripts"
            :key="item.id"
          >
            <div class="script-header">
              <h3>{{ item.project_name }}</h3>
              <div class="script-meta">
                <span class="author">我发布的</span>
                <span class="shots-count">{{ item.shot_count || 0 }} 个镜头</span>
                <span class="publish-time">发布时间: {{ formatDate(item.publish_time) }}</span>
              </div>
            </div>

            <div class="script-description">
              <p>{{ item.description || '暂无描述' }}</p>
            </div>

            <div class="script-actions">
              <el-button 
                type="danger" 
                :loading="deletingMap[item.project_id]"
                @click="deletePublished(item.project_id)"
              >
                删除发布
              </el-button>
              <el-button disabled>不可修改</el-button>
            </div>
          </div>
        </div>

        <div class="no-scripts" v-if="!myPublishedLoading && myPublishedScripts.length === 0">
          <el-icon size="60"><document /></el-icon>
          <p>你还没有发布到脚本广场的项目</p>
        </div>
      </div>
    </div>

    <!-- 发布到广场对话框 -->
    <el-dialog
      v-model="showPublishDialog"
      title="发布到脚本广场"
      width="500px"
    >
      <el-form :model="publishForm" label-width="80px">
        <el-form-item label="项目名称">
          <el-input v-model="publishForm.name" disabled />
        </el-form-item>
        
        <el-form-item label="分类">
          <el-select v-model="publishForm.category" placeholder="请选择分类" style="width: 100%">
            <el-option
              v-for="category in categories"
              :key="category"
              :label="category"
              :value="category"
            />
          </el-select>
        </el-form-item>
        
        <el-form-item label="描述">
          <el-input 
            v-model="publishForm.description" 
            type="textarea"
            :rows="3"
            placeholder="请输入项目描述"
          />
        </el-form-item>
      </el-form>
      
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="showPublishDialog = false">取消</el-button>
          <el-button 
            type="primary" 
            @click="publishToSquare"
            :loading="publishing"
          >
            发布
          </el-button>
        </span>
      </template>
    </el-dialog>

    <!-- 预览对话框 -->
    <el-dialog
      v-model="showPreviewDialog"
      title="脚本预览"
      width="80%"
      top="5vh"
    >
      <div class="preview-content" v-if="previewScriptData">
        <h2>{{ previewScriptData.name }}</h2>
        <div class="preview-meta">
          <span>作者: {{ previewScriptData.author }}</span>
          <span>镜头数: {{ previewScriptData.shot_count }}</span>
        </div>
        
        <div class="preview-shots">
          <div 
            class="preview-shot"
            v-for="(shot, index) in previewScriptData.shots"
            :key="shot.id"
          >
            <div class="shot-number">镜头 {{ index + 1 }}</div>
            <div class="shot-image" v-if="shot.image_url">
              <img :src="getImageUrl(shot.image_url)" alt="镜头图片" />
            </div>
            <div class="shot-info">
              <div class="shot-tag" v-if="shot.tag">标签: {{ shot.tag }}</div>
              <div class="shot-desc" v-if="shot.description">描述: {{ shot.description }}</div>
            </div>
          </div>
        </div>
      </div>
      
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="showPreviewDialog = false">关闭</el-button>
        </span>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, onMounted, watch, nextTick } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'
import { 
  ArrowLeft, Upload, CopyDocument, View, Picture, Document, Search
} from '@element-plus/icons-vue'
import { useUserStore } from '@/stores/user'
import { useProjectStore } from '@/stores/project'
import { useShotStore } from '@/stores/shot'
import api, { publicApi } from '@/utils/api'
import { formatDate, getImageUrl, debounce } from '@/utils/common'

const router = useRouter()
const userStore = useUserStore()
const projectStore = useProjectStore()
const shotStore = useShotStore()

const loading = ref(false)
const myPublishedLoading = ref(false)
const publishing = ref(false)
const userProjects = ref([])
const publicScripts = ref([])
const myPublishedScripts = ref([])
const selectedProjectId = ref('')
const showPublishDialog = ref(false)
const showPreviewDialog = ref(false)
const previewScriptData = ref(null)

const publishForm = ref({
  name: '',
  description: '',
  category: '其他类别'
})

const categories = ref([
  '生活记录', '知识科普', '娱乐搞笑', '情感故事', '美食制作', 
  '美妆穿搭', '旅行风景', '职场创业', '亲子母婴', '运动健康', '其他类别'
])
const selectedCategory = ref('全部')
const searchKeyword = ref('')

// 获取用户项目列表
const fetchUserProjects = async () => {
  try {
    const response = await api.get('/project/list')
    userProjects.value = response.data.data || []
    if (userProjects.value.length > 0) {
      selectedProjectId.value = userProjects.value[0].id
    }
  } catch (error) {
    ElMessage.error('获取项目列表失败')
    console.error('获取项目列表失败:', error)
  }
}

// 获取公开脚本
const fetchPublicScripts = async () => {
  loading.value = true
  try {
    const params = {}
    if (selectedCategory.value && selectedCategory.value !== '全部') {
      params.category = selectedCategory.value
    }
    if (searchKeyword.value && searchKeyword.value.trim()) {
      params.search = searchKeyword.value.trim()
    }
    
    const response = await publicApi.get('/project/public', { params })
    console.log('🔍 公开脚本API响应:', response.data)
    publicScripts.value = response.data.data || []
    console.log('📊 公开脚本数据:', publicScripts.value)
    
    // 检查每个脚本的数据完整性
    publicScripts.value.forEach((script, index) => {
      console.log(`📝 脚本 ${index + 1}:`, {
        id: script.id,
        project_id: script.project_id,
        project_name: script.project_name,
        author: script.author,
        shot_count: script.shot_count
      })
    })
  } catch (error) {
    ElMessage.error('获取公开脚本失败')
    console.error('获取公开脚本失败:', error)
  } finally {
    loading.value = false
  }
}

// 获取我的发布列表
const fetchMyPublished = async () => {
  myPublishedLoading.value = true
  try {
    const response = await api.get('/project/my-published')
    myPublishedScripts.value = response.data.data || []
  } catch (error) {
    ElMessage.error('获取我的发布列表失败')
    console.error('获取我的发布列表失败:', error)
  } finally {
    myPublishedLoading.value = false
  }
}

// 搜索和筛选方法
const handleSearch = debounce(async () => {
  await fetchPublicScripts()
}, 500)

const handleCategoryChange = async () => {
  await fetchPublicScripts()
}

// 发布到广场
const publishToSquare = async () => {
  if (!selectedProjectId.value) {
    ElMessage.warning('请先选择要发布的项目')
    return
  }
  
  publishing.value = true
  try {
    console.log('开始发布项目:', selectedProjectId.value)
    const response = await api.post('/project/publish', {
      projectId: selectedProjectId.value,
      description: publishForm.value.description,
      category: publishForm.value.category
    })
    
    console.log('发布响应:', response.data)
    const ok = response?.data?.success === true || response?.data?.code === 200
    if (ok) {
      ElMessage.success('发布成功')
      // 先关闭弹窗
      showPublishDialog.value = false
      // 刷新公开脚本列表（可选）
      await fetchPublicScripts()
      await fetchMyPublished()
      // 保持在脚本广场页面，不进行路由跳转
    } else {
      ElMessage.error(response.data.message || '发布失败')
    }
  } catch (error) {
    const msg = error?.response?.data?.message
    if (error?.response?.status === 400 && msg) {
      ElMessage.warning(msg)
    } else {
      ElMessage.error('发布失败')
    }
    console.error('发布失败:', error)
  } finally {
    publishing.value = false
  }
}

// 删除已发布
const deletingMap = ref({})
const deletePublished = async (projectId) => {
  try {
    await ElMessageBox.confirm(
      '确定要删除该项目的发布吗？删除后将不再出现在广场中。',
      '确认删除',
      { confirmButtonText: '确定', cancelButtonText: '取消', type: 'warning' }
    )
    deletingMap.value = { ...deletingMap.value, [projectId]: true }
    const res = await api.delete(`/project/publish/${projectId}`)
    if (res?.data) {
      ElMessage.success('删除成功')
      await fetchMyPublished()
      await fetchPublicScripts()
    }
  } catch (error) {
    if (error !== 'cancel') {
      ElMessage.error('删除失败')
      console.error('删除发布失败:', error)
    }
  } finally {
    deletingMap.value = { ...deletingMap.value, [projectId]: false }
  }
}

// 一键同款
const copyToMyProject = async (script) => {
  try {
    await ElMessageBox.confirm(
      `确定要将 "${script.project_name}" 复制到自己的项目中吗？`,
      '确认操作',
      {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }
    )
    
    const response = await api.post('/project/copy', {
      sourceProjectId: script.project_id
    })
    
    if (response.data.code === 200) {
      ElMessage.success('复制成功，请到项目列表查看')
      router.push('/projects')
    } else {
      ElMessage.error(response.data.message || '复制失败')
    }
  } catch (error) {
    if (error !== 'cancel') {
      // 更好地处理错误信息
      const errorMessage = error.response?.data?.message || error.message || '复制失败'
      ElMessage.error(errorMessage)
      console.error('复制失败:', error)
    }
  }
}

// 预览脚本
const previewScript = async (script) => {
  console.log('🔍 预览脚本:', script)
  console.log('🔍 脚本ID:', script.id)
  console.log('🔍 项目ID:', script.project_id)
  console.log('🔍 脚本完整数据:', script)
  
  if (!script.id) {
    ElMessage.error('脚本数据不完整，无法预览')
    console.error('❌ 脚本缺少 id:', script)
    return
  }
  
  // 跳转到脚本预览页面（使用新的路由）
  router.push({
    path: `/script-preview/${script.id}`
  })
}

// 返回
const goBack = () => {
  router.push('/projects')
}

//

// 监听选中的项目变化
const updatePublishForm = () => {
  const selectedProject = userProjects.value.find(p => p.id === selectedProjectId.value)
  if (selectedProject) {
    publishForm.value.name = selectedProject.name
    publishForm.value.description = selectedProject.name
    publishForm.value.category = '其他类别' // 重置分类
  }
}

onMounted(() => {
  fetchUserProjects()
  fetchPublicScripts()
  fetchMyPublished()
})

// 监听选中项目变化
watch(selectedProjectId, updatePublishForm)

</script>

<style scoped>
.script-square-container {
  min-height: 100vh;
  background: #f5f5f5;
  display: flex;
  flex-direction: column;
}

.header {
  background: white;
  border-bottom: 1px solid #e4e7ed;
  padding: 0 20px;
}

.header-content {
  max-width: 1200px;
  margin: 0 auto;
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: 60px;
  gap: 20px;
}

.back-btn {
  background: none;
  border: none;
  padding: 8px 16px;
  border-radius: 4px;
  transition: background-color 0.3s;
}

.back-btn:hover {
  background: #f5f7fa;
}

.page-title {
  margin: 0;
  font-size: 20px;
  font-weight: 600;
  color: #303133;
}

.header-actions {
  display: flex;
  gap: 10px;
}

.square-content {
  flex: 1;
  padding: 20px;
  max-width: 1200px;
  margin: 0 auto;
  width: 100%;
}

.project-selector {
  background: white;
  border-radius: 8px;
  padding: 20px;
  margin-bottom: 20px;
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
}

.project-selector h2 {
  margin: 0 0 15px 0;
  color: #303133;
  font-size: 18px;
  font-weight: 600;
}

.scripts-grid {
  background: white;
  border-radius: 8px;
  padding: 20px;
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
}

.scripts-grid h2 {
  margin: 0 0 20px 0;
  color: #303133;
  font-size: 18px;
  font-weight: 600;
}

.search-filter-section {
  display: flex;
  gap: 20px;
  margin-bottom: 20px;
  align-items: center;
  flex-wrap: wrap;
}

.search-box {
  flex: 1;
  min-width: 300px;
}

.filter-box {
  min-width: 200px;
}

.script-category {
  margin-top: 10px;
}

.script-category .el-tag {
  font-size: 12px;
}

.scripts-list {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
  gap: 20px;
}

.script-card {
  border: 1px solid #e4e7ed;
  border-radius: 8px;
  overflow: hidden;
  transition: all 0.3s ease;
}

.script-card:hover {
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
  transform: translateY(-2px);
}

.script-header {
  padding: 15px;
  border-bottom: 1px solid #f0f0f0;
}

.script-header h3 {
  margin: 0 0 10px 0;
  color: #303133;
  font-size: 16px;
  font-weight: 600;
}

.script-meta {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
  font-size: 12px;
  color: #909399;
}

.author-avatar {
  width: 18px;
  height: 18px;
  border-radius: 50%;
  object-fit: cover;
  margin-right: 6px;
  vertical-align: middle;
}

.script-preview {
  padding: 15px;
  border-bottom: 1px solid #f0f0f0;
}

.preview-image {
  width: 100%;
  height: 150px;
  display: flex;
  align-items: center;
  justify-content: center;
  overflow: hidden;
  border-radius: 4px;
  background: #f5f5f5;
}

.preview-image img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.no-preview {
  width: 100%;
  height: 150px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  color: #ccc;
  background: #f9f9f9;
  border-radius: 4px;
}

.no-preview p {
  margin: 10px 0 0 0;
  font-size: 14px;
}

.script-description {
  padding: 15px;
  border-bottom: 1px solid #f0f0f0;
  min-height: 60px;
}

.script-description p {
  margin: 0;
  color: #606266;
  font-size: 14px;
  line-height: 1.5;
}

.script-actions {
  padding: 15px;
  display: flex;
  gap: 10px;
}

.script-actions .el-button {
  flex: 1;
}

.no-scripts {
  text-align: center;
  padding: 60px 20px;
  color: #999;
}

.no-scripts p {
  margin-top: 20px;
  font-size: 16px;
}

/* 预览对话框样式 */
.preview-content h2 {
  margin: 0 0 15px 0;
  color: #303133;
}

.preview-meta {
  display: flex;
  gap: 20px;
  margin-bottom: 20px;
  padding: 10px 0;
  border-bottom: 1px solid #e4e7ed;
  color: #606266;
}

.preview-shots {
  max-height: 60vh;
  overflow-y: auto;
}

.preview-shot {
  display: flex;
  gap: 15px;
  padding: 15px;
  border: 1px solid #e4e7ed;
  border-radius: 6px;
  margin-bottom: 15px;
}

.shot-number {
  width: 60px;
  height: 60px;
  background: #409eff;
  color: white;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: 600;
  flex-shrink: 0;
}

.shot-image {
  width: 120px;
  height: 80px;
  border: 1px solid #e4e7ed;
  border-radius: 4px;
  overflow: hidden;
  display: flex;
  align-items: center;
  justify-content: center;
  background: #f5f5f5;
}

.shot-image img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.shot-info {
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 5px;
}

.shot-tag,
.shot-desc {
  font-size: 14px;
  color: #606266;
}

/* 响应式设计 */
@media (max-width: 768px) {
  .header-content {
    flex-direction: column;
    height: auto;
    padding: 15px 0;
  }
  
  .header-actions {
    width: 100%;
    justify-content: center;
  }
  
  .square-content {
    padding: 10px;
  }
  
  .scripts-list {
    grid-template-columns: 1fr;
  }
  
  .preview-shot {
    flex-direction: column;
  }
  
  .shot-number {
    width: 40px;
    height: 40px;
    font-size: 14px;
  }
  
  .shot-image {
    width: 100%;
    height: 120px;
  }
}
</style>