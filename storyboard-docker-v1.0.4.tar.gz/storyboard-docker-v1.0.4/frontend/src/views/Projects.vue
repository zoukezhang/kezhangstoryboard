<template>
  <div class="projects-container">
    <!-- 顶部导航栏 -->
    <div class="header">
      <div class="header-content">
        <h1 class="site-title">科长分镜故事板</h1>
        <div class="user-info">
          <span>ID: {{ userStore.user?.id || '未知' }}</span>
          <el-dropdown @command="handleCommand">
            <span class="user-name">
              {{ userStore.user?.username || '用户' }}
              <el-icon><arrow-down /></el-icon>
            </span>
            <template #dropdown>
              <el-dropdown-menu>
                <el-dropdown-item command="profile">个人设置</el-dropdown-item>
                <el-dropdown-item command="logout">退出登录</el-dropdown-item>
              </el-dropdown-menu>
            </template>
          </el-dropdown>
        </div>
      </div>
    </div>

    <!-- 主内容区 -->
    <div class="main-content">
      <!-- 操作区 -->
      <div class="actions">
        <el-button 
          type="primary" 
          size="large"
          :icon="Plus"
          @click="showCreateDialog = true"
        >
          新建故事板
        </el-button>
        <el-button 
          type="success" 
          size="large"
          :icon="Collection"
          @click="goToScriptSquare"
        >
          脚本广场
        </el-button>
      </div>

      <!-- 项目列表 -->
      <div class="projects-grid" v-loading="projectStore.loading">
        <div 
          v-for="project in projectStore.projects" 
          :key="project.id"
          class="project-card"
          @click="editProject(project.id)"
        >
          <div class="card-content">
            <div class="project-thumbnail">
              <img 
                v-if="project.thumbnail && !imageLoadFailed[project.id]" 
                :src="getImageUrl(project.thumbnail)" 
                alt="项目缩略图"
                class="thumbnail-image"
                @error="() => handleImageError(project.id)"
              />
              <div v-if="!project.thumbnail || imageLoadFailed[project.id]" class="default-thumbnail">
                <el-icon size="48"><film /></el-icon>
              </div>
            </div>
            <h3 class="project-name" @click.stop="editProjectName(project)" :title="'点击编辑项目名称'">
              <el-icon class="edit-name-icon"><edit /></el-icon>
              {{ project.name }}
            </h3>
            <div class="project-info">
              <p class="create-time">创建时间: {{ formatDate(project.create_time) }}</p>
              <p class="shot-count">镜头数: {{ project.shot_count || 0 }}</p>
            </div>
          </div>
          <div class="card-actions" @click.stop>
            <el-button 
              type="primary" 
              size="small"
              @click="editProject(project.id)"
            >
              编辑
            </el-button>
            <el-button 
              type="danger" 
              size="small"
              @click="deleteProject(project)"
            >
              删除
            </el-button>
          </div>
        </div>

        <!-- 空状态 -->
        <div v-if="!projectStore.loading && projectStore.projects.length === 0" class="empty-state">
          <el-icon size="64" color="#ccc"><document /></el-icon>
          <p>还没有项目，点击上方按钮创建第一个故事板吧！</p>
        </div>
      </div>
    </div>

    <!-- 底部 -->
    <div class="footer">
      <p>&copy; 2025 科长分镜故事板 - 专业的分镜创作平台</p>
    </div>

    <!-- 编辑项目名称对话框 -->
    <el-dialog
      v-model="showEditDialog"
      title="编辑项目名称"
      width="400px"
    >
      <el-form ref="editFormRef" :model="editForm" :rules="editRules">
        <el-form-item label="项目名称" prop="name">
          <el-input 
            v-model="editForm.name" 
            placeholder="请输入项目名称"
            @keyup.enter="updateProjectName"
          />
        </el-form-item>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="showEditDialog = false">取消</el-button>
          <el-button 
            type="primary" 
            :loading="editLoading"
            @click="updateProjectName"
          >
            保存
          </el-button>
        </span>
      </template>
    </el-dialog>
    <el-dialog
      v-model="showCreateDialog"
      title="新建故事板"
      width="400px"
    >
      <el-form ref="createFormRef" :model="createForm" :rules="createRules">
        <el-form-item label="项目名称" prop="name">
          <el-input 
            v-model="createForm.name" 
            placeholder="请输入项目名称"
            @keyup.enter="createProject"
          />
        </el-form-item>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="showCreateDialog = false">取消</el-button>
          <el-button 
            type="primary" 
            :loading="createLoading"
            @click="createProject"
          >
            创建
          </el-button>
        </span>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Plus, ArrowDown, Film, Document, Edit, Collection } from '@element-plus/icons-vue'
import { useUserStore } from '@/stores/user'
import { useProjectStore } from '@/stores/project'
import api from '@/utils/api'
import { formatDate, getImageUrl } from '@/utils/common'

const router = useRouter()
const userStore = useUserStore()
const projectStore = useProjectStore()

const createLoading = ref(false)
const showCreateDialog = ref(false)
const editLoading = ref(false)
const showEditDialog = ref(false)
const currentEditProject = ref(null)

const createFormRef = ref()
const createForm = reactive({
  name: ''
})

const editFormRef = ref()
const editForm = reactive({
  name: ''
})

const createRules = {
  name: [
    { required: true, message: '请输入项目名称', trigger: 'blur' },
    { min: 1, max: 50, message: '项目名称长度在 1 到 50 个字符', trigger: 'blur' }
  ]
}

const editRules = {
  name: [
    { required: true, message: '请输入项目名称', trigger: 'blur' },
    { min: 1, max: 50, message: '项目名称长度在 1 到 50 个字符', trigger: 'blur' }
  ]
}

// 获取项目列表
const fetchProjects = async () => {
  // 重置图片加载失败状态
  imageLoadFailed.value = {}
  const result = await projectStore.fetchProjects()
  if (!result.success) {
    ElMessage.error(result.message)
  }
}

// 创建项目
const createProject = async () => {
  if (!createFormRef.value) return
  
  await createFormRef.value.validate(async (valid) => {
    if (valid) {
      createLoading.value = true
      try {
        const result = await projectStore.createProject(createForm.name)
        if (result.success) {
          ElMessage.success(result.message)
          showCreateDialog.value = false
          createForm.name = ''
        } else {
          ElMessage.error(result.message)
        }
      } finally {
        createLoading.value = false
      }
    }
  })
}

// 编辑项目名称
const editProjectName = (project) => {
  currentEditProject.value = project
  editForm.name = project.name
  showEditDialog.value = true
}

// 更新项目名称
const updateProjectName = async () => {
  if (!editFormRef.value) return
  
  await editFormRef.value.validate(async (valid) => {
    if (valid) {
      editLoading.value = true
      try {
        const result = await projectStore.updateProject(currentEditProject.value.id, editForm.name)
        if (result.success) {
          ElMessage.success(result.message)
          showEditDialog.value = false
          editForm.name = ''
          currentEditProject.value = null
        } else {
          ElMessage.error(result.message)
        }
      } finally {
        editLoading.value = false
      }
    }
  })
}

// 编辑项目
const editProject = (projectId) => {
  router.push(`/edit/${projectId}`)
}

// 删除项目
const deleteProject = async (project) => {
  try {
    await ElMessageBox.confirm(
      `确定要删除项目"${project.name}"吗？此操作不可恢复。`,
      '确认删除',
      {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }
    )
    
    const result = await projectStore.deleteProject(project.id)
    if (result.success) {
      ElMessage.success(result.message)
    } else {
      ElMessage.error(result.message)
    }
  } catch (error) {
    if (error !== 'cancel') {
      ElMessage.error('删除项目失败')
    }
  }
}

// 用于跟踪图片加载失败的项目
const imageLoadFailed = ref({})

// 处理缩略图加载错误
const handleImageError = (projectId) => {
  imageLoadFailed.value = {
    ...imageLoadFailed.value,
    [projectId]: true
  }
}

// 跳转到脚本广场
const goToScriptSquare = () => {
  router.push('/script-square')
}

// 处理用户菜单
const handleCommand = (command) => {
  if (command === 'logout') {
    userStore.logout()
    router.push('/login')
  } else if (command === 'profile') {
    router.push('/profile')
  }
}

onMounted(async () => {
  await userStore.getCurrentUser()
  await fetchProjects()
})
</script>

<style scoped>
.projects-container {
  min-height: 100vh;
  display: flex;
  flex-direction: column;
}

.header {
  background: white;
  border-bottom: 1px solid #e4e7ed;
  padding: 0 20px;
}

.header-content {
  max-width: 1200px;
  margin: 0 auto;
  display: flex;
  justify-content: space-between;
  align-items: center;
  height: 60px;
}

.site-title {
  color: #409eff;
  font-size: 24px;
  margin: 0;
}

.user-info {
  display: flex;
  align-items: center;
  gap: 15px;
  color: #666;
}

.user-name {
  cursor: pointer;
  color: #409eff;
  display: flex;
  align-items: center;
  gap: 5px;
}

.main-content {
  flex: 1;
  max-width: 1200px;
  margin: 0 auto;
  padding: 30px 20px;
  width: 100%;
}

.actions {
  margin-bottom: 30px;
  display: flex;
  gap: 15px;
  flex-wrap: wrap;
}

.projects-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
  gap: 20px;
  min-height: 200px;
}

.project-card {
  background: white;
  border-radius: 8px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  transition: all 0.3s ease;
  cursor: pointer;
  overflow: hidden;
}

.project-card:hover {
  transform: translateY(-4px);
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.15);
}

.card-content {
  padding: 20px;
}

.project-icon {
  text-align: center;
  margin-bottom: 15px;
  color: #409eff;
}

.project-thumbnail {
  position: relative;
  width: 100%;
  aspect-ratio: 16 / 9;
  margin-bottom: 15px;
  border-radius: 6px;
  overflow: hidden;
  background: #f5f7fa;
}

.thumbnail-image {
  width: 100%;
  height: 100%;
  object-fit: cover;
  transition: transform 0.3s ease;
}

.project-card:hover .thumbnail-image {
  transform: scale(1.05);
}

.default-thumbnail {
  display: flex;
  align-items: center;
  justify-content: center;
  height: 100%;
  color: #c0c4cc;
  background: #f5f7fa;
}

.project-name {
  font-size: 18px;
  font-weight: 600;
  margin: 0 0 15px 0;
  text-align: center;
  color: #333;
  cursor: pointer;
  transition: color 0.3s ease;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 5px;
}

.project-name:hover {
  color: #409eff;
}

.edit-name-icon {
  opacity: 0;
  transition: opacity 0.3s ease;
  font-size: 14px;
}

.project-name:hover .edit-name-icon {
  opacity: 1;
}

.project-info {
  color: #666;
  font-size: 14px;
  line-height: 1.5;
}

.card-actions {
  padding: 15px 20px;
  background: #f8f9fa;
  border-top: 1px solid #e4e7ed;
  display: flex;
  gap: 10px;
  justify-content: center;
}

.empty-state {
  grid-column: 1 / -1;
  text-align: center;
  padding: 60px 20px;
  color: #999;
}

.empty-state p {
  margin-top: 20px;
  font-size: 16px;
}

.footer {
  background: #f8f9fa;
  text-align: center;
  padding: 20px;
  border-top: 1px solid #e4e7ed;
  color: #666;
  margin-top: auto;
}
</style>