<template>
  <div class="profile-container">
    <!-- 顶部导航栏 -->
    <div class="header">
      <div class="header-content">
        <el-button 
          :icon="ArrowLeft"
          @click="goBack"
          class="back-btn"
        >
          返回
        </el-button>
        <h1 class="page-title">个人设置</h1>
      </div>
    </div>

    <div class="profile-content">
      <div class="profile-card">
        <!-- 用户头像 -->
        <div class="avatar-section">
          <h2>头像设置</h2>
          <div class="avatar-content">
            <div class="avatar-preview">
              <img 
                v-if="userInfo.avatar_url" 
                :src="getImageUrl(userInfo.avatar_url)" 
                alt="用户头像"
                class="avatar-image"
              />
              <div v-else class="avatar-placeholder">
                <el-icon size="40"><user /></el-icon>
              </div>
            </div>
            <div class="avatar-actions">
              <el-button 
                type="primary" 
                @click="avatarInputRef?.click()"
              >
                上传头像
              </el-button>
              <el-button 
                @click="removeAvatar"
                :disabled="!userInfo.avatar_url"
              >
                移除头像
              </el-button>
            </div>
            <input 
              ref="avatarInputRef"
              type="file" 
              accept="image/*" 
              style="display: none"
              @change="handleAvatarUpload"
            />
          </div>
        </div>

        <!-- 用户基本信息 -->
        <div class="user-info-section">
          <h2>基本信息</h2>
          <div class="info-grid">
            <div class="info-item">
              <label>用户名</label>
              <div class="info-value">{{ userInfo.username }}</div>
            </div>
            <div class="info-item">
              <label>昵称</label>
              <div class="info-value" style="display:flex;gap:10px;align-items:center;">
                <el-input v-model="nickname" placeholder="请输入昵称" style="max-width:240px" />
                <el-button type="primary" size="small" :loading="savingNickname" @click="saveNickname">保存</el-button>
              </div>
            </div>
            <div class="info-item">
              <label>邮箱</label>
              <div class="info-value">{{ userInfo.email }}</div>
            </div>
            <div class="info-item">
              <label>注册时间</label>
              <div class="info-value">{{ formatDate(userInfo.register_time) }}</div>
            </div>
            <div class="info-item">
              <label>项目数量</label>
              <div class="info-value">{{ userInfo.project_count || 0 }} 个</div>
            </div>
            <div class="info-item">
              <label>总镜头数</label>
              <div class="info-value">{{ userInfo.total_shots || 0 }} 个</div>
            </div>
          </div>
        </div>

        <!-- 修改密码区域 -->
        <div class="password-section">
          <h2>修改密码</h2>
          <el-form 
            ref="passwordFormRef" 
            :model="passwordForm" 
            :rules="passwordRules"
            label-width="120px"
            class="password-form"
          >
            <el-form-item label="当前密码" prop="currentPassword">
              <el-input
                v-model="passwordForm.currentPassword"
                type="password"
                placeholder="请输入当前密码"
                show-password
                :prefix-icon="Lock"
              />
            </el-form-item>

            <el-form-item label="新密码" prop="newPassword">
              <el-input
                v-model="passwordForm.newPassword"
                type="password"
                placeholder="请输入新密码（至少6位）"
                show-password
                :prefix-icon="Lock"
              />
            </el-form-item>

            <el-form-item label="确认新密码" prop="confirmPassword">
              <el-input
                v-model="passwordForm.confirmPassword"
                type="password"
                placeholder="请再次输入新密码"
                show-password
                :prefix-icon="Lock"
                @keyup.enter="changePassword"
              />
            </el-form-item>

            <el-form-item>
              <el-button 
                type="primary" 
                :loading="changePasswordLoading"
                @click="changePassword"
              >
                修改密码
              </el-button>
              <el-button @click="resetPasswordForm">
                重置
              </el-button>
            </el-form-item>
          </el-form>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'
import { ArrowLeft, Lock, User } from '@element-plus/icons-vue'
import { useUserStore } from '@/stores/user'
import { formatDate, getImageUrl } from '@/utils/common'

const router = useRouter()
const userStore = useUserStore()

const passwordFormRef = ref()
const avatarInputRef = ref()
const changePasswordLoading = ref(false)
const userInfo = ref({})
const nickname = ref('')
const savingNickname = ref(false)

// 密码表单
const passwordForm = reactive({
  currentPassword: '',
  newPassword: '',
  confirmPassword: ''
})

// 密码验证规则
const validateConfirmPassword = (rule, value, callback) => {
  if (value === '') {
    callback(new Error('请再次输入新密码'))
  } else if (value !== passwordForm.newPassword) {
    callback(new Error('两次输入密码不一致'))
  } else {
    callback()
  }
}

const passwordRules = {
  currentPassword: [
    { required: true, message: '请输入当前密码', trigger: 'blur' }
  ],
  newPassword: [
    { required: true, message: '请输入新密码', trigger: 'blur' },
    { min: 6, message: '新密码长度至少6位', trigger: 'blur' }
  ],
  confirmPassword: [
    { required: true, validator: validateConfirmPassword, trigger: 'blur' }
  ]
}

// 获取用户信息
const fetchUserInfo = async () => {
  try {
    const user = await userStore.getCurrentUser()
    if (user) {
      userInfo.value = user
      nickname.value = user.display_name || user.nickname || user.username || ''
    }
  } catch (error) {
    ElMessage.error('获取用户信息失败')
    console.error('获取用户信息失败:', error)
  }
}

// 保存昵称
const saveNickname = async () => {
  if (!nickname.value || nickname.value.trim().length === 0) {
    ElMessage.warning('请输入昵称')
    return
  }
  savingNickname.value = true
  try {
    const result = await userStore.updateNickname(nickname.value.trim())
    if (result.success) {
      ElMessage.success('昵称已更新')
      await fetchUserInfo()
    } else {
      ElMessage.error(result.message || '昵称更新失败')
    }
  } finally {
    savingNickname.value = false
  }
}

// 修改密码
const changePassword = async () => {
  if (!passwordFormRef.value) return
  
  await passwordFormRef.value.validate(async (valid) => {
    if (valid) {
      changePasswordLoading.value = true
      try {
        const result = await userStore.changePassword({
          currentPassword: passwordForm.currentPassword,
          newPassword: passwordForm.newPassword
        })
        
        if (result.success) {
          ElMessage.success('密码修改成功')
          resetPasswordForm()
        } else {
          ElMessage.error(result.message || '密码修改失败')
        }
      } catch (error) {
        ElMessage.error('密码修改失败，请重试')
        console.error('修改密码失败:', error)
      } finally {
        changePasswordLoading.value = false
      }
    }
  })
}

// 重置密码表单
const resetPasswordForm = () => {
  passwordForm.currentPassword = ''
  passwordForm.newPassword = ''
  passwordForm.confirmPassword = ''
  passwordFormRef.value?.clearValidate()
}

// 返回
const goBack = () => {
  router.push('/projects')
}

onMounted(() => {
  fetchUserInfo()
})

// 处理头像上传
const handleAvatarUpload = async (event) => {
  const file = event.target.files[0]
  if (!file) return

  // 检查文件类型
  if (!file.type.startsWith('image/')) {
    ElMessage.error('请选择图片文件')
    return
  }

  // 检查文件大小 (5MB)
  if (file.size > 5 * 1024 * 1024) {
    ElMessage.error('头像文件大小不能超过5MB')
    return
  }

  try {
    const result = await userStore.uploadAvatar(file)
    if (result.success) {
      ElMessage.success('头像上传成功')
      // 刷新用户信息并避免缓存
      await fetchUserInfo()
      userInfo.value.avatar_url = `${result.avatarUrl}?t=${Date.now()}`
    } else {
      ElMessage.error(result.message || '头像上传失败')
    }
  } catch (error) {
    ElMessage.error('头像上传失败，请重试')
    console.error('头像上传失败:', error)
  } finally {
    // 清空文件输入
    event.target.value = ''
  }
}

// 移除头像
const removeAvatar = async () => {
  try {
    await ElMessageBox.confirm(
      '确定要移除当前头像吗？',
      '确认操作',
      {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }
    )

    const result = await userStore.deleteAvatar()
    if (result.success) {
      ElMessage.success('头像移除成功')
      // 刷新用户信息
      await fetchUserInfo()
    } else {
      ElMessage.error(result.message || '头像移除失败')
    }
  } catch (error) {
    if (error !== 'cancel') {
      ElMessage.error('头像移除失败，请重试')
      console.error('头像移除失败:', error)
    }
  }
}
</script>

<style scoped>
.profile-container {
  min-height: 100vh;
  background: #f5f5f5;
  display: flex;
  flex-direction: column;
}

.header {
  background: white;
  border-bottom: 1px solid #e4e7ed;
  padding: 0 20px;
}

.header-content {
  max-width: 1200px;
  margin: 0 auto;
  display: flex;
  align-items: center;
  height: 60px;
  gap: 20px;
}

.back-btn {
  background: none;
  border: none;
  padding: 8px 16px;
  border-radius: 4px;
  transition: background-color 0.3s;
}

.back-btn:hover {
  background: #f5f7fa;
}

.page-title {
  margin: 0;
  font-size: 20px;
  font-weight: 600;
  color: #303133;
}

.profile-content {
  flex: 1;
  padding: 20px;
  max-width: 800px;
  margin: 0 auto;
  width: 100%;
}

.profile-card {
  background: white;
  border-radius: 8px;
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
  overflow: hidden;
}

.user-info-section {
  padding: 30px;
  border-bottom: 1px solid #f0f0f0;
}

.user-info-section h2 {
  margin: 0 0 20px 0;
  color: #303133;
  font-size: 18px;
  font-weight: 600;
}

.info-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 20px;
}

.info-item {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.info-item label {
  color: #909399;
  font-size: 14px;
  font-weight: 500;
}

.info-value {
  color: #303133;
  font-size: 16px;
  font-weight: 400;
}

.password-section {
  padding: 30px;
}

.password-section h2 {
  margin: 0 0 20px 0;
  color: #303133;
  font-size: 18px;
  font-weight: 600;
}

.password-form {
  max-width: 500px;
}

.password-form .el-form-item {
  margin-bottom: 20px;
}

.password-form .el-input {
  width: 100%;
}

/* 响应式设计 */
@media (max-width: 768px) {
  .profile-content {
    padding: 10px;
  }
  
  .user-info-section,
  .password-section {
    padding: 20px;
  }
  
  .info-grid {
    grid-template-columns: 1fr;
  }
  
  .header-content {
    padding: 0 10px;
  }
  
  .password-form {
    max-width: 100%;
  }
}

/* 动画效果 */
.profile-card {
  animation: fadeIn 0.3s ease-out;
}

@keyframes fadeIn {
  from {
    opacity: 0;
    transform: translateY(20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

/* 表单样式优化 */
.password-form .el-form-item__label {
  color: #606266;
  font-weight: 500;
}

.password-form .el-button {
  margin-right: 10px;
}

.password-form .el-button--primary {
  background: #409eff;
  border-color: #409eff;
}

.password-form .el-button--primary:hover {
  background: #66b1ff;
  border-color: #66b1ff;
}

/* 头像设置样式 */
.avatar-section {
  padding: 30px;
  border-bottom: 1px solid #f0f0f0;
}

.avatar-section h2 {
  margin: 0 0 20px 0;
  color: #303133;
  font-size: 18px;
  font-weight: 600;
}

.avatar-content {
  display: flex;
  align-items: center;
  gap: 30px;
}

.avatar-preview {
  width: 120px;
  height: 120px;
  border-radius: 50%;
  overflow: hidden;
  border: 2px solid #e4e7ed;
  display: flex;
  align-items: center;
  justify-content: center;
}

.avatar-image {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.avatar-placeholder {
  width: 100%;
  height: 100%;
  background: #f5f7fa;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #c0c4cc;
}

.avatar-actions {
  display: flex;
  gap: 15px;
}

/* 响应式设计 */
@media (max-width: 768px) {
  .avatar-content {
    flex-direction: column;
    align-items: flex-start;
    gap: 15px;
  }
  
  .avatar-actions {
    align-self: stretch;
    justify-content: center;
  }
}
</style>