import axios from 'axios'
import { ElMessage } from 'element-plus'

// 创建axios实例
const apiBaseURL = import.meta.env.VITE_API_BASE_URL
console.log('🔍 API基础地址:', apiBaseURL)

const api = axios.create({
  baseURL: apiBaseURL ? `${apiBaseURL}/api` : '/api',
  timeout: 10000,
  withCredentials: true // 支持跨域请求携带cookie
})

// 创建用于公开接口的axios实例（不带身份验证）
const publicApi = axios.create({
  baseURL: apiBaseURL ? `${apiBaseURL}/api` : '/api',
  timeout: 10000
})

// 请求拦截器
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token')
    if (token) {
      config.headers.Authorization = `Bearer ${token}`
    }
    return config
  },
  (error) => {
    return Promise.reject(error)
  }
)

// 响应拦截器
api.interceptors.response.use(
  (response) => {
    return response
  },
  (error) => {
    if (error.response) {
      const { status, data } = error.response
      const requestUrl = error.config?.url || ''
      
      console.error('API错误详情:', {
        url: requestUrl,
        status: status,
        statusText: error.response.statusText,
        errorData: data
      })
      
      if (status === 401) {
        // 对于登录接口，不进行自动跳转，让组件处理具体错误
        if (!requestUrl.includes('/user/login')) {
          localStorage.removeItem('token')
          window.location.href = '/login'
          ElMessage.error('登录已过期，请重新登录')
        }
      } else if (status === 403) {
        ElMessage.error('没有权限访问该资源')
      } else if (status === 500) {
        ElMessage.error('服务器错误，请稍后重试')
      } else if (status === 400) {
        // 特殊处理400错误，显示详细的验证错误信息
        console.error('400错误详情:', {
          status: error.response?.status,
          statusText: error.response?.statusText,
          data: error.response?.data,
          headers: error.response?.headers,
          config: error.config,
          message: error.message
        })
        if (data && data.data && Array.isArray(data.data)) {
          // 提取所有验证错误信息
          const errorMessages = data.data.map(err => {
            // 如果有字段名，显示字段名和错误信息
            if (err.param && err.msg) {
              return `${err.param}: ${err.msg}`
            }
            // 否则只显示错误信息
            return err.msg || '未知验证错误'
          }).join('\n')
          ElMessage.error(errorMessages || data.message || '输入数据验证失败')
        } else {
          ElMessage.error(data.message || '输入数据验证失败')
        }
      } else {
        // 对于登录接口，不在这里显示错误消息，让组件处理
        if (!requestUrl.includes('/user/login')) {
          ElMessage.error(data.message || '请求失败')
        }
      }
    } else {
      ElMessage.error('网络错误，请检查网络连接')
    }
    
    return Promise.reject(error)
  }
)

export default api
export { publicApi }