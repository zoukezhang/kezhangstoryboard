#!/bin/bash

# 分镜故事板 Docker 启动脚本 v1.0.4
# 作者: 科长分镜故事板
# 日期: 2025-08-29

echo "🎬 分镜故事板 v1.0.4 启动中..."
echo "=================================="

# 检查Docker是否运行
if ! docker info > /dev/null 2>&1; then
    echo "❌ 错误: Docker未运行，请先启动Docker Desktop"
    exit 1
fi

# 检查端口占用
if lsof -i :80 > /dev/null 2>&1; then
    echo "⚠️  警告: 端口80已被占用，请检查或修改配置"
fi

if lsof -i :3002 > /dev/null 2>&1; then
    echo "⚠️  警告: 端口3002已被占用，请检查或修改配置"
fi

echo "🔧 构建Docker镜像..."
docker-compose build

if [ $? -ne 0 ]; then
    echo "❌ 构建失败，请检查错误信息"
    exit 1
fi

echo "🚀 启动服务..."
docker-compose up -d

if [ $? -ne 0 ]; then
    echo "❌ 启动失败，请检查错误信息"
    exit 1
fi

echo "⏳ 等待服务启动..."
sleep 10

# 检查服务状态
echo "📊 服务状态:"
docker-compose ps

echo ""
echo "✅ 启动完成！"
echo "🌐 前端应用: http://localhost"
echo "🔌 后端API: http://localhost:3002"
echo ""
echo "📋 常用命令:"
echo "  查看日志: docker-compose logs -f"
echo "  停止服务: docker-compose down"
echo "  重启服务: docker-compose restart"
echo ""
echo "🎉 开始使用分镜故事板吧！"
