import { pool } from './database.js'

const initDatabase = async () => {
  try {
    // 创建用户表
    await pool.execute(`
      CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(50) NOT NULL,
        email VARCHAR(100) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL,
        avatar_url VARCHAR(500) DEFAULT NULL,
        register_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `)

    // 创建项目表
    await pool.execute(`
      CREATE TABLE IF NOT EXISTS projects (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        name VARCHAR(100) NOT NULL,
        shot_count INT DEFAULT 0,
        field_config TEXT,
        create_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        last_edit_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `)

    // 创建分镜表
    await pool.execute(`
      CREATE TABLE IF NOT EXISTS shots (
        id INT AUTO_INCREMENT PRIMARY KEY,
        project_id INT NOT NULL,
        sort_order INT NOT NULL DEFAULT 0,
        tag VARCHAR(100) DEFAULT '',
        description TEXT,
        image_url VARCHAR(500) DEFAULT '',
        duration TEXT,
        shot_type TEXT,
        dialogue TEXT,
        sound_effect TEXT,
        animation TEXT,
        camera_movement TEXT,
        scene TEXT,
        characters TEXT,
        character_state TEXT,
        narration TEXT,
        shooting_angle TEXT,
        create_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        update_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
        INDEX idx_project_sort (project_id, sort_order)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `)

    // 创建分享表
    await pool.execute(`
      CREATE TABLE IF NOT EXISTS shares (
        id INT AUTO_INCREMENT PRIMARY KEY,
        project_id INT NOT NULL,
        token VARCHAR(255) NOT NULL UNIQUE,
        expire_time TIMESTAMP NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `)

    // 创建脚本广场表
    await pool.execute(`
      CREATE TABLE IF NOT EXISTS script_square (
        id INT AUTO_INCREMENT PRIMARY KEY,
        project_id INT NOT NULL,
        user_id INT NOT NULL,
        description TEXT,
        is_public BOOLEAN DEFAULT TRUE,
        publish_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `)

    // 数据库迁移 - 将单数字段名改为复数字段名
    try {
      // 检查是否存在旧的character字段，如果存在则重命名为characters
      const [tableInfo] = await pool.execute("SHOW COLUMNS FROM shots LIKE 'character'");
      if (tableInfo.length > 0) {
        console.log('🔄 正在将character字段重命名为characters...');
        await pool.execute("ALTER TABLE shots CHANGE COLUMN `character` `characters` TEXT");
        console.log('✅ 字段重命名成功');
      }
    } catch (error) {
      console.log('ℹ️ 字段迁移信息:', error.message);
    }

    console.log('✅ 数据库表创建成功')
  } catch (error) {
    console.error('❌ 数据库初始化失败:', error)
    throw error
  }
}

export { initDatabase }