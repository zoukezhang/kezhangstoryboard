import mysql from 'mysql2/promise'
import dotenv from 'dotenv'
import path from 'path'
import { fileURLToPath } from 'url'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

dotenv.config({ path: path.join(__dirname, '../../.env') })

// 创建连接池
const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  port: process.env.DB_PORT || 3306,
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_DATABASE || 'storyboard',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
  charset: 'utf8mb4'
})

// 自动添加缺失的avatar_url字段
const addMissingAvatarUrlColumn = async () => {
  try {
    const connection = await pool.getConnection()
    console.log('🔍 检查是否需要添加avatar_url字段...')
    
    // 检查字段是否已存在
    const [columns] = await connection.execute("SHOW COLUMNS FROM users LIKE 'avatar_url'")
    
    if (columns.length === 0) {
      console.log('   正在添加avatar_url字段...')
      await connection.execute(`
        ALTER TABLE users 
        ADD COLUMN avatar_url VARCHAR(500) DEFAULT NULL AFTER password
      `)
      console.log('✅ avatar_url字段添加成功')
    } else {
      console.log('✅ avatar_url字段已存在，无需添加')
    }
    
    connection.release()
  } catch (error) {
    console.error('❌ 添加avatar_url字段失败:', error.message)
  }
}

// 自动添加缺失的nickname字段
const addMissingNicknameColumn = async () => {
  try {
    const connection = await pool.getConnection()
    console.log('🔍 检查是否需要添加nickname字段...')
    const [columns] = await connection.execute("SHOW COLUMNS FROM users LIKE 'nickname'")
    if (columns.length === 0) {
      console.log('   正在添加nickname字段...')
      await connection.execute(`
        ALTER TABLE users 
        ADD COLUMN nickname VARCHAR(100) DEFAULT NULL AFTER username
      `)
      console.log('✅ nickname字段添加成功')
    } else {
      console.log('✅ nickname字段已存在，无需添加')
    }
    connection.release()
  } catch (error) {
    console.error('❌ 添加nickname字段失败:', error.message)
  }
}

// 自动添加缺失的category字段到script_square表
const addMissingCategoryColumn = async () => {
  try {
    const connection = await pool.getConnection()
    console.log('🔍 检查是否需要添加category字段...')
    const [columns] = await connection.execute("SHOW COLUMNS FROM script_square LIKE 'category'")
    if (columns.length === 0) {
      console.log('   正在添加category字段...')
      await connection.execute(`
        ALTER TABLE script_square 
        ADD COLUMN category VARCHAR(50) DEFAULT '其他类别' AFTER description
      `)
      console.log('✅ category字段添加成功')
    } else {
      console.log('✅ category字段已存在，无需添加')
    }
    connection.release()
  } catch (error) {
    console.error('❌ 添加category字段失败:', error.message)
  }
}

// 测试数据库连接
const testConnection = async () => {
  try {
    const connection = await pool.getConnection()
    console.log('✅ 数据库连接成功')
    connection.release()
    
    // 自动添加缺失的字段
    await addMissingAvatarUrlColumn()
    await addMissingNicknameColumn()
    await addMissingCategoryColumn()
  } catch (error) {
    console.error('❌ 数据库连接失败:', error.message)
  }
}

export { pool, testConnection }