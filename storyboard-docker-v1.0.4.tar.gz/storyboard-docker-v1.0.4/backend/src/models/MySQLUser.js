import { pool } from '../config/database.js'

export class MySQLUser {
  // 创建用户
  static async create(userData) {
    const { username, email, password } = userData
    const [result] = await pool.execute(
      'INSERT INTO users (username, email, password) VALUES (?, ?, ?)',
      [username, email, password]
    )
    return result.insertId
  }

  // 根据邮箱查找用户
  static async findByEmail(email) {
    const [rows] = await pool.execute('SELECT * FROM users WHERE email = ?', [email])
    return rows[0] || null
  }

  // 根据ID查找用户
  static async findById(id) {
    // 首先检查avatar_url字段是否存在
    const [columns] = await pool.execute("SHOW COLUMNS FROM users LIKE 'avatar_url'")
    
    if (columns.length > 0) {
      // 如果字段存在，使用完整查询
      const [rows] = await pool.execute(
        'SELECT id, username, nickname, email, avatar_url, register_time FROM users WHERE id = ?',
        [id]
      )
      return rows[0] || null
    } else {
      // 如果字段不存在，使用基础查询
      const [rows] = await pool.execute(
        'SELECT id, username, nickname, email, register_time FROM users WHERE id = ?',
        [id]
      )
      return rows[0] || null
    }
  }

  // 检查邮箱是否存在
  static async emailExists(email) {
    const [rows] = await pool.execute(
      'SELECT COUNT(*) as count FROM users WHERE email = ?',
      [email]
    )
    return rows[0].count > 0
  }

  // 更新密码
  static async updatePassword(id, newPassword) {
    const [result] = await pool.execute(
      'UPDATE users SET password = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?',
      [newPassword, id]
    )
    return result.affectedRows > 0
  }

  // 获取用户统计信息
  static async getStats(userId) {
    const [rows] = await pool.execute(
      `SELECT 
        COUNT(p.id) as project_count,
        COALESCE(SUM(p.shot_count), 0) as total_shots
      FROM projects p 
      WHERE p.user_id = ?`,
      [userId]
    )
    return rows[0] || { project_count: 0, total_shots: 0 }
  }

  // 更新用户头像
  static async updateAvatar(userId, avatarUrl) {
    // 首先检查avatar_url字段是否存在
    const [columns] = await pool.execute("SHOW COLUMNS FROM users LIKE 'avatar_url'")
    
    if (columns.length > 0) {
      // 如果字段存在，执行更新
      const [result] = await pool.execute(
        'UPDATE users SET avatar_url = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?',
        [avatarUrl, userId]
      )
      return result.affectedRows > 0
    } else {
      // 如果字段不存在，返回false
      console.warn('avatar_url字段不存在，无法更新用户头像')
      return false
    }
  }

  // 更新昵称
  static async updateNickname(userId, nickname) {
    const [result] = await pool.execute(
      'UPDATE users SET nickname = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?',
      [nickname, userId]
    )
    return result.affectedRows > 0
  }

  // 获取用户头像
  static async getAvatar(userId) {
    // 首先检查avatar_url字段是否存在
    const [columns] = await pool.execute("SHOW COLUMNS FROM users LIKE 'avatar_url'")
    
    if (columns.length > 0) {
      // 如果字段存在，执行查询
      const [rows] = await pool.execute(
        'SELECT avatar_url FROM users WHERE id = ?',
        [userId]
      )
      return rows[0]?.avatar_url || null
    } else {
      // 如果字段不存在，返回null
      console.warn('avatar_url字段不存在，无法获取用户头像')
      return null
    }
  }
}