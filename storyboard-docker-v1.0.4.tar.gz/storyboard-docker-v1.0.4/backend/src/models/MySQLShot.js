import { pool } from '../config/database.js';
import { fileURLToPath } from 'url';
import path from 'path';

// 获取当前文件的绝对路径
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
console.log(`✅ MySQLShot.js 正在从以下路径加载: ${__filename}`);

export class MySQLShot {
  // 添加分镜（支持批量）
  static async create(projectId, count = 1) {
    // 获取当前最大排序号
    const [maxRows] = await pool.execute(
      'SELECT COALESCE(MAX(sort_order), 0) as max_sort FROM shots WHERE project_id = ?',
      [projectId]
    );
    
    let currentSort = maxRows[0].max_sort;
    const insertedIds = [];
    
    // 批量插入分镜
    for (let i = 0; i < count; i++) {
      currentSort++;
      const [result] = await pool.execute(
        'INSERT INTO shots (project_id, sort_order) VALUES (?, ?)',
        [projectId, currentSort]
      );
      insertedIds.push(result.insertId);
    }
    
    return insertedIds;
  }

  // 获取项目的分镜列表
  static async findByProjectId(projectId) {
    // 使用单引号和转义的反引号确保正确的字段名
    const sql = 'SELECT id, sort_order, tag, description, image_url, shot_type, dialogue, sound_effect, animation, camera_movement, scene, characters, character_state, narration, shooting_angle, create_time, update_time FROM shots WHERE project_id = ? ORDER BY sort_order ASC';
    
    console.log(`🔍 执行findByProjectId，项目ID: ${projectId}`);
    console.log(`📝 实际执行的SQL查询: ${sql}`);
    console.log(`❓ 是否包含"characters"字段: ${sql.includes('characters')}`);
    console.log(`✅ 是否包含"character"字段: ${sql.includes('character')}`);
    
    try {
      const [rows] = await pool.execute(sql, [projectId]);
      console.log(`✅ 查询成功，返回 ${rows.length} 条记录`);
      return rows;
    } catch (error) {
      console.error(`❌ 查询失败: ${error.message}`);
      console.error(`❌ 错误的SQL: ${error.sql || '未知'}`);
      throw error;
    }
  }

  // 根据ID查找分镜
  static async findById(id) {
    const [rows] = await pool.execute('SELECT * FROM shots WHERE id = ?', [id]);
    return rows[0] || null;
  }

  // 更新分镜信息
  static async update(id, data) {
    const {
      tag,
      description,
      image_url,
      shot_type,
      dialogue,
      sound_effect,
      animation,
      camera_movement,
      scene,
      characters,
      character_state,
      narration,
      shooting_angle
    } = data;
    
    // 使用单引号和转义的反引号确保正确的字段名
    let sql = 'UPDATE shots SET tag = ?, description = ?, shot_type = ?, dialogue = ?, sound_effect = ?, animation = ?, camera_movement = ?, scene = ?, characters = ?, character_state = ?, narration = ?, shooting_angle = ?, update_time = CURRENT_TIMESTAMP';
    let params = [
      tag || null, 
      description || null, 
      shot_type || null, 
      dialogue || null, 
      sound_effect || null, 
      animation || null, 
      camera_movement || null, 
      scene || null, 
      characters || null, 
      character_state || null, 
      narration || null, 
      shooting_angle || null
    ];
    
    if (image_url !== undefined) {
      sql += ', image_url = ?';
      params.push(image_url);
    }
    
    sql += ' WHERE id = ?';
    params.push(id);
    
    const [result] = await pool.execute(sql, params);
    return result.affectedRows > 0;
  }

  // 更新分镜图片
  static async updateImage(id, imageUrl) {
    const [result] = await pool.execute(
      'UPDATE shots SET image_url = ?, update_time = CURRENT_TIMESTAMP WHERE id = ?',
      [imageUrl, id]
    );
    return result.affectedRows > 0;
  }

  // 删除分镜
  static async delete(id) {
    const [result] = await pool.execute('DELETE FROM shots WHERE id = ?', [id]);
    return result.affectedRows > 0;
  }

  // 删除项目的所有分镜
  static async deleteByProjectId(projectId) {
    const [result] = await pool.execute('DELETE FROM shots WHERE project_id = ?', [projectId]);
    return result.affectedRows > 0;
  }

  // 重新排序分镜
  static async reorder(projectId, shotIds) {
    // 事务处理
    const connection = await pool.getConnection();
    
    try {
      await connection.beginTransaction();
      
      // 批量更新排序号
      for (let i = 0; i < shotIds.length; i++) {
        await connection.execute(
          'UPDATE shots SET sort_order = ?, update_time = CURRENT_TIMESTAMP WHERE id = ? AND project_id = ?',
          [i + 1, shotIds[i], projectId]
        );
      }
      
      await connection.commit();
      return true;
    } catch (error) {
      await connection.rollback();
      throw error;
    } finally {
      connection.release();
    }
  }
  
  // 根据分镜ID获取项目ID
  static async getProjectId(shotId) {
    try {
      const [rows] = await pool.execute(
        'SELECT project_id FROM shots WHERE id = ?',
        [shotId]
      );
      
      return rows.length > 0 ? rows[0].project_id : null;
    } catch (error) {
      console.error('获取分镜所属项目ID失败:', error);
      return null;
    }
  }
}