import { pool } from '../config/database.js'
import { MySQLProject } from './MySQLProject.js'

export class MySQLScriptSquare {
  // 发布项目到脚本广场
  static async publishProject(projectId, userId, description = '', category = '其他类别', isPublic = true) {
    // 检查是否有任何发布记录（不区分公开/私有）
    const existingAny = await this.findAnyByProjectId(projectId)
    if (existingAny) {
      // 读取项目最后编辑时间
      const [projRows] = await pool.execute(
        'SELECT last_edit_time FROM projects WHERE id = ?',
        [projectId]
      )
      const lastEditTime = projRows[0]?.last_edit_time
      // 若项目自上次发布之后没有任何修改，则不允许重复发布
      if (lastEditTime && new Date(lastEditTime) <= new Date(existingAny.publish_time)) {
        return { ok: false, reason: 'no_changes' }
      }
      // 允许再次发布：仅更新元信息与发布时间
      const [result] = await pool.execute(
        `UPDATE script_square 
         SET description = ?, category = ?, is_public = ?, publish_time = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP 
         WHERE project_id = ?`,
        [description, category, isPublic, projectId]
      )
      return { ok: result.affectedRows > 0 }
    } else {
      // 首次发布
      const [result] = await pool.execute(
        `INSERT INTO script_square (project_id, user_id, description, category, is_public) 
         VALUES (?, ?, ?, ?, ?)`,
        [projectId, userId, description, category, isPublic]
      )
      return { ok: !!result.insertId, id: result.insertId }
    }
  }

  // 根据项目ID查找发布记录
  static async findByProjectId(projectId) {
    const [rows] = await pool.execute(
      `SELECT ss.*, u.username as author, p.name as project_name, p.shot_count
       FROM script_square ss
       JOIN users u ON ss.user_id = u.id
       JOIN projects p ON ss.project_id = p.id
       WHERE ss.project_id = ? AND ss.is_public = TRUE`,
      [projectId]
    )
    return rows[0] || null
  }

  // 不区分公开/私有，按项目查找发布记录
  static async findAnyByProjectId(projectId) {
    const [rows] = await pool.execute(
      `SELECT * FROM script_square WHERE project_id = ?`,
      [projectId]
    )
    return rows[0] || null
  }

  // 获取所有公开的脚本（支持分类筛选和搜索）
  static async getPublicScripts(category = null, search = null) {
    let sql = `
      SELECT ss.*, COALESCE(u.nickname, u.username) as author, u.avatar_url as author_avatar, p.name as project_name, p.shot_count
      FROM script_square ss
      JOIN users u ON ss.user_id = u.id
      JOIN projects p ON ss.project_id = p.id
      WHERE ss.is_public = TRUE
    `
    
    const params = []
    
    // 添加分类筛选
    if (category && category !== '全部') {
      sql += ' AND ss.category = ?'
      params.push(category)
    }
    
    // 添加关键词搜索
    if (search && search.trim()) {
      sql += ' AND (p.name LIKE ? OR ss.description LIKE ? OR EXISTS (SELECT 1 FROM shots s WHERE s.project_id = ss.project_id AND (s.tag LIKE ? OR s.description LIKE ?)))'
      const keyword = `%${search.trim()}%`
      params.push(keyword, keyword, keyword, keyword)
    }
    
    sql += ' ORDER BY ss.publish_time DESC'
    
    const [rows] = await pool.execute(sql, params)
    
    // 为每个脚本获取缩略图
    for (const script of rows) {
      script.preview_image = await MySQLProject.getThumbnail(script.project_id)
    }
    
    return rows
  }

  // 获取所有可用的分类
  static async getCategories() {
    const [rows] = await pool.execute(`
      SELECT DISTINCT category 
      FROM script_square 
      WHERE is_public = TRUE 
      ORDER BY category
    `)
    return rows.map(row => row.category)
  }

  // 根据ID获取公开脚本详情（包含分镜信息）
  static async getPublicScriptById(id) {
    const [rows] = await pool.execute(
      `SELECT ss.*, COALESCE(u.nickname, u.username) as author, u.avatar_url as author_avatar, p.name as project_name, p.shot_count, p.field_config
       FROM script_square ss
       JOIN users u ON ss.user_id = u.id
       JOIN projects p ON ss.project_id = p.id
       WHERE ss.id = ? AND ss.is_public = TRUE`,
      [id]
    )
    
    if (rows.length === 0) {
      return null
    }
    
    const script = rows[0]
    
    // 获取项目分镜
    const [shots] = await pool.execute(
      `SELECT * FROM shots 
       WHERE project_id = ? 
       ORDER BY sort_order ASC`,
      [script.project_id]
    )
    
    script.shots = shots
    
    // 解析字段配置
    if (script.field_config) {
      script.field_config = JSON.parse(script.field_config)
    }
    
    return script
  }

  // 根据项目ID获取公开脚本详情（包含分镜信息）
  static async getPublicScriptByProjectId(projectId) {
    const [rows] = await pool.execute(
      `SELECT ss.*, COALESCE(u.nickname, u.username) as author, u.avatar_url as author_avatar, p.name as project_name, p.shot_count, p.field_config
       FROM script_square ss
       JOIN users u ON ss.user_id = u.id
       JOIN projects p ON ss.project_id = p.id
       WHERE ss.project_id = ? AND ss.is_public = TRUE`,
      [projectId]
    )
    
    if (rows.length === 0) {
      return null
    }
    
    const script = rows[0]
    
    // 获取项目分镜
    const [shots] = await pool.execute(
      `SELECT * FROM shots 
       WHERE project_id = ? 
       ORDER BY sort_order ASC`,
      [script.project_id]
    )
    
    script.shots = shots
    
    // 解析字段配置
    if (script.field_config) {
      script.field_config = JSON.parse(script.field_config)
    }
    
    return script
  }

  // 复制公开脚本到用户项目
  static async copyScript(sourceProjectId, targetUserId, targetProjectName) {
    const connection = await pool.getConnection()
    try {
      // 开始事务
      await connection.query('START TRANSACTION')
      
      // 创建新项目
      const [projectResult] = await connection.execute(
        `INSERT INTO projects (user_id, name, field_config, shot_count) 
         SELECT ?, ?, field_config, shot_count 
         FROM projects 
         WHERE id = ?`,
        [targetUserId, targetProjectName, sourceProjectId]
      )
      
      const newProjectId = projectResult.insertId
      
      if (!newProjectId) {
        throw new Error('创建项目失败')
      }
      
      // 复制分镜数据
      const [shots] = await connection.execute(
        `SELECT * FROM shots 
         WHERE project_id = ? 
         ORDER BY sort_order ASC`,
        [sourceProjectId]
      )
      
      // 插入分镜数据到新项目
      for (const shot of shots) {
        await connection.execute(
          `INSERT INTO shots (
            project_id, sort_order, tag, description, image_url, 
            shot_type, dialogue, sound_effect, animation, 
            camera_movement, scene, characters, character_state, 
            narration, shooting_angle, create_time, update_time
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            newProjectId, 
            shot.sort_order || 0, 
            shot.tag || null, 
            shot.description || null, 
            shot.image_url || null,
            shot.shot_type || null, 
            shot.dialogue || null, 
            shot.sound_effect || null, 
            shot.animation || null,
            shot.camera_movement || null, 
            shot.scene || null, 
            shot.characters || null, 
            shot.character_state || null,
            shot.narration || null, 
            shot.shooting_angle || null, 
            shot.create_time || new Date(), 
            shot.update_time || new Date()
          ]
        )
      }
      
      // 提交事务
      await connection.query('COMMIT')
      
      return newProjectId
    } catch (error) {
      // 回滚事务
      await connection.query('ROLLBACK')
      throw error
    } finally {
      connection.release()
    }
  }

  // 取消发布
  static async unpublishProject(projectId) {
    const [result] = await pool.execute(
      'DELETE FROM script_square WHERE project_id = ?',
      [projectId]
    )
    return result.affectedRows > 0
  }

  // 获取用户自己的发布列表（含公开与私有）
  static async getPublishedByUser(userId) {
    const [rows] = await pool.execute(
      `SELECT ss.*, p.name AS project_name, p.shot_count, p.last_edit_time
       FROM script_square ss
       JOIN projects p ON ss.project_id = p.id
       WHERE ss.user_id = ?
       ORDER BY ss.publish_time DESC`,
      [userId]
    )
    return rows
  }
}