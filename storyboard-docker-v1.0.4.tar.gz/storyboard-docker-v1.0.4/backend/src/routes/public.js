import express from 'express'
import { MySQLScriptSquare as ScriptSquare } from '../models/MySQLScriptSquare.js'
import { successResponse, errorResponse } from '../utils/helpers.js'

const router = express.Router()

console.log('📝 public.js 路由文件已加载')

// 获取公开脚本列表（支持分类筛选和搜索）
router.get('/project/public', async (req, res) => {
  console.log('🔍 /api/project/public 公开路由被调用')
  console.log('Request headers:', req.headers)
  try {
    const { category, search } = req.query
    console.log('🔍 搜索参数:', { category, search })
    const scripts = await ScriptSquare.getPublicScripts(category, search)
    successResponse(res, scripts)
  } catch (error) {
    console.error('获取公开脚本失败:', error)
    errorResponse(res, 500, '获取公开脚本失败')
  }
})

// 获取公开脚本详情
router.get('/project/public/:id', async (req, res) => {
  try {
    const scriptId = req.params.id
    const script = await ScriptSquare.getPublicScriptById(scriptId)
    
    if (!script) {
      return errorResponse(res, 404, '脚本不存在或未公开')
    }
    
    successResponse(res, script)
  } catch (error) {
    console.error('获取脚本详情失败:', error)
    errorResponse(res, 500, '获取脚本详情失败')
  }
})

// 测试路由
router.get('/test', async (req, res) => {
  console.log('🧪 测试路由被调用')
  console.log('Request headers:', req.headers)
  console.log('Request query:', req.query)
  successResponse(res, { message: '测试路由正常工作' })
})

export default router