import express from 'express'
import { body, param } from 'express-validator'
import { MySQLProject as Project } from '../models/MySQLProject.js'
import { MySQLScriptSquare as ScriptSquare } from '../models/MySQLScriptSquare.js'
import { authenticateToken } from '../middleware/auth.js'
import { validateInput } from '../middleware/validation.js'
import { successResponse, errorResponse, checkOwnership } from '../utils/helpers.js'

const router = express.Router()

// 创建项目
router.post('/create', [
  authenticateToken,
  body('name')
    .trim()
    .isLength({ min: 1, max: 100 })
    .withMessage('项目名称长度必须在1-100个字符之间'),
  body('fieldConfig').optional().isObject().withMessage('字段配置必须是对象')
], validateInput, async (req, res) => {
  try {
    const { name, fieldConfig } = req.body
    const userId = req.user.id

    const projectId = await Project.create(userId, name, fieldConfig)

    // 获取创建后的项目信息
    const project = await Project.findById(projectId)

    successResponse(res, project, '项目创建成功')
  } catch (error) {
    console.error('创建项目失败:', error)
    errorResponse(res, 500, '创建项目失败，请重试')
  }
})

// 获取用户的项目列表
router.get('/list', authenticateToken, async (req, res) => {
  try {
    const userId = req.user.id
    const projects = await Project.findByUserId(userId)
    
    successResponse(res, projects)
  } catch (error) {
    console.error('获取项目列表失败:', error)
    errorResponse(res, 500, '获取项目列表失败')
  }
})

// 获取当前用户发布到脚本广场的列表（需在动态路由前面）
router.get('/my-published', authenticateToken, async (req, res) => {
  try {
    const userId = req.user.id
    const rows = await ScriptSquare.getPublishedByUser(userId)
    successResponse(res, rows, '获取已发布列表成功')
  } catch (error) {
    console.error('获取我的发布列表失败:', error)
    errorResponse(res, 500, '获取我的发布列表失败')
  }
})

// 获取单个项目信息
router.get('/:id', [
  authenticateToken,
  param('id').isInt().withMessage('项目ID必须是数字')
], validateInput, async (req, res) => {
  try {
    const projectId = req.params.id
    const userId = req.user.id

    const project = await Project.findById(projectId)
    if (!project) {
      return errorResponse(res, 404, '项目不存在')
    }

    // 检查项目所有权
    if (!checkOwnership(project.user_id, userId)) {
      return errorResponse(res, 403, '无权访问此项目')
    }

    // 获取项目统计信息
    const stats = await Project.getStats(projectId)

    successResponse(res, {
      ...project,
      ...stats
    })
  } catch (error) {
    console.error('获取项目信息失败:', error)
    errorResponse(res, 500, '获取项目信息失败')
  }
})

// 更新项目名称
router.put('/update/:id', [
  authenticateToken,
  param('id').isInt().withMessage('项目ID必须是数字'),
  body('name')
    .trim()
    .isLength({ min: 1, max: 100 })
    .withMessage('项目名称长度必须在1-100个字符之间')
], validateInput, async (req, res) => {
  try {
    const projectId = req.params.id
    const userId = req.user.id
    const { name } = req.body

    // 检查项目是否属于当前用户
    const belongsToUser = await Project.belongsToUser(projectId, userId)
    if (!belongsToUser) {
      return errorResponse(res, 403, '无权修改此项目')
    }

    const updated = await Project.updateName(projectId, name)
    if (!updated) {
      return errorResponse(res, 404, '项目不存在或更新失败')
    }

    successResponse(res, null, '项目名称更新成功')
  } catch (error) {
    console.error('更新项目失败:', error)
    errorResponse(res, 500, '更新项目失败，请重试')
  }
})

// 删除项目
router.delete('/delete/:id', [
  authenticateToken,
  param('id').isInt().withMessage('项目ID必须是数字')
], validateInput, async (req, res) => {
  try {
    const projectId = req.params.id
    const userId = req.user.id

    // 检查项目是否属于当前用户
    const belongsToUser = await Project.belongsToUser(projectId, userId)
    if (!belongsToUser) {
      return errorResponse(res, 403, '无权删除此项目')
    }

    const deleted = await Project.delete(projectId)
    if (!deleted) {
      return errorResponse(res, 404, '项目不存在')
    }

    successResponse(res, null, '项目删除成功')
  } catch (error) {
    console.error('删除项目失败:', error)
    errorResponse(res, 500, '删除项目失败，请重试')
  }
})

// 更新项目字段配置
router.put('/field-config/:id', [
  authenticateToken,
  param('id').isInt().withMessage('项目ID必须是数字'),
  body('fieldConfig').isObject().withMessage('字段配置必须是对象'),
  // 删除duration字段验证规则
  body('fieldConfig.shot_type').isBoolean().withMessage('镜头字段配置必须是布尔值'),
  body('fieldConfig.dialogue').isBoolean().withMessage('台词字段配置必须是布尔值'),
  body('fieldConfig.sound_effect').isBoolean().withMessage('音效字段配置必须是布尔值'),
  body('fieldConfig.animation').isBoolean().withMessage('动效字段配置必须是布尔值'),
  body('fieldConfig.camera_movement').isBoolean().withMessage('运镜字段配置必须是布尔值'),
  body('fieldConfig.scene').isBoolean().withMessage('场景字段配置必须是布尔值'),
  body('fieldConfig.character').isBoolean().withMessage('角色字段配置必须是布尔值'),
  body('fieldConfig.character_state').isBoolean().withMessage('人物状态字段配置必须是布尔值'),
  body('fieldConfig.narration').isBoolean().withMessage('旁白字段配置必须是布尔值'),
  body('fieldConfig.shooting_angle').isBoolean().withMessage('拍摄角度字段配置必须是布尔值')
], validateInput, async (req, res) => {
  try {
    const projectId = req.params.id
    const userId = req.user.id
    const { fieldConfig } = req.body

    // 检查项目是否属于当前用户
    const belongsToUser = await Project.belongsToUser(projectId, userId)
    if (!belongsToUser) {
      return errorResponse(res, 403, '无权修改此项目')
    }

    const updated = await Project.updateFieldConfig(projectId, fieldConfig)
    if (!updated) {
      return errorResponse(res, 404, '项目不存在或更新失败')
    }

    successResponse(res, fieldConfig, '字段配置更新成功')
  } catch (error) {
    console.error('更新字段配置失败:', error)
    errorResponse(res, 500, '更新字段配置失败，请重试')
  }
})

// 获取项目字段配置
router.get('/field-config/:id', [
  authenticateToken,
  param('id').isInt().withMessage('项目ID必须是数字')
], validateInput, async (req, res) => {
  try {
    const projectId = req.params.id
    const userId = req.user.id

    // 检查项目是否属于当前用户
    const belongsToUser = await Project.belongsToUser(projectId, userId)
    if (!belongsToUser) {
      return errorResponse(res, 403, '无权访问此项目')
    }

    const fieldConfig = await Project.getFieldConfig(projectId)
    successResponse(res, fieldConfig)
  } catch (error) {
    console.error('获取字段配置失败:', error)
    errorResponse(res, 500, '获取字段配置失败')
  }
})

// 获取公开脚本列表
router.get('/public', async (req, res, next) => {
  // 直接处理公开接口，不经过任何中间件
  console.log('🔍 /api/project/public 路由被调用（直接处理）')
  console.log('Request headers:', req.headers)
  try {
    const scripts = await ScriptSquare.getPublicScripts()
    return res.json({
      code: 200,
      success: true,
      message: '获取公开脚本成功',
      data: scripts
    })
  } catch (error) {
    console.error('获取公开脚本失败:', error)
    return res.status(500).json({
      code: 500,
      success: false,
      message: '获取公开脚本失败'
    })
  }
})

// 获取公开脚本详情
router.get('/public/:id', [
  param('id').isInt().withMessage('脚本ID必须是数字')
], validateInput, async (req, res) => {
  try {
    const scriptId = req.params.id
    const script = await ScriptSquare.getPublicScriptById(scriptId)
    
    if (!script) {
      return errorResponse(res, 404, '脚本不存在或未公开')
    }
    
    successResponse(res, script)
  } catch (error) {
    console.error('获取脚本详情失败:', error)
    errorResponse(res, 500, '获取脚本详情失败')
  }
})

// 发布项目到脚本广场
router.post('/publish', [
  authenticateToken,
  body('projectId').isInt().withMessage('项目ID必须是数字'),
  body('description').optional().trim(),
  body('category').isIn([
    '生活记录', '知识科普', '娱乐搞笑', '情感故事', '美食制作', 
    '美妆穿搭', '旅行风景', '职场创业', '亲子母婴', '运动健康', '其他类别'
  ]).withMessage('分类选择无效'),
  body('isPublic').optional().isBoolean().withMessage('isPublic必须是布尔值')
], validateInput, async (req, res) => {
  try {
    const { projectId, description = '', category = '其他类别', isPublic = true } = req.body
    const userId = req.user.id

    // 检查项目是否属于当前用户
    const belongsToUser = await Project.belongsToUser(projectId, userId)
    if (!belongsToUser) {
      return errorResponse(res, 403, '无权发布此项目')
    }

    // 发布项目到脚本广场
    const result = await ScriptSquare.publishProject(projectId, userId, description, category, isPublic)
    if (result?.ok) {
      return res.json({ code: 200, success: true, message: '项目发布成功' })
    }
    if (result?.reason === 'no_changes') {
      return res.status(400).json({ code: 400, success: false, message: '该项目自上次发布以来没有任何修改，不能重复发布' })
    }
    return errorResponse(res, 500, '项目发布失败')
  } catch (error) {
    console.error('发布项目失败:', error)
    errorResponse(res, 500, '项目发布失败，请重试')
  }
})

// 获取当前用户发布到脚本广场的列表（含公开与私有）
router.get('/my-published', authenticateToken, async (req, res) => {
  try {
    const userId = req.user.id
    const rows = await ScriptSquare.getPublishedByUser(userId)
    successResponse(res, rows, '获取已发布列表成功')
  } catch (error) {
    console.error('获取我的发布列表失败:', error)
    errorResponse(res, 500, '获取我的发布列表失败')
  }
})

// 获取所有可用的分类
router.get('/categories', async (req, res) => {
  try {
    const categories = await ScriptSquare.getCategories()
    successResponse(res, categories, '获取分类列表成功')
  } catch (error) {
    console.error('获取分类列表失败:', error)
    errorResponse(res, 500, '获取分类列表失败')
  }
})

// 删除发布（仅允许删除，不能编辑）
router.delete('/publish/:projectId', [
  authenticateToken,
  param('projectId').isInt().withMessage('项目ID必须是数字')
], validateInput, async (req, res) => {
  try {
    const projectId = parseInt(req.params.projectId)
    const userId = req.user.id
    // 权限：项目必须属于本人
    const belongsToUser = await Project.belongsToUser(projectId, userId)
    if (!belongsToUser) {
      return errorResponse(res, 403, '无权删除该发布')
    }
    const ok = await ScriptSquare.unpublishProject(projectId)
    if (ok) {
      return successResponse(res, null, '删除发布成功')
    }
    return errorResponse(res, 404, '未找到发布记录或删除失败')
  } catch (error) {
    console.error('删除发布失败:', error)
    errorResponse(res, 500, '删除发布失败，请重试')
  }
})

// 复制公开脚本到用户项目
router.post('/copy', [
  authenticateToken,
  body('sourceProjectId').isInt().withMessage('源项目ID必须是数字')
], validateInput, async (req, res) => {
  try {
    const { sourceProjectId } = req.body
    const userId = req.user.id
    
    // 检查源项目是否在脚本广场中且为公开状态
    const publicScript = await ScriptSquare.getPublicScriptByProjectId(sourceProjectId)
    if (!publicScript) {
      return errorResponse(res, 404, '该脚本不存在或未公开')
    }
    
    // 再次检查源项目是否真实存在（防止项目被删除导致复制失败）
    const sourceProject = await Project.findById(sourceProjectId)
    if (!sourceProject) {
      return errorResponse(res, 404, '源项目不存在或已被删除')
    }

    // 生成新项目名称
    const newProjectName = `复制 - ${publicScript.project_name}`
    
    // 复制脚本
    const newProjectId = await ScriptSquare.copyScript(sourceProjectId, userId, newProjectName)
    
    successResponse(res, { newProjectId }, '脚本复制成功')
  } catch (error) {
    console.error('复制脚本失败:', error)
    errorResponse(res, 500, '脚本复制失败，请重试')
  }
})

export default router