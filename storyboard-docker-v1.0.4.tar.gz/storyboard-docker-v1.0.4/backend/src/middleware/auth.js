import jwt from 'jsonwebtoken'
import dotenv from 'dotenv'

dotenv.config()

export const authenticateToken = (req, res, next) => {
  console.log('🔍 authenticateToken middleware called')
  console.log('Request URL:', req.url)
  console.log('Request method:', req.method)
  console.log('Request headers:', req.headers)
  
  const authHeader = req.headers['authorization']
  const token = authHeader && authHeader.split(' ')[1] // Bearer TOKEN

  if (!token) {
    console.log('❌ Missing token, returning 401')
    return res.status(401).json({
      code: 401,
      message: '缺少访问令牌'
    })
  }

  jwt.verify(token, process.env.JWT_SECRET, (err, user) => {
    if (err) {
      console.log('❌ Invalid token, returning 401')
      return res.status(401).json({
        code: 401,
        message: '无效的访问令牌'
      })
    }

    req.user = user
    console.log('✅ Token verified, user:', user)
    next()
  })
}

export const generateToken = (payload) => {
  return jwt.sign(payload, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN || '7d'
  })
}