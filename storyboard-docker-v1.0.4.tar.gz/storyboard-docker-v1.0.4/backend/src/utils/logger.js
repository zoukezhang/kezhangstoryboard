import winston from 'winston';
const { createLogger, transports, format } = winston;

// 创建日志记录器
const logger = createLogger({
  level: 'error',
  format: format.json(),
  transports: [
    new transports.File({ filename: 'logs/error.log' })
  ]
});

// 导出日志记录器
export default logger;