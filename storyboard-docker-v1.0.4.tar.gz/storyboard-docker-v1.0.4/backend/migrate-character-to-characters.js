#!/usr/bin/env node
/**
 * 数据库迁移脚本
 * 将shots表中的character字段重命名为characters字段
 */
import { pool } from './src/config/database.js'
import dotenv from 'dotenv'
import path from 'path'
import { fileURLToPath } from 'url'

// 设置文件路径，确保能正确加载.env文件
const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)
dotenv.config({ path: path.join(__dirname, '.env') })

// 运行迁移
const runMigration = async () => {
  console.log('=== 开始数据库迁移 ===')
  
  try {
    // 测试数据库连接
    console.log('🔌 正在测试数据库连接...')
    const connection = await pool.getConnection()
    console.log('✅ 数据库连接成功')
    connection.release()
    
    // 检查是否存在旧的character字段
    console.log('🔍 检查shots表中是否存在character字段...')
    const [tableInfo] = await pool.execute("SHOW COLUMNS FROM shots LIKE 'character'")
    
    if (tableInfo.length > 0) {
      console.log('✅ 找到character字段，正在重命名为characters...')
      
      // 执行字段重命名
      await pool.execute("ALTER TABLE shots CHANGE COLUMN `character` `characters` TEXT")
      console.log('✅ 字段重命名成功')
      
      // 验证重命名结果
      const [newTableInfo] = await pool.execute("SHOW COLUMNS FROM shots LIKE 'characters'")
      if (newTableInfo.length > 0) {
        console.log('✅ 验证成功：characters字段已存在')
      } else {
        console.log('❌ 验证失败：characters字段不存在')
      }
      
      // 再次检查旧字段是否已不存在
      const [oldTableInfo] = await pool.execute("SHOW COLUMNS FROM shots LIKE 'character'")
      if (oldTableInfo.length === 0) {
        console.log('✅ 验证成功：character字段已不存在')
      } else {
        console.log('❌ 验证失败：character字段仍然存在')
      }
    } else {
      console.log('ℹ️ character字段不存在，无需迁移')
    }
    
    console.log('\n✅ 数据库迁移完成！')
    console.log('\n现在您可以重新启动应用程序，角色字段应该能够正常保存和显示了。')
    
  } catch (error) {
    console.error('\n❌ 数据库迁移失败:', error.message)
    console.error('\n错误详情:', error)
    
    console.error('\n请检查以下几点:')
    console.error('1. MySQL服务是否正在运行')
    console.error('2. .env文件中的数据库配置是否正确')
    console.error('3. 数据库用户是否有足够的权限执行ALTER TABLE语句')
    
    // 提供手动执行SQL的提示
    console.error('\n💡 如果自动迁移失败，您可以手动执行以下SQL语句:')
    console.error('   1. 登录MySQL: mysql -u root -p')
    console.error('   2. 使用数据库: USE storyboard;')
    console.error('   3. 执行字段重命名: ALTER TABLE shots CHANGE COLUMN `character` `characters` TEXT;')
  }
}

// 运行迁移
runMigration()