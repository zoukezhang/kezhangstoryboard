# 分镜故事板 Docker 安装包 v1.0.4

## 📦 安装包内容

本安装包包含分镜故事板项目的完整Docker部署文件：

- `backend/` - 后端Node.js服务
- `frontend/` - 前端Vue.js应用
- `docker-compose.yml` - Docker编排配置文件
- `README.md` - 本安装说明文件

## 🚀 快速开始

### 前置要求

- Docker Desktop 已安装并运行
- 至少 2GB 可用内存
- 端口 80 和 3002 未被占用

### 一键安装

```bash
# 1. 解压安装包
tar -xzf storyboard-docker-v1.0.4.tar.gz
cd storyboard-docker-v1.0.4

# 2. 启动服务
docker-compose up -d

# 3. 等待服务启动完成（约1-2分钟）
# 4. 访问应用：http://localhost
```

### 手动安装

```bash
# 1. 解压安装包
tar -xzf storyboard-docker-v1.0.4.tar.gz
cd storyboard-docker-v1.0.4

# 2. 构建并启动容器
docker-compose build
docker-compose up -d

# 3. 查看服务状态
docker-compose ps

# 4. 查看日志
docker-compose logs -f
```

## 🌐 访问地址

- **前端应用**: http://localhost
- **后端API**: http://localhost:3002
- **健康检查**: http://localhost:3002/health

## 📋 服务管理

### 启动服务
```bash
docker-compose up -d
```

### 停止服务
```bash
docker-compose down
```

### 重启服务
```bash
docker-compose restart
```

### 查看日志
```bash
# 查看所有服务日志
docker-compose logs -f

# 查看特定服务日志
docker-compose logs -f frontend
docker-compose logs -f backend
```

### 更新服务
```bash
# 拉取最新代码并重新构建
git pull
docker-compose build --no-cache
docker-compose up -d
```

## 🔧 配置说明

### 环境变量

可以通过修改 `docker-compose.yml` 文件中的环境变量来自定义配置：

```yaml
environment:
  - NODE_ENV=production
  - PORT=3002
  - JWT_SECRET=your-secret-key
```

### 端口配置

- 前端: 80 (HTTP)
- 后端: 3002 (HTTP)

如需修改端口，请编辑 `docker-compose.yml` 文件中的端口映射。

### 数据持久化

- 数据库文件存储在 `backend/database.sqlite`
- 上传文件存储在 `backend/uploads/`
- 字体文件存储在 `backend/fonts/`

## 🐛 故障排除

### 常见问题

1. **端口被占用**
   ```bash
   # 查看端口占用
   lsof -i :80
   lsof -i :3002
   
   # 修改docker-compose.yml中的端口映射
   ```

2. **服务启动失败**
   ```bash
   # 查看详细错误日志
   docker-compose logs backend
   docker-compose logs frontend
   ```

3. **内存不足**
   ```bash
   # 增加Docker内存限制
   # 在Docker Desktop设置中调整内存分配
   ```

4. **数据库连接失败**
   ```bash
   # 检查数据库文件权限
   ls -la backend/database.sqlite
   
   # 重新创建数据库
   docker-compose exec backend node src/config/init.js
   ```

### 重置服务

```bash
# 完全重置（删除所有数据）
docker-compose down -v
docker-compose up -d

# 重新初始化数据库
docker-compose exec backend node src/config/init.js
```

## 📊 系统要求

- **操作系统**: Windows 10+, macOS 10.14+, Ubuntu 18.04+
- **Docker**: Docker Desktop 4.0+ 或 Docker Engine 20.10+
- **内存**: 最少 2GB，推荐 4GB+
- **存储**: 最少 1GB 可用空间
- **网络**: 需要访问互联网下载Docker镜像

## 🔒 安全说明

- 默认情况下，服务仅在本地网络可访问
- 如需外网访问，请配置防火墙和反向代理
- JWT密钥在生产环境中应使用强密码
- 定期备份数据库文件

## 📞 技术支持

如遇到问题，请：

1. 查看服务日志：`docker-compose logs -f`
2. 检查系统资源使用情况
3. 确认Docker服务正常运行
4. 参考项目文档：https://github.com/your-repo

## 📝 版本信息

- **版本**: v1.0.4
- **发布日期**: 2025年8月29日
- **更新内容**: 脚本广场功能、用户头像昵称管理、一键同款等

---

**分镜故事板 v1.0.4** - 专业的分镜创作平台  
© 2025 科长分镜故事板 | 脚本广场功能版
