import express from 'express'
import cors from 'cors'
import helmet from 'helmet'
import rateLimit from 'express-rate-limit'
import dotenv from 'dotenv'
import path from 'path'
import { fileURLToPath } from 'url'
import os from 'os'

// 路由导入
import userRoutes from './routes/user.js'
import projectRoutes from './routes/project.js'
import shotRoutes from './routes/shot.js'
import exportRoutes from './routes/export.js'
import shareRoutes from './routes/share.js'

// 配置和中间件导入
import { testSQLiteConnection } from './config/sqlite.js'
import { initSQLiteDatabase } from './config/sqlite-init.js'
import { errorHandler } from './middleware/errorHandler.js'

// 获取当前文件路径
const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

// 加载环境变量
dotenv.config()

// 获取本机IP地址的工具函数
const getLocalIP = () => {
  const interfaces = os.networkInterfaces()
  for (const name of Object.keys(interfaces)) {
    for (const iface of interfaces[name]) {
      // 跳过回环和非IPv4地址
      if (iface.family === 'IPv4' && !iface.internal) {
        return iface.address
      }
    }
  }
  return 'localhost'
}

const app = express()
const PORT = process.env.PORT || 3002

// 安全中间件
app.use(helmet({
  crossOriginResourcePolicy: { policy: "cross-origin" }
}))

// CORS配置 - 允许本机IP访问
const localIP = getLocalIP()
const allowedOrigins = [
  'http://localhost:3000',
  'http://localhost:3001', // Vite在端口3000被占用时会使用3001
  'http://127.0.0.1:3000',
  'http://127.0.0.1:3001',
  `http://${localIP}:3000`,
  `http://${localIP}:3001`,
  'http://192.168.1.119:3000', // 明确指定当前本机IP
  'http://192.168.1.119:3001',
  process.env.CORS_ORIGIN
].filter(Boolean)

console.log('🌐 允许的CORS源地址:', allowedOrigins)

app.use(cors({
  origin: (origin, callback) => {
    console.log(`🔍 收到来自 ${origin || '未知'} 的跨域请求`)
    
    // 允许无origin的请求（如移动应用、Postman等）
    if (!origin) {
      console.log('✅ 允许无origin的请求')
      return callback(null, true)
    }
    
    if (allowedOrigins.includes(origin)) {
      console.log(`✅ 允许来自 ${origin} 的跨域请求`)
      callback(null, true)
    } else {
      console.log(`❌ 拒绝来自 ${origin} 的跨域请求`)
      console.log('📝 允许的源地址列表:', allowedOrigins)
      callback(new Error('不允许的跨域请求'))
    }
  },
  credentials: true
}))

// 限流配置 - 开发环境禁用
if (process.env.NODE_ENV === 'production') {
  const limiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15分钟
    max: 500, // 生产环境100次
    message: {
      code: 429,
      message: '请求过于频繁，请稍后再试'
    }
  })
  app.use(limiter)
  console.log('✅ 生产环境限流已启用: 100次/15分钟')
} else {
  console.log('⚠️  开发环境已禁用请求限流')
}

// 请求解析中间件
app.use(express.json({ limit: '10mb' }))
app.use(express.urlencoded({ extended: true, limit: '10mb' }))

// 请求日志中间件
app.use((req, res, next) => {
  console.log(`${new Date().toISOString()} - ${req.method} ${req.url}`)
  console.log('Request headers:', req.headers)
  console.log('Request body:', req.body)
  next()
})

// 静态文件服务
app.use('/uploads', express.static(path.join(__dirname, '../uploads')))

// API路由
app.use('/api/user', userRoutes)
app.use('/api/project', projectRoutes)
app.use('/api/shot', shotRoutes)
app.use('/api/export', exportRoutes)
app.use('/api/share', shareRoutes)

console.log('✅ API路由已挂载')
console.log('- /api/user')
console.log('- /api/project')
console.log('- /api/shot')
console.log('- /api/export')
console.log('- /api/share')

// 健康检查接口
app.get('/api/health', (req, res) => {
  res.json({
    code: 200,
    message: '服务运行正常',
    data: {
      status: 'ok',
      timestamp: new Date().toISOString()
    }
  })
})

// 404处理
app.use((req, res) => {
  res.status(404).json({
    code: 404,
    message: '接口不存在'
  })
})

// 错误处理中间件
app.use(errorHandler)

// 启动服务器
const startServer = async () => {
  try {
    // 测试SQLite数据库连接
    testSQLiteConnection()
    
    // 初始化SQLite数据库表
    initSQLiteDatabase()
    
    // 启动服务器 - 监听所有网络接口
    const HOST = process.env.HOST || '0.0.0.0'
    app.listen(PORT, HOST, () => {
      console.log(`🚀 服务器已启动:`)  
      console.log(`   - 本地访问: http://localhost:${PORT}`)
      console.log(`   - 网络访问: http://${getLocalIP()}:${PORT}`)
      console.log(`📝 API文档: http://localhost:${PORT}/api/health`)
      console.log(`🌍 环境: ${process.env.NODE_ENV || 'development'}`)
      
      // 根据环境显示数据库信息
      const isProduction = process.env.NODE_ENV === 'production'
      const dbInfo = isProduction 
        ? 'SQLite （生产环境，建议切换至MySQL）' 
        : 'SQLite （开发环境）'
      console.log(`💾 数据库: ${dbInfo}`)
    })
  } catch (error) {
    console.error('❌ 服务器启动失败:', error)
    process.exit(1)
  }
}

startServer()

export default app