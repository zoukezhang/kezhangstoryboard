import express from 'express'
import { param } from 'express-validator'
import PDFDocument from 'pdfkit'
import path from 'path'
import fs from 'fs'
import { fileURLToPath } from 'url'
import { SQLiteProject as Project } from '../models/SQLiteProject.js'
import { SQLiteShot as Shot } from '../models/SQLiteShot.js'
import { authenticateToken } from '../middleware/auth.js'
import { validateInput } from '../middleware/validation.js'
import { successResponse, errorResponse, checkOwnership } from '../utils/helpers.js'

// 获取当前文件路径
const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

const router = express.Router()

// 获取预览数据
router.get('/preview/:projectId', [
  authenticateToken,
  param('projectId').isInt().withMessage('项目ID必须是数字')
], validateInput, async (req, res) => {
  try {
    const projectId = req.params.projectId
    const userId = req.user.id

    // 检查项目是否属于当前用户
    const belongsToUser = await Project.belongsToUser(projectId, userId)
    if (!belongsToUser) {
      return errorResponse(res, 403, '无权访问此项目')
    }

    // 获取分镜列表
    const shots = await Shot.findByProjectId(projectId)
    
    successResponse(res, shots)
  } catch (error) {
    console.error('获取预览数据失败:', error)
    errorResponse(res, 500, '获取预览数据失败')
  }
})

// 导出项目数据
router.get('/project/:projectId', [
  authenticateToken,
  param('projectId').isInt().withMessage('项目ID必须是数字')
], validateInput, async (req, res) => {
  try {
    const projectId = req.params.projectId
    const userId = req.user.id
    const format = req.query.format || 'json'

    // 检查项目是否属于当前用户
    const belongsToUser = await Project.belongsToUser(projectId, userId)
    if (!belongsToUser) {
      return errorResponse(res, 403, '无权访问此项目')
    }

    // 获取项目信息和分镜列表
    const [project, shots] = await Promise.all([
      Project.findById(projectId),
      Shot.findByProjectId(projectId)
    ])

    if (!project) {
      return errorResponse(res, 404, '项目不存在')
    }

    if (format === 'pdf') {
      // 使用PDFKit生成真正的PDF文件
      const doc = new PDFDocument({
        margin: 50,
        size: 'A4',
        bufferPages: true
      })
      
      // 设置响应头为PDF
      res.setHeader('Content-Type', 'application/pdf')
      const fileName = encodeURIComponent(`${project.name}-storyboard.pdf`)
      res.setHeader('Content-Disposition', `attachment; filename="${fileName}"`)
      
      // 直接将PDF流管道到响应
      doc.pipe(res)
      
      // 尝试加载中文字体 - 使用项目内的字体文件
      let fontLoaded = false
      const projectFontsDir = path.join(__dirname, '../../fonts')
      const fontConfigs = [
        { path: path.join(projectFontsDir, 'NotoSansCJKsc-Regular.otf'), name: 'NotoSansCJK' },
        { path: path.join(projectFontsDir, 'Arial.ttf'), name: 'Arial' },
        { path: path.join(projectFontsDir, 'STHeiti Light.ttc'), name: 'STHeiti' },
        { path: path.join(projectFontsDir, 'Hiragino Sans GB.ttc'), name: 'HiraginoGB' }
      ]
      
      console.log('字体目录:', projectFontsDir)
      console.log('尝试加载的字体配置:', fontConfigs.map(f => f.path))
      
      for (const fontConfig of fontConfigs) {
        try {
          if (fs.existsSync(fontConfig.path)) {
            console.log(`找到字体文件: ${fontConfig.path}`)
            
            // 对于TTC字体，尝试指定字体索引
            if (fontConfig.path.endsWith('.ttc')) {
              try {
                // 尝试加载TTC字体的第一个字体
                doc.registerFont('ChineseFont', fontConfig.path, fontConfig.name)
                doc.font('ChineseFont')
                fontLoaded = true
                console.log(`TTC中文字体加载成功: ${fontConfig.path}`)
                break
              } catch (ttcError) {
                console.log(`TTC字体加载失败: ${ttcError.message}`)
                // 尝试不指定名称加载
                try {
                  doc.registerFont('ChineseFont', fontConfig.path)
                  doc.font('ChineseFont')
                  fontLoaded = true
                  console.log(`TTC字体(无名称)加载成功: ${fontConfig.path}`)
                  break
                } catch (ttcError2) {
                  console.log(`TTC字体(无名称)加载也失败: ${ttcError2.message}`)
                  continue
                }
              }
            } else {
              // TTF和OTF字体直接加载
              doc.registerFont('ChineseFont', fontConfig.path)
              doc.font('ChineseFont')
              fontLoaded = true
              console.log(`${fontConfig.path.endsWith('.otf') ? 'OTF' : 'TTF'}中文字体加载成功: ${fontConfig.path}`)
              break
            }
          } else {
            console.log(`字体文件不存在: ${fontConfig.path}`)
          }
        } catch (error) {
          console.log(`字体加载失败 ${fontConfig.path}:`, error.message)
        }
      }
      
      if (!fontLoaded) {
        // 使用内置字体
        doc.font('Helvetica')
        console.log('警告：无法加载中文字体，中文字符将使用回退方案显示')
      }
      
      // 中文处理函数：确保正确处理中文字符
      const processChineseText = (text) => {
        if (!text) return ''
        
        const processed = String(text).trim()
        
        // 如果有中文字体，直接返回原文
        if (fontLoaded) {
          return processed
        }
        
        // 如果没有加载中文字体，检查是否包含中文字符
        const hasChinese = /[\u4e00-\u9fff]/.test(processed)
        if (hasChinese) {
          // 尝试翻译常见中文词汇为英文
          const translations = {
            '项目': 'Project',
            '总镜头数': 'Total Shots',
            '创建时间': 'Created',
            '镜头': 'Shot',
            '标签': 'Tag',
            '描述': 'Description',
            '时长': 'Duration',
            '镜头类型': 'Shot Type',
            '台词': 'Dialogue',
            '音效': 'Sound Effect',
            '动效': 'Animation',
            '运镜': 'Camera Movement',
            '场景': 'Scene',
            '角色': 'Character',
            '人物状态': 'Character State',
            '旁白': 'Narration',
            '拍摄角度': 'Shooting Angle'
          }
          
          let result = processed
          for (const [chinese, english] of Object.entries(translations)) {
            result = result.replace(new RegExp(chinese, 'g'), english)
          }
          
          // 如果还有中文字符，添加标记
          if (/[\u4e00-\u9fff]/.test(result)) {
            return `${result} [Contains Chinese]`
          }
          
          return result
        }
        
        return processed
      }
      
      // 添加标题
      doc.fontSize(20).text(processChineseText(project.name), { align: 'center' })
      doc.moveDown()
      
      // 添加项目信息
      doc.fontSize(12)
      doc.text(`总镜头数: ${shots.length}`)
      doc.text(`创建时间: ${project.create_time}`)
      doc.moveDown()
      
      // 添加分镜列表
      for (let index = 0; index < shots.length; index++) {
        const shot = shots[index]
        
        if (index > 0) {
          doc.addPage()
        }
        
        doc.fontSize(16)
        doc.text(`镜头 ${index + 1}`, { underline: true })
        doc.moveDown(0.5)
        
        // 如果有图片，先显示图片
        if (shot.image_url) {
          try {
            const possiblePaths = [
              path.join(__dirname, '../../uploads', path.basename(shot.image_url)),
              path.join(__dirname, '../../../uploads', path.basename(shot.image_url))
            ]
            
            let imagePath = null
            for (const testPath of possiblePaths) {
              if (fs.existsSync(testPath)) {
                imagePath = testPath
                break
              }
            }
            
            if (imagePath) {
              console.log(`找到图片文件: ${imagePath}`)
              const maxWidth = 400
              const maxHeight = 300
              
              doc.image(imagePath, {
                fit: [maxWidth, maxHeight],
                align: 'center'
              })
              doc.moveDown()
            } else {
              doc.fontSize(10).text(`[Image not found: ${shot.image_url}]`, { color: 'gray' })
              doc.moveDown()
            }
          } catch (imgErr) {
            console.log(`图片加载失败: ${shot.image_url}`, imgErr.message)
            doc.fontSize(10).text(`[Image error: ${imgErr.message}]`, { color: 'gray' })
            doc.moveDown()
          }
        }
        
        doc.fontSize(12)
        if (shot.tag) {
          doc.text(`标签: ${processChineseText(shot.tag)}`)
        }
        if (shot.description) {
          doc.text(`描述: ${processChineseText(shot.description)}`)
        }
        
        // 添加自定义字段
        if (shot.duration) doc.text(`时长: ${processChineseText(shot.duration)}`)
        if (shot.shot_type) doc.text(`镜头类型: ${processChineseText(shot.shot_type)}`)
        if (shot.dialogue) doc.text(`台词: ${processChineseText(shot.dialogue)}`)
        if (shot.sound_effect) doc.text(`音效: ${processChineseText(shot.sound_effect)}`)
        if (shot.animation) doc.text(`动效: ${processChineseText(shot.animation)}`)
        if (shot.camera_movement) doc.text(`运镜: ${processChineseText(shot.camera_movement)}`)
        if (shot.scene) doc.text(`场景: ${processChineseText(shot.scene)}`)
        if (shot.character) doc.text(`角色: ${processChineseText(shot.character)}`)
        if (shot.character_state) doc.text(`人物状态: ${processChineseText(shot.character_state)}`)
        if (shot.narration) doc.text(`旁白: ${processChineseText(shot.narration)}`)
        if (shot.shooting_angle) doc.text(`拍摄角度: ${processChineseText(shot.shooting_angle)}`)
        
        doc.moveDown()
      }
      
      // 结束PDF文档
      doc.end()
      return
    }

    // 返回JSON格式数据
    successResponse(res, {
      project,
      shots
    })
  } catch (error) {
    console.error('导出失败:', error)
    errorResponse(res, 500, '导出失败，请重试')
  }
})

export default router