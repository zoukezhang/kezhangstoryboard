import express from 'express'
import { body, param } from 'express-validator'
import { SQLiteProject as Project } from '../models/SQLiteProject.js'
import { authenticateToken } from '../middleware/auth.js'
import { validateInput } from '../middleware/validation.js'
import { successResponse, errorResponse, checkOwnership } from '../utils/helpers.js'

const router = express.Router()

// 创建项目
router.post('/create', [
  authenticateToken,
  body('name')
    .trim()
    .isLength({ min: 1, max: 100 })
    .withMessage('项目名称长度必须在1-100个字符之间'),
  body('fieldConfig').optional().isObject().withMessage('字段配置必须是对象')
], validateInput, async (req, res) => {
  try {
    const { name, fieldConfig } = req.body
    const userId = req.user.id

    const projectId = await Project.create(userId, name, fieldConfig)

    // 获取创建后的项目信息
    const project = await Project.findById(projectId)

    successResponse(res, project, '项目创建成功')
  } catch (error) {
    console.error('创建项目失败:', error)
    errorResponse(res, 500, '创建项目失败，请重试')
  }
})

// 获取用户的项目列表
router.get('/list', authenticateToken, async (req, res) => {
  try {
    const userId = req.user.id
    const projects = await Project.findByUserId(userId)
    
    successResponse(res, projects)
  } catch (error) {
    console.error('获取项目列表失败:', error)
    errorResponse(res, 500, '获取项目列表失败')
  }
})

// 获取单个项目信息
router.get('/:id', [
  authenticateToken,
  param('id').isInt().withMessage('项目ID必须是数字')
], validateInput, async (req, res) => {
  try {
    const projectId = req.params.id
    const userId = req.user.id

    const project = await Project.findById(projectId)
    if (!project) {
      return errorResponse(res, 404, '项目不存在')
    }

    // 检查项目所有权
    if (!checkOwnership(project.user_id, userId)) {
      return errorResponse(res, 403, '无权访问此项目')
    }

    // 获取项目统计信息
    const stats = await Project.getStats(projectId)

    successResponse(res, {
      ...project,
      ...stats
    })
  } catch (error) {
    console.error('获取项目信息失败:', error)
    errorResponse(res, 500, '获取项目信息失败')
  }
})

// 更新项目名称
router.put('/update/:id', [
  authenticateToken,
  param('id').isInt().withMessage('项目ID必须是数字'),
  body('name')
    .trim()
    .isLength({ min: 1, max: 100 })
    .withMessage('项目名称长度必须在1-100个字符之间')
], validateInput, async (req, res) => {
  try {
    const projectId = req.params.id
    const userId = req.user.id
    const { name } = req.body

    // 检查项目是否属于当前用户
    const belongsToUser = await Project.belongsToUser(projectId, userId)
    if (!belongsToUser) {
      return errorResponse(res, 403, '无权修改此项目')
    }

    const updated = await Project.updateName(projectId, name)
    if (!updated) {
      return errorResponse(res, 404, '项目不存在或更新失败')
    }

    successResponse(res, null, '项目名称更新成功')
  } catch (error) {
    console.error('更新项目失败:', error)
    errorResponse(res, 500, '更新项目失败，请重试')
  }
})

// 删除项目
router.delete('/delete/:id', [
  authenticateToken,
  param('id').isInt().withMessage('项目ID必须是数字')
], validateInput, async (req, res) => {
  try {
    const projectId = req.params.id
    const userId = req.user.id

    // 检查项目是否属于当前用户
    const belongsToUser = await Project.belongsToUser(projectId, userId)
    if (!belongsToUser) {
      return errorResponse(res, 403, '无权删除此项目')
    }

    const deleted = await Project.delete(projectId)
    if (!deleted) {
      return errorResponse(res, 404, '项目不存在')
    }

    successResponse(res, null, '项目删除成功')
  } catch (error) {
    console.error('删除项目失败:', error)
    errorResponse(res, 500, '删除项目失败，请重试')
  }
})

// 更新项目字段配置
router.put('/field-config/:id', [
  authenticateToken,
  param('id').isInt().withMessage('项目ID必须是数字'),
  body('fieldConfig').isObject().withMessage('字段配置必须是对象'),
  body('fieldConfig.duration').isBoolean().withMessage('时长字段配置必须是布尔值'),
  body('fieldConfig.shot_type').isBoolean().withMessage('镜头字段配置必须是布尔值'),
  body('fieldConfig.dialogue').isBoolean().withMessage('台词字段配置必须是布尔值'),
  body('fieldConfig.sound_effect').isBoolean().withMessage('音效字段配置必须是布尔值'),
  body('fieldConfig.animation').isBoolean().withMessage('动效字段配置必须是布尔值'),
  body('fieldConfig.camera_movement').isBoolean().withMessage('运镜字段配置必须是布尔值'),
  body('fieldConfig.scene').isBoolean().withMessage('场景字段配置必须是布尔值'),
  body('fieldConfig.character').isBoolean().withMessage('角色字段配置必须是布尔值'),
  body('fieldConfig.character_state').isBoolean().withMessage('人物状态字段配置必须是布尔值'),
  body('fieldConfig.narration').isBoolean().withMessage('旁白字段配置必须是布尔值'),
  body('fieldConfig.shooting_angle').isBoolean().withMessage('拍摄角度字段配置必须是布尔值')
], validateInput, async (req, res) => {
  try {
    const projectId = req.params.id
    const userId = req.user.id
    const { fieldConfig } = req.body

    // 检查项目是否属于当前用户
    const belongsToUser = await Project.belongsToUser(projectId, userId)
    if (!belongsToUser) {
      return errorResponse(res, 403, '无权修改此项目')
    }

    const updated = await Project.updateFieldConfig(projectId, fieldConfig)
    if (!updated) {
      return errorResponse(res, 404, '项目不存在或更新失败')
    }

    successResponse(res, fieldConfig, '字段配置更新成功')
  } catch (error) {
    console.error('更新字段配置失败:', error)
    errorResponse(res, 500, '更新字段配置失败，请重试')
  }
})

// 获取项目字段配置
router.get('/field-config/:id', [
  authenticateToken,
  param('id').isInt().withMessage('项目ID必须是数字')
], validateInput, async (req, res) => {
  try {
    const projectId = req.params.id
    const userId = req.user.id

    // 检查项目是否属于当前用户
    const belongsToUser = await Project.belongsToUser(projectId, userId)
    if (!belongsToUser) {
      return errorResponse(res, 403, '无权访问此项目')
    }

    const fieldConfig = await Project.getFieldConfig(projectId)
    successResponse(res, fieldConfig)
  } catch (error) {
    console.error('获取字段配置失败:', error)
    errorResponse(res, 500, '获取字段配置失败')
  }
})

export default router