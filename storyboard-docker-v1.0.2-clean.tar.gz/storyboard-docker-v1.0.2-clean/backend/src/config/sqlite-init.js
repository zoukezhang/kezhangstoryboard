import { db } from '../config/sqlite.js'

const initSQLiteDatabase = () => {
  try {
    // 创建用户表
    db.exec(`
      CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL,
        email TEXT NOT NULL UNIQUE,
        password TEXT NOT NULL,
        register_time DATETIME DEFAULT CURRENT_TIMESTAMP,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `)

    // 创建项目表
    db.exec(`
      CREATE TABLE IF NOT EXISTS projects (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        name TEXT NOT NULL,
        shot_count INTEGER DEFAULT 0,
        field_config TEXT DEFAULT '{"duration":false,"shot_type":false,"dialogue":false,"sound_effect":false,"animation":false,"camera_movement":false,"scene":false,"character":false,"character_state":false,"narration":false,"shooting_angle":false}',
        create_time DATETIME DEFAULT CURRENT_TIMESTAMP,
        last_edit_time DATETIME DEFAULT CURRENT_TIMESTAMP,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      )
    `)

    // 创建分镜表
    db.exec(`
      CREATE TABLE IF NOT EXISTS shots (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        project_id INTEGER NOT NULL,
        sort_order INTEGER NOT NULL DEFAULT 0,
        tag TEXT DEFAULT '',
        description TEXT DEFAULT '',
        image_url TEXT DEFAULT '',
        duration TEXT DEFAULT '',
        shot_type TEXT DEFAULT '',
        dialogue TEXT DEFAULT '',
        sound_effect TEXT DEFAULT '',
        animation TEXT DEFAULT '',
        camera_movement TEXT DEFAULT '',
        scene TEXT DEFAULT '',
        character TEXT DEFAULT '',
        character_state TEXT DEFAULT '',
        narration TEXT DEFAULT '',
        shooting_angle TEXT DEFAULT '',
        create_time DATETIME DEFAULT CURRENT_TIMESTAMP,
        update_time DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE
      )
    `)

    // 创建分享表
    db.exec(`
      CREATE TABLE IF NOT EXISTS shares (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        project_id INTEGER NOT NULL,
        token TEXT NOT NULL UNIQUE,
        expire_time DATETIME NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE
      )
    `)

    // 数据库迁移 - 为现有表添加新字段
    try {
      // 为项目表添加字段配置
      db.exec(`
        ALTER TABLE projects ADD COLUMN field_config TEXT DEFAULT '{"duration":false,"shot_type":false,"dialogue":false,"sound_effect":false,"animation":false,"camera_movement":false,"scene":false,"character":false,"character_state":false,"narration":false,"shooting_angle":false}'
      `)
    } catch (error) {
      // 字段已存在，忽略错误
    }

    try {
      // 为分镜表添加新字段
      db.exec(`ALTER TABLE shots ADD COLUMN duration TEXT DEFAULT ''`)
      db.exec(`ALTER TABLE shots ADD COLUMN shot_type TEXT DEFAULT ''`)
      db.exec(`ALTER TABLE shots ADD COLUMN dialogue TEXT DEFAULT ''`)
      db.exec(`ALTER TABLE shots ADD COLUMN sound_effect TEXT DEFAULT ''`)
      db.exec(`ALTER TABLE shots ADD COLUMN animation TEXT DEFAULT ''`)
      db.exec(`ALTER TABLE shots ADD COLUMN camera_movement TEXT DEFAULT ''`)
      db.exec(`ALTER TABLE shots ADD COLUMN scene TEXT DEFAULT ''`)
      db.exec(`ALTER TABLE shots ADD COLUMN character TEXT DEFAULT ''`)
      db.exec(`ALTER TABLE shots ADD COLUMN character_state TEXT DEFAULT ''`)
      db.exec(`ALTER TABLE shots ADD COLUMN narration TEXT DEFAULT ''`)
      db.exec(`ALTER TABLE shots ADD COLUMN shooting_angle TEXT DEFAULT ''`)
    } catch (error) {
      // 字段已存在，忽略错误
    }

    console.log('✅ SQLite数据库表创建成功')
  } catch (error) {
    console.error('❌ SQLite数据库初始化失败:', error)
    throw error
  }
}

export { initSQLiteDatabase }