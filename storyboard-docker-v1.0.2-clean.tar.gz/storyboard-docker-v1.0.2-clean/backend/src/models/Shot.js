import { pool } from '../config/database.js'

export class Shot {
  // 添加分镜（支持批量）
  static async create(projectId, count = 1) {
    const connection = await pool.getConnection()
    
    try {
      await connection.beginTransaction()
      
      // 获取当前最大排序号
      const [maxRows] = await connection.execute(
        'SELECT COALESCE(MAX(sort_order), 0) as max_sort FROM shots WHERE project_id = ?',
        [projectId]
      )
      
      let currentSort = maxRows[0].max_sort
      const insertedIds = []
      
      // 批量插入分镜
      for (let i = 0; i < count; i++) {
        currentSort++
        const [result] = await connection.execute(
          'INSERT INTO shots (project_id, sort_order) VALUES (?, ?)',
          [projectId, currentSort]
        )
        insertedIds.push(result.insertId)
      }
      
      await connection.commit()
      return insertedIds
      
    } catch (error) {
      await connection.rollback()
      throw error
    } finally {
      connection.release()
    }
  }

  // 获取项目的分镜列表
  static async findByProjectId(projectId) {
    const [rows] = await pool.execute(`
      SELECT 
        id, 
        sort_order,
        tag, 
        description, 
        image_url, 
        create_time, 
        update_time
      FROM shots 
      WHERE project_id = ? 
      ORDER BY sort_order ASC
    `, [projectId])
    return rows
  }

  // 根据ID查找分镜
  static async findById(id) {
    const [rows] = await pool.execute(
      'SELECT * FROM shots WHERE id = ?',
      [id]
    )
    return rows[0]
  }

  // 更新分镜信息
  static async update(id, data) {
    const { tag, description, image_url } = data
    const [result] = await pool.execute(`
      UPDATE shots 
      SET tag = ?, description = ?, image_url = COALESCE(?, image_url), update_time = CURRENT_TIMESTAMP 
      WHERE id = ?
    `, [tag || '', description || '', image_url, id])
    return result.affectedRows > 0
  }

  // 更新分镜图片
  static async updateImage(id, imageUrl) {
    const [result] = await pool.execute(
      'UPDATE shots SET image_url = ?, update_time = CURRENT_TIMESTAMP WHERE id = ?',
      [imageUrl, id]
    )
    return result.affectedRows > 0
  }

  // 删除分镜
  static async delete(id) {
    const connection = await pool.getConnection()
    
    try {
      await connection.beginTransaction()
      
      // 获取要删除的分镜信息
      const [shotRows] = await connection.execute(
        'SELECT project_id, sort_order FROM shots WHERE id = ?',
        [id]
      )
      
      if (shotRows.length === 0) {
        throw new Error('分镜不存在')
      }
      
      const { project_id, sort_order } = shotRows[0]
      
      // 删除分镜
      await connection.execute('DELETE FROM shots WHERE id = ?', [id])
      
      // 重新排序后续分镜
      await connection.execute(
        'UPDATE shots SET sort_order = sort_order - 1 WHERE project_id = ? AND sort_order > ?',
        [project_id, sort_order]
      )
      
      await connection.commit()
      return true
      
    } catch (error) {
      await connection.rollback()
      throw error
    } finally {
      connection.release()
    }
  }

  // 更新分镜排序
  static async updateSort(sortedIds) {
    const connection = await pool.getConnection()
    
    try {
      await connection.beginTransaction()
      
      // 批量更新排序
      for (let i = 0; i < sortedIds.length; i++) {
        await connection.execute(
          'UPDATE shots SET sort_order = ? WHERE id = ?',
          [i + 1, sortedIds[i]]
        )
      }
      
      await connection.commit()
      return true
      
    } catch (error) {
      await connection.rollback()
      throw error
    } finally {
      connection.release()
    }
  }

  // 检查分镜是否属于指定项目
  static async belongsToProject(shotId, projectId) {
    const [rows] = await pool.execute(
      'SELECT COUNT(*) as count FROM shots WHERE id = ? AND project_id = ?',
      [shotId, projectId]
    )
    return rows[0].count > 0
  }

  // 获取分镜所属的项目ID
  static async getProjectId(shotId) {
    const [rows] = await pool.execute(
      'SELECT project_id FROM shots WHERE id = ?',
      [shotId]
    )
    return rows[0]?.project_id
  }
}