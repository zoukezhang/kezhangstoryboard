import { pool } from '../config/database.js'

export class Project {
  // 创建项目
  static async create(userId, name) {
    const [result] = await pool.execute(
      'INSERT INTO projects (user_id, name) VALUES (?, ?)',
      [userId, name]
    )
    return result.insertId
  }

  // 获取用户的项目列表
  static async findByUserId(userId) {
    const [rows] = await pool.execute(`
      SELECT 
        id, 
        name, 
        shot_count, 
        create_time, 
        last_edit_time
      FROM projects 
      WHERE user_id = ? 
      ORDER BY last_edit_time DESC
    `, [userId])
    return rows
  }

  // 根据ID查找项目
  static async findById(id) {
    const [rows] = await pool.execute(
      'SELECT * FROM projects WHERE id = ?',
      [id]
    )
    return rows[0]
  }

  // 检查项目是否属于用户
  static async belongsToUser(projectId, userId) {
    const [rows] = await pool.execute(
      'SELECT COUNT(*) as count FROM projects WHERE id = ? AND user_id = ?',
      [projectId, userId]
    )
    return rows[0].count > 0
  }

  // 更新项目名称
  static async updateName(id, name) {
    const [result] = await pool.execute(
      'UPDATE projects SET name = ?, last_edit_time = CURRENT_TIMESTAMP WHERE id = ?',
      [name, id]
    )
    return result.affectedRows > 0
  }

  // 更新项目镜头数量
  static async updateShotCount(id) {
    await pool.execute(`
      UPDATE projects 
      SET shot_count = (
        SELECT COUNT(*) FROM shots WHERE project_id = ?
      ),
      last_edit_time = CURRENT_TIMESTAMP 
      WHERE id = ?
    `, [id, id])
  }

  // 删除项目
  static async delete(id) {
    const [result] = await pool.execute(
      'DELETE FROM projects WHERE id = ?',
      [id]
    )
    return result.affectedRows > 0
  }

  // 获取项目统计信息
  static async getStats(projectId) {
    const [rows] = await pool.execute(`
      SELECT 
        COUNT(s.id) as shot_count,
        COUNT(CASE WHEN s.image_url != '' THEN 1 END) as shots_with_image
      FROM shots s 
      WHERE s.project_id = ?
    `, [projectId])
    return rows[0]
  }
}