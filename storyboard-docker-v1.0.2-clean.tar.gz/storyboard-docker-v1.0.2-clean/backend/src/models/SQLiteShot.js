import { db } from '../config/sqlite.js'

export class SQLiteShot {
  // 添加分镜（支持批量）
  static create(projectId, count = 1) {
    const transaction = db.transaction(() => {
      // 获取当前最大排序号
      const maxStmt = db.prepare('SELECT COALESCE(MAX(sort_order), 0) as max_sort FROM shots WHERE project_id = ?')
      const maxResult = maxStmt.get(projectId)
      
      let currentSort = maxResult.max_sort
      const insertedIds = []
      
      // 批量插入分镜
      const insertStmt = db.prepare('INSERT INTO shots (project_id, sort_order) VALUES (?, ?)')
      
      for (let i = 0; i < count; i++) {
        currentSort++
        const result = insertStmt.run(projectId, currentSort)
        insertedIds.push(result.lastInsertRowid)
      }
      
      return insertedIds
    })
    
    return transaction()
  }

  // 获取项目的分镜列表
  static findByProjectId(projectId) {
    const stmt = db.prepare(`
      SELECT 
        id, 
        sort_order,
        tag, 
        description, 
        image_url,
        duration,
        shot_type,
        dialogue,
        sound_effect,
        animation,
        camera_movement,
        scene,
        character,
        character_state,
        narration,
        shooting_angle,
        create_time, 
        update_time
      FROM shots 
      WHERE project_id = ? 
      ORDER BY sort_order ASC
    `)
    return stmt.all(projectId)
  }

  // 根据ID查找分镜
  static findById(id) {
    const stmt = db.prepare('SELECT * FROM shots WHERE id = ?')
    return stmt.get(id)
  }

  // 更新分镜信息
  static update(id, data) {
    const {
      tag = '',
      description = '',
      image_url,
      duration = '',
      shot_type = '',
      dialogue = '',
      sound_effect = '',
      animation = '',
      camera_movement = '',
      scene = '',
      character = '',
      character_state = '',
      narration = '',
      shooting_angle = ''
    } = data
    
    let sql = 'UPDATE shots SET tag = ?, description = ?, duration = ?, shot_type = ?, dialogue = ?, sound_effect = ?, animation = ?, camera_movement = ?, scene = ?, character = ?, character_state = ?, narration = ?, shooting_angle = ?, update_time = CURRENT_TIMESTAMP'
    let params = [tag, description, duration, shot_type, dialogue, sound_effect, animation, camera_movement, scene, character, character_state, narration, shooting_angle]
    
    if (image_url !== undefined) {
      sql += ', image_url = ?'
      params.push(image_url)
    }
    
    sql += ' WHERE id = ?'
    params.push(id)
    
    const stmt = db.prepare(sql)
    const result = stmt.run(...params)
    return result.changes > 0
  }

  // 更新分镜图片
  static updateImage(id, imageUrl) {
    const stmt = db.prepare('UPDATE shots SET image_url = ?, update_time = CURRENT_TIMESTAMP WHERE id = ?')
    const result = stmt.run(imageUrl, id)
    return result.changes > 0
  }

  // 删除分镜
  static delete(id) {
    const transaction = db.transaction(() => {
      // 获取要删除的分镜信息
      const shotStmt = db.prepare('SELECT project_id, sort_order FROM shots WHERE id = ?')
      const shot = shotStmt.get(id)
      
      if (!shot) {
        throw new Error('分镜不存在')
      }
      
      // 删除分镜
      const deleteStmt = db.prepare('DELETE FROM shots WHERE id = ?')
      deleteStmt.run(id)
      
      // 重新排序后续分镜
      const updateStmt = db.prepare(`
        UPDATE shots 
        SET sort_order = sort_order - 1 
        WHERE project_id = ? AND sort_order > ?
      `)
      updateStmt.run(shot.project_id, shot.sort_order)
      
      return true
    })
    
    return transaction()
  }

  // 更新分镜排序
  static updateSort(sortedIds) {
    const transaction = db.transaction(() => {
      const stmt = db.prepare('UPDATE shots SET sort_order = ? WHERE id = ?')
      
      for (let i = 0; i < sortedIds.length; i++) {
        stmt.run(i + 1, sortedIds[i])
      }
      
      return true
    })
    
    return transaction()
  }

  // 检查分镜是否属于指定项目
  static belongsToProject(shotId, projectId) {
    const stmt = db.prepare('SELECT COUNT(*) as count FROM shots WHERE id = ? AND project_id = ?')
    const result = stmt.get(shotId, projectId)
    return result.count > 0
  }

  // 获取分镜所属的项目ID
  static getProjectId(shotId) {
    const stmt = db.prepare('SELECT project_id FROM shots WHERE id = ?')
    const result = stmt.get(shotId)
    return result?.project_id
  }
}