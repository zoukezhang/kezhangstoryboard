import { db } from '../config/sqlite.js'

export class SQLiteProject {
  // 创建项目
  static create(userId, name, fieldConfig = null) {
    const defaultConfig = '{"duration":false,"shot_type":false,"dialogue":false,"sound_effect":false,"animation":false,"camera_movement":false,"scene":false,"character":false,"character_state":false,"narration":false,"shooting_angle":false}'
    const config = fieldConfig ? JSON.stringify(fieldConfig) : defaultConfig
    
    const stmt = db.prepare('INSERT INTO projects (user_id, name, field_config) VALUES (?, ?, ?)')
    const result = stmt.run(userId, name, config)
    return result.lastInsertRowid
  }

  // 获取用户的项目列表
  static findByUserId(userId) {
    const stmt = db.prepare(`
      SELECT 
        id, 
        name, 
        shot_count, 
        field_config,
        create_time, 
        last_edit_time
      FROM projects 
      WHERE user_id = ? 
      ORDER BY last_edit_time DESC
    `)
    const projects = stmt.all(userId)
    
    // 解析字段配置 JSON 并获取缩略图
    return projects.map(project => ({
      ...project,
      field_config: project.field_config ? JSON.parse(project.field_config) : {
        duration: false,
        shot_type: false,
        dialogue: false,
        sound_effect: false,
        animation: false,
        camera_movement: false,
        scene: false,
        character: false,
        character_state: false,
        narration: false,
        shooting_angle: false
      },
      thumbnail: SQLiteProject.getThumbnail(project.id)
    }))
  }

  // 根据ID查找项目
  static findById(id) {
    const stmt = db.prepare('SELECT * FROM projects WHERE id = ?')
    const project = stmt.get(id)
    
    if (project && project.field_config) {
      project.field_config = JSON.parse(project.field_config)
    }
    
    return project
  }

  // 检查项目是否属于用户
  static belongsToUser(projectId, userId) {
    const stmt = db.prepare('SELECT COUNT(*) as count FROM projects WHERE id = ? AND user_id = ?')
    const result = stmt.get(projectId, userId)
    return result.count > 0
  }

  // 更新项目名称
  static updateName(id, name) {
    const stmt = db.prepare(`
      UPDATE projects 
      SET name = ?, last_edit_time = CURRENT_TIMESTAMP 
      WHERE id = ?
    `)
    const result = stmt.run(name, id)
    return result.changes > 0
  }

  // 更新项目镜头数量
  static updateShotCount(id) {
    const transaction = db.transaction(() => {
      // 获取镜头数量
      const countStmt = db.prepare('SELECT COUNT(*) as count FROM shots WHERE project_id = ?')
      const countResult = countStmt.get(id)
      
      // 更新项目镜头数量
      const updateStmt = db.prepare(`
        UPDATE projects 
        SET shot_count = ?, last_edit_time = CURRENT_TIMESTAMP 
        WHERE id = ?
      `)
      updateStmt.run(countResult.count, id)
    })
    
    transaction()
  }

  // 删除项目
  static delete(id) {
    const stmt = db.prepare('DELETE FROM projects WHERE id = ?')
    const result = stmt.run(id)
    return result.changes > 0
  }

  // 更新项目字段配置
  static updateFieldConfig(id, fieldConfig) {
    const stmt = db.prepare(`
      UPDATE projects 
      SET field_config = ?, last_edit_time = CURRENT_TIMESTAMP 
      WHERE id = ?
    `)
    const result = stmt.run(JSON.stringify(fieldConfig), id)
    return result.changes > 0
  }

  // 获取项目字段配置
  static getFieldConfig(id) {
    const stmt = db.prepare('SELECT field_config FROM projects WHERE id = ?')
    const result = stmt.get(id)
    
    if (result && result.field_config) {
      return JSON.parse(result.field_config)
    }
    
    return {
      duration: false,
      shot_type: false,
      dialogue: false,
      sound_effect: false,
      animation: false,
      camera_movement: false,
      scene: false,
      character: false,
      character_state: false,
      narration: false,
      shooting_angle: false
    }
  }

  // 获取项目缩略图（使用第一个分镜的图片）
  static getThumbnail(projectId) {
    const stmt = db.prepare(`
      SELECT image_url 
      FROM shots 
      WHERE project_id = ? AND image_url != '' 
      ORDER BY sort_order ASC 
      LIMIT 1
    `)
    const result = stmt.get(projectId)
    return result ? result.image_url : null
  }

  // 获取项目统计信息
  static getStats(projectId) {
    const stmt = db.prepare(`
      SELECT 
        COUNT(s.id) as shot_count,
        COUNT(CASE WHEN s.image_url != '' THEN 1 END) as shots_with_image
      FROM shots s 
      WHERE s.project_id = ?
    `)
    const result = stmt.get(projectId)
    return result || { shot_count: 0, shots_with_image: 0 }
  }
}