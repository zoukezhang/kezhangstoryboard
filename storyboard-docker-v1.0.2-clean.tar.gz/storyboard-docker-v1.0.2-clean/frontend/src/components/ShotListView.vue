<template>
  <div class="shot-list-view">
    <!-- 表格容器 -->
    <div class="table-container">
      <table class="shots-table">
        <!-- 表头 -->
        <thead>
          <tr>
            <th class="actions-col">操作</th>
            <th class="shot-number-col">镜号</th>
            <th class="thumbnail-col">缩略图</th>
            <th class="tag-col">标签</th>
            <th class="description-col">描述</th>
            <!-- 动态字段表头 -->
            <th v-if="fieldConfig.duration" class="field-col">时长</th>
            <th v-if="fieldConfig.shot_type" class="field-col">镜头</th>
            <th v-if="fieldConfig.dialogue" class="field-col">台词</th>
            <th v-if="fieldConfig.sound_effect" class="field-col">音效</th>
            <th v-if="fieldConfig.animation" class="field-col">动效</th>
            <th v-if="fieldConfig.camera_movement" class="field-col">运镜</th>
            <th v-if="fieldConfig.scene" class="field-col">场景</th>
            <th v-if="fieldConfig.character" class="field-col">角色</th>
            <th v-if="fieldConfig.character_state" class="field-col">人物状态</th>
            <th v-if="fieldConfig.narration" class="field-col">旁白</th>
            <th v-if="fieldConfig.shooting_angle" class="field-col">拍摄角度</th>
          </tr>
        </thead>
        
        <!-- 表体 -->
        <draggable 
          v-model="localShots" 
          @end="handleSortEnd"
          item-key="id"
          tag="tbody"
          handle=".drag-handle"
        >
            <template #item="{ element, index }">
              <tr class="shot-row" :class="{ 'editing': editingCells[element.id] }">
                <!-- 操作列 -->
                <td class="actions">
                  <el-button 
                    size="small" 
                    type="danger"
                    :icon="Delete"
                    @click="handleDelete(element)"
                  />
                </td>
                
                <!-- 镜号 -->
                <td class="shot-number drag-handle">{{ index + 1 }}</td>
                
                <!-- 缩略图 -->
                <td class="thumbnail" style="padding: 15px 10px;">
                  <div class="thumbnail-container" 
                       @mouseenter="hoveredThumbnail = element.id" 
                       @mouseleave="hoveredThumbnail = null">
                    <img 
                      v-if="element.image_url" 
                      :src="getImageUrl(element.image_url)" 
                      alt="缩略图"
                      class="thumbnail-image"
                    />
                    <div v-else class="thumbnail-placeholder" @click="uploadImage(element)">
                      <el-icon><Plus /></el-icon>
                      <span class="upload-text">点击上传</span>
                    </div>
                    
                    <!-- 悬停操作按钮 -->
                    <div v-if="element.image_url && hoveredThumbnail === element.id" 
                         class="thumbnail-actions">
                      <el-button 
                        size="small" 
                        type="primary"
                        :icon="Upload"
                        @click.stop="replaceImage(element)"
                        class="action-btn replace-btn"
                        title="替换图片">
                        替换
                      </el-button>
                      <el-button 
                        size="small" 
                        type="danger"
                        :icon="Delete"
                        @click.stop="deleteImage(element)"
                        class="action-btn delete-btn"
                        title="删除图片">
                        删除
                      </el-button>
                    </div>
                  </div>
                </td>
                
                <!-- 标签 -->
                <td class="editable-cell" style="padding: 0 8px;">
                  <EditableCell 
                    :value="element.tag"
                    :shotId="element.id"
                    field="tag"
                    placeholder="标签"
                    @update="handleCellUpdate"
                    @startEdit="handleStartEdit"
                    @endEdit="handleEndEdit"
                  />
                </td>
                
                <!-- 描述 -->
                <td class="editable-cell" style="padding: 0 8px;">
                  <EditableCell 
                    :value="element.description"
                    :shotId="element.id"
                    field="description"
                    type="textarea"
                    placeholder="描述"
                    @update="handleCellUpdate"
                    @startEdit="handleStartEdit"
                    @endEdit="handleEndEdit"
                  />
                </td>
                
                <!-- 动态字段 -->
                <td v-if="fieldConfig.duration" class="editable-cell" style="padding: 0 8px;">
                  <EditableCell 
                    :value="element.duration"
                    :shotId="element.id"
                    field="duration"
                    placeholder="时长"
                    @update="handleCellUpdate"
                    @startEdit="handleStartEdit"
                    @endEdit="handleEndEdit"
                  />
                </td>
                
                <td v-if="fieldConfig.shot_type" class="editable-cell" style="padding: 0 8px;">
                  <EditableCell 
                    :value="element.shot_type"
                    :shotId="element.id"
                    field="shot_type"
                    placeholder="镜头"
                    @update="handleCellUpdate"
                    @startEdit="handleStartEdit"
                    @endEdit="handleEndEdit"
                  />
                </td>
                
                <td v-if="fieldConfig.dialogue" class="editable-cell" style="padding: 0 8px;">
                  <EditableCell 
                    :value="element.dialogue"
                    :shotId="element.id"
                    field="dialogue"
                    type="textarea"
                    placeholder="台词"
                    @update="handleCellUpdate"
                    @startEdit="handleStartEdit"
                    @endEdit="handleEndEdit"
                  />
                </td>
                
                <td v-if="fieldConfig.sound_effect" class="editable-cell" style="padding: 0 8px;">
                  <EditableCell 
                    :value="element.sound_effect"
                    :shotId="element.id"
                    field="sound_effect"
                    placeholder="音效"
                    @update="handleCellUpdate"
                    @startEdit="handleStartEdit"
                    @endEdit="handleEndEdit"
                  />
                </td>
                
                <td v-if="fieldConfig.animation" class="editable-cell" style="padding: 0 8px;">
                  <EditableCell 
                    :value="element.animation"
                    :shotId="element.id"
                    field="animation"
                    placeholder="动效"
                    @update="handleCellUpdate"
                    @startEdit="handleStartEdit"
                    @endEdit="handleEndEdit"
                  />
                </td>
                
                <td v-if="fieldConfig.camera_movement" class="editable-cell" style="padding: 0 8px;">
                  <EditableCell 
                    :value="element.camera_movement"
                    :shotId="element.id"
                    field="camera_movement"
                    placeholder="运镜"
                    @update="handleCellUpdate"
                    @startEdit="handleStartEdit"
                    @endEdit="handleEndEdit"
                  />
                </td>
                
                <td v-if="fieldConfig.scene" class="editable-cell" style="padding: 0 8px;">
                  <EditableCell 
                    :value="element.scene"
                    :shotId="element.id"
                    field="scene"
                    placeholder="场景"
                    @update="handleCellUpdate"
                    @startEdit="handleStartEdit"
                    @endEdit="handleEndEdit"
                  />
                </td>
                
                <td v-if="fieldConfig.character" class="editable-cell" style="padding: 0 8px;">
                  <EditableCell 
                    :value="element.character"
                    :shotId="element.id"
                    field="character"
                    placeholder="角色"
                    @update="handleCellUpdate"
                    @startEdit="handleStartEdit"
                    @endEdit="handleEndEdit"
                  />
                </td>
                
                <td v-if="fieldConfig.character_state" class="editable-cell" style="padding: 0 8px;">
                  <EditableCell 
                    :value="element.character_state"
                    :shotId="element.id"
                    field="character_state"
                    placeholder="人物状态"
                    @update="handleCellUpdate"
                    @startEdit="handleStartEdit"
                    @endEdit="handleEndEdit"
                  />
                </td>
                
                <td v-if="fieldConfig.narration" class="editable-cell" style="padding: 0 8px;">
                  <EditableCell 
                    :value="element.narration"
                    :shotId="element.id"
                    field="narration"
                    type="textarea"
                    placeholder="旁白"
                    @update="handleCellUpdate"
                    @startEdit="handleStartEdit"
                    @endEdit="handleEndEdit"
                  />
                </td>
                
                <td v-if="fieldConfig.shooting_angle" class="editable-cell" style="padding: 0 8px;">
                  <EditableCell 
                    :value="element.shooting_angle"
                    :shotId="element.id"
                    field="shooting_angle"
                    placeholder="拍摄角度"
                    @update="handleCellUpdate"
                    @startEdit="handleStartEdit"
                    @endEdit="handleEndEdit"
                  />
                </td>
              </tr>
            </template>
        </draggable>
      </table>
    </div>
    
    <!-- 文件上传组件 -->
    <input 
      ref="fileInput" 
      type="file" 
      accept="image/*" 
      style="display: none"
      @change="handleFileChange"
    />
  </div>
</template>

<script setup>
import { ref, computed, watch } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Plus, Delete, Upload } from '@element-plus/icons-vue'
import draggable from 'vuedraggable'
import EditableCell from './EditableCell.vue'
import { getImageUrl } from '@/utils/common'

const props = defineProps({
  shots: {
    type: Array,
    default: () => []
  },
  fieldConfig: {
    type: Object,
    default: () => ({})
  }
})

const emit = defineEmits(['updateShot', 'deleteShot', 'uploadImage', 'sortShots'])

const fileInput = ref(null)
const currentUploadShot = ref(null)
const editingCells = ref({})
const hoveredThumbnail = ref(null) // 用于跟踪当前悬停的缩略图

// 本地分镜数据，用于拖拽排序
const localShots = ref([])

// 监听props.shots变化
watch(() => props.shots, (newShots) => {
  localShots.value = [...newShots]
}, { immediate: true })

// 处理单元格更新
const handleCellUpdate = (shotId, field, value) => {
  const updateData = { [field]: value }
  emit('updateShot', shotId, updateData)
}

// 处理开始编辑
const handleStartEdit = (shotId, field) => {
  if (!editingCells.value[shotId]) {
    editingCells.value[shotId] = new Set()
  }
  editingCells.value[shotId].add(field)
}

// 处理结束编辑
const handleEndEdit = (shotId, field) => {
  if (editingCells.value[shotId]) {
    editingCells.value[shotId].delete(field)
    if (editingCells.value[shotId].size === 0) {
      delete editingCells.value[shotId]
    }
  }
}

// 处理删除分镜
const handleDelete = (shot) => {
  emit('deleteShot', shot)
}

// 处理拖拽排序结束
const handleSortEnd = () => {
  const sortedIds = localShots.value.map(shot => shot.id)
  emit('sortShots', sortedIds)
}

// 上传图片
const uploadImage = (shot) => {
  currentUploadShot.value = shot
  fileInput.value?.click()
}

// 替换图片
const replaceImage = (shot) => {
  currentUploadShot.value = shot
  fileInput.value?.click()
}

// 删除图片
const deleteImage = async (shot) => {
  try {
    await ElMessageBox.confirm(
      '确定要删除这张图片吗？',
      '确认删除',
      {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }
    )
    
    // 发送更新请求，将image_url设置为null
    emit('updateShot', shot.id, { image_url: null })
    
    ElMessage.success('图片删除成功')
  } catch (error) {
    if (error !== 'cancel') {
      ElMessage.error('删除图片失败')
    }
  }
}

// 处理文件选择
const handleFileChange = async (event) => {
  const file = event.target.files[0]
  if (!file || !currentUploadShot.value) return
  
  // 检查文件类型
  if (!file.type.startsWith('image/')) {
    ElMessage.error('请选择图片文件')
    return
  }
  
  // 检查文件大小 (10MB)
  if (file.size > 10 * 1024 * 1024) {
    ElMessage.error('图片大小不能超过10MB')
    return
  }
  
  emit('uploadImage', currentUploadShot.value.id, file)
  
  // 清空文件输入和当前上传分镜
  event.target.value = ''
  currentUploadShot.value = null
}
</script>

<style scoped>
.shot-list-view {
  width: 100%;
  height: 100%;
  background: white;
  border-radius: 8px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

.table-container {
  width: 100%;
  overflow: auto;
  border-radius: 8px;
  border: 1px solid #e4e7ed;
}

.shots-table {
  width: 100%;
  border-collapse: collapse;
  font-size: 14px;
  background: white;
  min-width: 1900px; /* 增加最小宽度以适应更宽的缩略图列 */
  table-layout: fixed; /* 固定表格布局，确保列宽生效 */
}

.shots-table th {
  background: #f5f7fa;
  color: #606266;
  font-weight: 600;
  padding: 12px 8px;
  border-bottom: 2px solid #e4e7ed;
  border-right: 1px solid #e4e7ed;
  text-align: center;
  white-space: nowrap;
  position: sticky;
  top: 0;
  z-index: 10;
  overflow: hidden;
  text-overflow: ellipsis;
}

.shots-table td {
  padding: 0; /* 移除内边距避免影响高度 */
  border-bottom: 1px solid #e4e7ed;
  border-right: 1px solid #e4e7ed;
  vertical-align: top;
  overflow: hidden;
  word-wrap: break-word;
  height: 130px; /* 设置行高为130px */
  box-sizing: border-box; /* 确保边框包含在高度内 */
}

.shot-row:hover {
  background: #f9f9f9;
}

.shot-row.editing {
  background: #f0f9ff;
}

/* 列宽定义 */
.shot-number-col {
  width: 80px;
  min-width: 80px;
}

.thumbnail-col {
  width: 200px;
  min-width: 200px;
}

.tag-col {
  width: 120px;
  min-width: 120px;
}

.description-col {
  width: 200px;
  min-width: 200px;
}

.field-col {
  width: 150px;
  min-width: 150px;
}

.actions-col {
  width: 100px;
  min-width: 100px;
}

.shot-number {
  text-align: center;
  font-weight: 600;
  color: #409eff;
  cursor: move;
  user-select: none;
  width: 100%;
  height: 130px; /* 与行高保持一致 */
  padding: 0; /* 移除padding避免影响高度 */
  margin: 0; /* 移除margin避免影响高度 */
  font-size: 16px; /* 增大字体大小 */
  box-sizing: border-box; /* 确保边框和内边距包含在高度内 */
  line-height: 130px; /* 使用line-height实现垂直居中 */
  vertical-align: middle;
}

.drag-handle:hover {
  background: #f0f9ff;
  border-radius: 4px;
}

.thumbnail-container {
  width: 180px; /* 适应200px列宽，留有边距 */
  aspect-ratio: 16/9; /* 使用CSS aspect-ratio属性确保16:9比例 */
  border: 1px solid #e4e7ed;
  border-radius: 6px; /* 略微增加圆角 */
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  overflow: hidden;
  background: #f9f9f9;
  margin: 0 auto;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1); /* 添加轻微阴影增加美观 */
  position: relative; /* 为操作按钮定位 */
  transition: all 0.3s ease;
}

.thumbnail-container:hover {
  border-color: #409eff;
  box-shadow: 0 2px 8px rgba(64, 158, 255, 0.2);
}

.thumbnail-image {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.thumbnail-placeholder {
  color: #c0c4cc;
  font-size: 20px;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 8px;
}

.upload-text {
  font-size: 12px;
  color: #909399;
}

/* 缩略图操作按钮 */
.thumbnail-actions {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  display: flex;
  gap: 8px;
  background: rgba(0, 0, 0, 0.6);
  border-radius: 6px;
  padding: 8px;
  backdrop-filter: blur(4px);
  animation: fadeIn 0.2s ease-in;
}

@keyframes fadeIn {
  from {
    opacity: 0;
    transform: translate(-50%, -50%) scale(0.8);
  }
  to {
    opacity: 1;
    transform: translate(-50%, -50%) scale(1);
  }
}

.action-btn {
  padding: 4px 8px;
  font-size: 12px;
  border: none;
  border-radius: 4px;
  backdrop-filter: none;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  transition: all 0.2s ease;
}

.action-btn:hover {
  transform: translateY(-1px);
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
}

.replace-btn {
  background: #409eff;
  color: white;
}

.replace-btn:hover {
  background: #66b1ff;
}

.delete-btn {
  background: #f56c6c;
  color: white;
}

.delete-btn:hover {
  background: #f78989;
}

.editable-cell {
  width: 100%;
  max-width: inherit;
  overflow: hidden;
}

.actions {
  text-align: center;
  vertical-align: middle;
  padding: 0;
  height: 130px;
  width: 100px;
  box-sizing: border-box;
  line-height: 130px;
}

.actions .el-button {
  vertical-align: middle;
}

/* 滚动条样式 */
.table-container::-webkit-scrollbar {
  width: 8px;
  height: 8px;
}

.table-container::-webkit-scrollbar-track {
  background: #f1f1f1;
}

.table-container::-webkit-scrollbar-thumb {
  background: #c0c4cc;
  border-radius: 4px;
}

.table-container::-webkit-scrollbar-thumb:hover {
  background: #909399;
}
</style>