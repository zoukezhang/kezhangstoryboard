import { defineStore } from 'pinia'
import { ref } from 'vue'
import api from '@/utils/api'

export const useShotStore = defineStore('shot', () => {
  const shots = ref([])
  const currentShot = ref(null)
  const loading = ref(false)

  // 获取分镜列表
  const fetchShots = async (projectId) => {
    loading.value = true
    try {
      const response = await api.get(`/shot/list/${projectId}`)
      shots.value = response.data.data || []
      return { success: true }
    } catch (error) {
      console.error('获取分镜列表失败:', error)
      return { 
        success: false, 
        message: error.response?.data?.message || '获取分镜列表失败' 
      }
    } finally {
      loading.value = false
    }
  }

  // 添加分镜
  const addShots = async (projectId, count = 1) => {
    try {
      const response = await api.post('/shot/add', { project_id: projectId, count })
      await fetchShots(projectId) // 重新获取分镜列表
      return { 
        success: true, 
        data: response.data.data,
        message: `成功添加${count}个镜头` 
      }
    } catch (error) {
      console.error('添加分镜失败:', error)
      return { 
        success: false, 
        message: error.response?.data?.message || '添加分镜失败' 
      }
    }
  }

  // 更新分镜
  const updateShot = async (shotId, data) => {
    try {
      await api.put(`/shot/edit/${shotId}`, data)
      // 更新本地数据
      const index = shots.value.findIndex(shot => shot.id === shotId)
      if (index !== -1) {
        Object.assign(shots.value[index], data)
      }
      return { success: true, message: '分镜更新成功' }
    } catch (error) {
      console.error('更新分镜失败:', error)
      return { 
        success: false, 
        message: error.response?.data?.message || '更新分镜失败' 
      }
    }
  }

  // 删除分镜
  const deleteShot = async (shotId, projectId) => {
    try {
      await api.delete(`/shot/delete/${shotId}`)
      await fetchShots(projectId) // 重新获取分镜列表
      return { success: true, message: '分镜删除成功' }
    } catch (error) {
      console.error('删除分镜失败:', error)
      return { 
        success: false, 
        message: error.response?.data?.message || '删除分镜失败' 
      }
    }
  }

  // 更新分镜排序
  const updateShotsOrder = async (sortedIds) => {
    try {
      await api.put('/shot/sort', { sortedIds })
      return { success: true, message: '排序更新成功' }
    } catch (error) {
      console.error('排序更新失败:', error)
      return { 
        success: false, 
        message: error.response?.data?.message || '排序更新失败' 
      }
    }
  }

  // 上传分镜图片
  const uploadShotImage = async (shotId, file) => {
    try {
      const formData = new FormData()
      formData.append('image', file)
      formData.append('shotId', shotId)
      
      const response = await api.post('/shot/upload-image', formData, {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      })
      
      // 更新本地数据
      const index = shots.value.findIndex(shot => shot.id === shotId)
      if (index !== -1) {
        shots.value[index].image_url = response.data.data.image_url
      }
      
      return { 
        success: true, 
        data: response.data.data,
        message: '图片上传成功' 
      }
    } catch (error) {
      console.error('图片上传失败:', error)
      return { 
        success: false, 
        message: error.response?.data?.message || '图片上传失败' 
      }
    }
  }

  // 设置当前选中的分镜
  const setCurrentShot = (shot) => {
    currentShot.value = shot
  }

  // 清空分镜数据
  const clearShots = () => {
    shots.value = []
    currentShot.value = null
  }

  return {
    shots,
    currentShot,
    loading,
    fetchShots,
    addShots,
    updateShot,
    deleteShot,
    updateShotsOrder,
    uploadShotImage,
    setCurrentShot,
    clearShots
  }
})