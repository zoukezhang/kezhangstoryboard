# 分镜故事板 v1.0.2 Docker部署包

## 🚀 快速部署

```bash
# 1. 解压
tar -xzf storyboard-docker-v1.0.2-clean.tar.gz
cd storyboard-docker-v1.0.2-clean

# 2. 配置（重要）
cp .env.example .env
# 编辑 .env 文件，修改 JWT_SECRET

# 3. 部署
./deploy.sh
```

## 📋 访问地址
- **前端**: http://localhost
- **后端**: http://localhost:3002

## 🎯 新功能 (v1.0.2)
- ✨ **幻灯片缩略图优化**: 悬浮显示，毛玻璃效果
- 🖱️ **列表视图增强**: 缩略图悬停操作
- 🎨 **界面美化**: 响应式设计优化

## 🔧 系统要求
- Docker 20.10.0+
- Docker Compose 2.0.0+
- 内存 2GB+
- 存储 3GB+

## 🛠️ 管理命令
```bash
# 查看状态
docker-compose ps

# 查看日志
docker-compose logs -f

# 停止服务
docker-compose down

# 重启服务
docker-compose restart
```

## 🔒 生产部署建议
1. 修改 `.env` 中的 `JWT_SECRET`
2. 配置 HTTPS
3. 设置防火墙
4. 定期备份数据

---
**版本**: v1.0.2 测试版  
**技术栈**: Vue 3 + Node.js + Docker
