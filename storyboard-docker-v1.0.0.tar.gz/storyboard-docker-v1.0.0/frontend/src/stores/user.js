import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import api from '@/utils/api'

export const useUserStore = defineStore('user', () => {
  const user = ref(null)
  const token = ref(localStorage.getItem('token') || '')

  const isLoggedIn = computed(() => !!token.value)

  // 登录
  const login = async (credentials) => {
    try {
      const response = await api.post('/user/login', credentials)
      const { data } = response.data
      
      token.value = data.token
      user.value = data.user
      localStorage.setItem('token', data.token)
      
      return { success: true }
    } catch (error) {
      return { 
        success: false, 
        message: error.response?.data?.message || '登录失败' 
      }
    }
  }

  // 注册
  const register = async (userInfo) => {
    try {
      const response = await api.post('/user/register', userInfo)
      return { success: true, message: '注册成功' }
    } catch (error) {
      return { 
        success: false, 
        message: error.response?.data?.message || '注册失败' 
      }
    }
  }

  // 获取当前用户信息
  const getCurrentUser = async () => {
    try {
      const response = await api.get('/user/current')
      user.value = response.data.data
      return user.value
    } catch (error) {
      console.error('获取用户信息失败:', error)
      logout()
      return null
    }
  }

  // 修改密码
  const changePassword = async (passwordData) => {
    try {
      const response = await api.put('/user/password', passwordData)
      return { 
        success: true, 
        message: response.data.message || '密码修改成功' 
      }
    } catch (error) {
      return { 
        success: false, 
        message: error.response?.data?.message || '密码修改失败' 
      }
    }
  }

  // 退出登录
  const logout = () => {
    user.value = null
    token.value = ''
    localStorage.removeItem('token')
  }

  return {
    user,
    token,
    isLoggedIn,
    login,
    register,
    getCurrentUser,
    changePassword,
    logout
  }
})