<template>
  <div class="share-container">
    <div v-if="loading" class="loading">
      <el-loading-directive
        v-loading="loading"
        element-loading-text="加载中..."
        class="loading-wrapper"
      />
    </div>
    
    <div v-else-if="error" class="error-state">
      <el-result
        icon="error"
        :title="error"
        sub-title="链接可能已过期或不存在"
      />
    </div>
    
    <div v-else class="share-content">
      <!-- 分享标识 -->
      <div class="share-header">
        <div class="share-badge">
          <el-icon><Share /></el-icon>
          <span>分享的故事板</span>
        </div>
        <div class="share-info">
          <p>链接有效期至：{{ formatDate(shareData?.share_info?.expire_time) }}</p>
        </div>
      </div>

      <!-- 项目内容 -->
      <div class="storyboard">
        <div class="project-header">
          <h1>{{ shareData?.project?.name }}</h1>
          <div class="project-meta">
            <p><strong>总镜头数：</strong>{{ shareData?.project?.shot_count }}</p>
            <p><strong>创建时间：</strong>{{ formatDate(shareData?.project?.create_time) }}</p>
          </div>
        </div>

        <div class="shots-grid">
          <div v-if="!shareData?.shots?.length" class="empty-state">
            <el-icon size="64" color="#c0c4cc"><Film /></el-icon>
            <p>暂无分镜内容</p>
          </div>
          
          <div v-else>
            <div 
              v-for="(shot, index) in shareData.shots" 
              :key="shot.id"
              class="shot-card"
            >
              <div class="shot-number">
                镜头 {{ index + 1 }}
              </div>
              
              <div class="shot-image">
                <img 
                  v-if="shot.image_url" 
                  :src="shot.image_url"
                  :alt="`镜头${index + 1}`"
                  @error="handleImageError"
                />
                <div v-else class="no-image">
                  <el-icon size="32" color="#c0c4cc"><Picture /></el-icon>
                  <span>暂无图片</span>
                </div>
              </div>
              
              <div class="shot-info">
                <div v-if="shot.tag" class="shot-tag">
                  <strong>标签：</strong> {{ shot.tag }}
                </div>
                
                <div v-if="shot.description" class="shot-description">
                  <strong>描述：</strong>
                  <p>{{ shot.description }}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <!-- 底部信息 -->
      <div class="share-footer">
        <p>此内容通过 <strong>科长分镜故事板</strong> 分享</p>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRoute } from 'vue-router'
import { ElMessage } from 'element-plus'
import { Share, Film, Picture } from '@element-plus/icons-vue'
import { formatDate } from '@/utils/common'
import api from '@/utils/api'

const route = useRoute()

const loading = ref(true)
const error = ref('')
const shareData = ref(null)
const token = route.params.token

// 获取分享内容
const fetchShareData = async () => {
  try {
    loading.value = true
    error.value = ''
    
    const response = await api.get(`/share/view/${token}`)
    shareData.value = response.data.data
    
    // 设置页面标题
    if (shareData.value?.project?.name) {
      document.title = `${shareData.value.project.name} - 分享的故事板`
    }
  } catch (err) {
    console.error('获取分享内容失败:', err)
    if (err.response?.status === 404) {
      error.value = '分享链接不存在或已过期'
    } else {
      error.value = '加载失败，请稍后重试'
    }
  } finally {
    loading.value = false
  }
}

// 图片加载失败处理
const handleImageError = (event) => {
  event.target.style.display = 'none'
  console.error('图片加载失败:', event.target.src)
}

onMounted(() => {
  if (!token) {
    error.value = '无效的分享链接'
    loading.value = false
    return
  }
  
  fetchShareData()
})
</script>

<style scoped>
.share-container {
  min-height: 100vh;
  background: #f5f5f5;
  padding: 20px;
}

.loading {
  height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
}

.loading-wrapper {
  min-height: 300px;
  width: 100%;
}

.error-state {
  height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
}

.share-content {
  max-width: 1200px;
  margin: 0 auto;
}

.share-header {
  text-align: center;
  margin-bottom: 30px;
  padding: 20px;
  background: white;
  border-radius: 8px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

.share-badge {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  background: #e1f3ff;
  color: #0066cc;
  padding: 8px 16px;
  border-radius: 20px;
  font-weight: 600;
  margin-bottom: 10px;
}

.share-info {
  color: #666;
  font-size: 14px;
}

.share-info p {
  margin: 0;
}

.storyboard {
  background: white;
  border-radius: 8px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  overflow: hidden;
}

.project-header {
  padding: 30px;
  border-bottom: 2px solid #e4e7ed;
  text-align: center;
}

.project-header h1 {
  margin: 0 0 20px 0;
  color: #333;
  font-size: 28px;
}

.project-meta {
  display: flex;
  justify-content: center;
  gap: 30px;
  color: #666;
  font-size: 14px;
}

.project-meta p {
  margin: 0;
}

.shots-grid {
  padding: 30px;
}

.empty-state {
  text-align: center;
  padding: 80px 20px;
  color: #999;
}

.empty-state p {
  margin: 20px 0;
  font-size: 16px;
}

.shot-card {
  display: grid;
  grid-template-columns: auto 1fr;
  grid-template-rows: auto 1fr;
  gap: 20px;
  padding: 20px;
  border: 1px solid #e4e7ed;
  border-radius: 8px;
  margin-bottom: 20px;
  background: #fafafa;
}

.shot-number {
  grid-column: 1 / -1;
  font-size: 18px;
  font-weight: 600;
  color: #409eff;
  padding: 10px 15px;
  background: white;
  border-radius: 6px;
  border-left: 4px solid #409eff;
}

.shot-image {
  width: 300px;
  height: 200px;
  border: 1px solid #e4e7ed;
  border-radius: 8px;
  overflow: hidden;
  display: flex;
  align-items: center;
  justify-content: center;
  background: white;
}

.shot-image img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.no-image {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 10px;
  color: #999;
}

.shot-info {
  display: flex;
  flex-direction: column;
  gap: 15px;
}

.shot-tag {
  font-size: 16px;
  color: #333;
}

.shot-description {
  color: #666;
}

.shot-description strong {
  color: #333;
}

.shot-description p {
  margin: 5px 0 0 0;
  line-height: 1.6;
  white-space: pre-wrap;
}

.share-footer {
  text-align: center;
  padding: 20px;
  margin-top: 30px;
  color: #999;
  font-size: 14px;
}

.share-footer p {
  margin: 0;
}

/* 移动端适配 */
@media (max-width: 768px) {
  .share-container {
    padding: 10px;
  }
  
  .project-meta {
    flex-direction: column;
    gap: 10px;
  }
  
  .shot-card {
    grid-template-columns: 1fr;
    gap: 15px;
  }
  
  .shot-image {
    width: 100%;
    height: 200px;
  }
  
  .shots-grid {
    padding: 20px;
  }
}

/* 打印样式 */
@media print {
  .share-header {
    display: none;
  }
  
  .share-footer {
    display: none;
  }
  
  .share-container {
    padding: 0;
  }
  
  .shot-card {
    page-break-inside: avoid;
    margin-bottom: 30px;
  }
}
</style>