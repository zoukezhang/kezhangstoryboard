import express from 'express'
import cors from 'cors'
import helmet from 'helmet'
import rateLimit from 'express-rate-limit'
import dotenv from 'dotenv'
import path from 'path'
import { fileURLToPath } from 'url'

// 路由导入
import userRoutes from './routes/user.js'
import projectRoutes from './routes/project.js'
import shotRoutes from './routes/shot.js'
import exportRoutes from './routes/export.js'
import shareRoutes from './routes/share.js'

// 配置和中间件导入
import { testSQLiteConnection } from './config/sqlite.js'
import { initSQLiteDatabase } from './config/sqlite-init.js'
import { errorHandler } from './middleware/errorHandler.js'

// 获取当前文件路径
const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

// 加载环境变量
dotenv.config()

const app = express()
const PORT = process.env.PORT || 3002

// 安全中间件
app.use(helmet({
  crossOriginResourcePolicy: { policy: "cross-origin" }
}))

// CORS配置
app.use(cors({
  origin: process.env.CORS_ORIGIN || 'http://localhost:3000',
  credentials: true
}))

// 限流配置
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15分钟
  max: process.env.NODE_ENV === 'production' ? 100 : 1000, // 生产环境100次，开发环境1000次
  message: {
    code: 429,
    message: '请求过于频繁，请稍后再试'
  },
  skip: (req) => {
    // 开发环境下跳过本地请求的限制
    return process.env.NODE_ENV !== 'production' && 
           (req.ip === '127.0.0.1' || req.ip === '::1' || req.ip === '::ffff:127.0.0.1')
  }
})
app.use(limiter)

// 请求解析中间件
app.use(express.json({ limit: '10mb' }))
app.use(express.urlencoded({ extended: true, limit: '10mb' }))

// 请求日志中间件
app.use((req, res, next) => {
  console.log(`${new Date().toISOString()} - ${req.method} ${req.url}`)
  console.log('Request headers:', req.headers)
  console.log('Request body:', req.body)
  next()
})

// 静态文件服务
app.use('/uploads', express.static(path.join(__dirname, '../uploads')))

// API路由
app.use('/api/user', userRoutes)
app.use('/api/project', projectRoutes)
app.use('/api/shot', shotRoutes)
app.use('/api/export', exportRoutes)
app.use('/api/share', shareRoutes)

console.log('✅ API路由已挂载')
console.log('- /api/user')
console.log('- /api/project')
console.log('- /api/shot')
console.log('- /api/export')
console.log('- /api/share')

// 健康检查接口
app.get('/api/health', (req, res) => {
  res.json({
    code: 200,
    message: '服务运行正常',
    data: {
      status: 'ok',
      timestamp: new Date().toISOString()
    }
  })
})

// 404处理
app.use((req, res) => {
  res.status(404).json({
    code: 404,
    message: '接口不存在'
  })
})

// 错误处理中间件
app.use(errorHandler)

// 启动服务器
const startServer = async () => {
  try {
    // 测试SQLite数据库连接
    testSQLiteConnection()
    
    // 初始化SQLite数据库表
    initSQLiteDatabase()
    
    // 启动服务器
    app.listen(PORT, () => {
      console.log(`🚀 服务器已启动: http://localhost:${PORT}`)
      console.log(`📝 API文档: http://localhost:${PORT}/api/health`)
      console.log(`🌍 环境: ${process.env.NODE_ENV || 'development'}`)
      console.log(`💾 数据库: SQLite （测试模式）`)
    })
  } catch (error) {
    console.error('❌ 服务器启动失败:', error)
    process.exit(1)
  }
}

startServer()

export default app