import { db } from '../config/sqlite.js'

export class SQLiteUser {
  // 创建用户
  static create(userData) {
    const { username, email, password } = userData
    const stmt = db.prepare('INSERT INTO users (username, email, password) VALUES (?, ?, ?)')
    const result = stmt.run(username, email, password)
    return result.lastInsertRowid
  }

  // 根据邮箱查找用户
  static findByEmail(email) {
    const stmt = db.prepare('SELECT * FROM users WHERE email = ?')
    return stmt.get(email)
  }

  // 根据ID查找用户
  static findById(id) {
    const stmt = db.prepare('SELECT id, username, email, register_time FROM users WHERE id = ?')
    return stmt.get(id)
  }

  // 检查邮箱是否存在
  static emailExists(email) {
    const stmt = db.prepare('SELECT COUNT(*) as count FROM users WHERE email = ?')
    const result = stmt.get(email)
    return result.count > 0
  }

  // 更新密码
  static updatePassword(id, newPassword) {
    const stmt = db.prepare('UPDATE users SET password = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?')
    const result = stmt.run(newPassword, id)
    return result.changes > 0
  }

  // 获取用户统计信息
  static getStats(userId) {
    const stmt = db.prepare(`
      SELECT 
        COUNT(p.id) as project_count,
        COALESCE(SUM(p.shot_count), 0) as total_shots
      FROM projects p 
      WHERE p.user_id = ?
    `)
    return stmt.get(userId) || { project_count: 0, total_shots: 0 }
  }
}