# 快速开始

## 1. 系统要求
- Docker 20.10.0+
- Docker Compose 2.0.0+
- 2GB+ RAM, 5GB+ 存储空间

## 2. 部署步骤

```bash
# 1. 解压部署包
tar -xzf storyboard-docker-v1.0.0.tar.gz
cd storyboard-docker-v1.0.0

# 2. 配置环境变量（可选）
cp .env.example .env
nano .env  # 修改JWT_SECRET等配置

# 3. 运行部署脚本
./deploy.sh

# 4. 访问应用
# 前端: http://localhost
# 后端: http://localhost:3002
```

## 3. 测试账号
- 邮箱: test@example.com  
- 密码: 123456

详细说明请查看 DOCKER_DEPLOY.md
