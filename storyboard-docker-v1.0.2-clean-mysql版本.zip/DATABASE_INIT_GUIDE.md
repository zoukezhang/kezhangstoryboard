# 数据库初始化指南

## 问题说明

在将分镜工具部署到新服务器时，可能会遇到"却表"（缺少表）的问题。这是因为：
1. Docker部署时默认使用的 `backend/src/config/init.js` 脚本中缺少了许多必要的字段定义
2. 脚本中存在一些导入错误，导致无法正确执行

## 解决方案

我们已经做了以下修复：
1. 完善了 `backend/src/config/init.js` 中的 shots 表结构，添加了所有必要的字段
2. 修复了 `backend/src/config/database.js` 中缺少 mysql 导入的问题
3. 修复了脚本间的导入路径问题
4. 同时也完善了 `backend/init-mysql-database.js` 作为独立的初始化脚本

## 使用方法

### 数据库初始化的两种方式

#### 方式一：Docker部署时的自动初始化（推荐）

当您使用Docker部署应用时，系统会自动通过以下流程初始化数据库：

1. Docker容器启动时执行 `npm start` 命令
2. `npm start` 执行 `src/server.js` 文件
3. 在 `server.js` 中调用 `initDatabase()` 函数
4. `initDatabase()` 函数来自 `./config/init.js`，负责创建所有必要的表

**注意：** 我们已经修复了 `init.js` 文件中的表结构和导入问题，现在它可以正确创建完整的数据库表。

#### 方式二：手动运行独立的初始化脚本

如果您需要在非Docker环境中初始化数据库，或者需要重新初始化数据库，可以使用以下步骤：

1. **确保已安装依赖**
   ```bash
   cd backend
   npm install
   ```

2. **配置环境变量**
   确保您的 `.env` 文件包含正确的数据库配置信息：
   ```
   # MySQL数据库配置
   DB_HOST=localhost
   DB_PORT=3306
   DB_USER=root
   DB_PASSWORD=your_password
   DB_DATABASE=storyboard
   
   # 应用配置
   NODE_ENV=production
   PORT=3002
   ```

3. **运行初始化脚本**
   执行以下命令来运行修复后的数据库初始化脚本：
   ```bash
   cd backend
   node init-mysql-database.js
   ```
   
   或者，由于我们已经添加了执行权限，您也可以直接运行：
   ```bash
   cd backend
   ./init-mysql-database.js
   ```

### 4. 验证初始化结果

脚本运行成功后，您应该看到类似以下的输出：

```
=== 开始MySQL数据库初始化 ===
🔌 正在测试数据库连接...
✅ 数据库连接成功
📋 开始创建数据库表...
   正在创建 users 表...
   正在创建 projects 表...
   正在创建 shots 表...
   正在创建 shares 表...
✅ 数据库表创建成功

✅ MySQL数据库初始化成功！

所有必要的表已创建：
1. users - 用户表（包含所有用户信息）
2. projects - 项目表（存储分镜项目基本信息）
3. shots - 分镜表（包含分镜内容、图片和所有自定义字段）
4. shares - 分享表（存储项目分享信息）

📝 数据库配置信息:
   - 主机: localhost
   - 端口: 3306
   - 数据库: storyboard
   - 用户: root

🚀 初始化完成！您现在可以启动应用程序了。
   后端启动命令: npm start
```

## 故障排除

如果初始化过程中遇到错误，请检查以下几点：

1. **MySQL服务是否正在运行**
   - 可以使用 `systemctl status mysql`（Linux）或通过系统偏好设置检查（Mac）

2. **.env文件中的数据库配置是否正确**
   - 确保用户名、密码、数据库名和端口号正确

3. **数据库用户是否有足够的权限**
   - 确保数据库用户具有创建表的权限

4. **手动创建表**
   - 如果自动初始化失败，您可以手动创建表：
     ```bash
     # 1. 登录MySQL
     mysql -u root -p
     
     # 2. 创建数据库
     CREATE DATABASE IF NOT EXISTS storyboard;
     
     # 3. 使用数据库
     USE storyboard;
     
     # 4. 手动创建表（可以从错误日志中复制CREATE TABLE语句）
     ```

## Docker部署环境中的使用

如果您使用Docker部署，可以在启动容器后通过以下方式运行初始化脚本：

```bash
docker exec -it [backend_container_name] node init-mysql-database.js
```

## 注意事项

- 此脚本只需要在首次部署时运行一次
- 如果数据库已经存在并且包含数据，脚本会跳过表的创建，不会影响现有数据
- 每次修改数据库结构后，建议更新此初始化脚本以保持同步

## 支持

如果您在使用过程中遇到任何问题，请检查错误日志并参考以上故障排除指南。如果问题仍然存在，可以联系技术支持获取帮助。