#!/bin/bash

# 分镜故事板 Docker 部署脚本
# Version: 1.0.0

set -e

echo "🚀 开始部署分镜故事板应用..."

# 检查Docker是否安装
if ! command -v docker &> /dev/null; then
    echo "❌ Docker未安装，请先安装Docker"
    exit 1
fi

if ! command -v docker-compose &> /dev/null; then
    echo "❌ Docker Compose未安装，请先安装Docker Compose"
    exit 1
fi

# 停止现有容器
echo "🔄 停止现有容器..."
docker-compose down || true

# 清理未使用的镜像（可选）
echo "🧹 清理Docker资源..."
docker system prune -f || true

# 构建并启动服务
echo "🏗️  构建并启动服务..."
docker-compose up --build -d

# 等待服务启动
echo "⏳ 等待服务启动..."
sleep 30

# 检查服务状态
echo "🔍 检查服务状态..."
if docker-compose ps | grep -q "Up"; then
    echo "✅ 部署成功！"
    echo ""
    echo "📋 访问信息："
    echo "   前端应用: http://localhost"
    echo "   后端API:  http://localhost:3002"
    echo "   健康检查: http://localhost:3002/api/health"
    echo ""
    echo "📊 服务状态："
    docker-compose ps
    echo ""
    echo "📝 查看日志命令："
    echo "   所有服务: docker-compose logs -f"
    echo "   前端服务: docker-compose logs -f frontend"
    echo "   后端服务: docker-compose logs -f backend"
    echo ""
    echo "🛑 停止服务命令："
    echo "   docker-compose down"
else
    echo "❌ 部署失败，请检查日志："
    docker-compose logs
    exit 1
fi