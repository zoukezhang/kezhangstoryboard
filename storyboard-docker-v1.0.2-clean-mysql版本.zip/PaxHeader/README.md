30 mtime=1756268408.629816679
57 LIBARCHIVE.xattr.com.apple.provenance=AQIA/BGTv9sFdcY
49 SCHILY.xattr.com.apple.provenance= ����u�
