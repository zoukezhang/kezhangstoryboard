import { db } from '../config/sqlite.js'

export class SQLiteShare {
  // 创建分享链接
  static create(projectId, token, expireTime) {
    const stmt = db.prepare('INSERT INTO shares (project_id, token, expire_time) VALUES (?, ?, ?)')
    const result = stmt.run(projectId, token, expireTime)
    return result.lastInsertRowid
  }

  // 根据token查找分享记录
  static findByToken(token) {
    const stmt = db.prepare(`
      SELECT s.*, p.name as project_name, p.user_id
      FROM shares s
      JOIN projects p ON s.project_id = p.id
      WHERE s.token = ? AND s.expire_time > datetime('now')
    `)
    return stmt.get(token)
  }

  // 检查分享是否有效
  static isValid(token) {
    const stmt = db.prepare(`
      SELECT COUNT(*) as count 
      FROM shares 
      WHERE token = ? AND expire_time > datetime('now')
    `)
    const result = stmt.get(token)
    return result.count > 0
  }

  // 删除过期的分享记录
  static deleteExpired() {
    const stmt = db.prepare("DELETE FROM shares WHERE expire_time <= datetime('now')")
    const result = stmt.run()
    return result.changes
  }

  // 获取项目的分享记录
  static findByProjectId(projectId) {
    const stmt = db.prepare(`
      SELECT token, expire_time, created_at
      FROM shares 
      WHERE project_id = ? AND expire_time > datetime('now')
      ORDER BY created_at DESC
    `)
    return stmt.all(projectId)
  }

  // 删除项目的所有分享记录
  static deleteByProjectId(projectId) {
    const stmt = db.prepare('DELETE FROM shares WHERE project_id = ?')
    const result = stmt.run(projectId)
    return result.changes
  }
}