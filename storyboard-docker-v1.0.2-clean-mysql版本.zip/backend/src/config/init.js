import { pool } from './database.js'

const initDatabase = async () => {
  try {
    // 创建用户表
    await pool.execute(`
      CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(50) NOT NULL,
        email VARCHAR(100) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL,
        register_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `)

    // 创建项目表
    await pool.execute(`
      CREATE TABLE IF NOT EXISTS projects (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        name VARCHAR(100) NOT NULL,
        shot_count INT DEFAULT 0,
        field_config TEXT,
        create_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        last_edit_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `)

    // 创建分镜表
    await pool.execute(`
      CREATE TABLE IF NOT EXISTS shots (
        id INT AUTO_INCREMENT PRIMARY KEY,
        project_id INT NOT NULL,
        sort_order INT NOT NULL DEFAULT 0,
        tag VARCHAR(100) DEFAULT '',
        description TEXT,
        image_url VARCHAR(500) DEFAULT '',
        duration TEXT,
        shot_type TEXT,
        dialogue TEXT,
        sound_effect TEXT,
        animation TEXT,
        camera_movement TEXT,
        scene TEXT,
        characters TEXT,
        character_state TEXT,
        narration TEXT,
        shooting_angle TEXT,
        create_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        update_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
        INDEX idx_project_sort (project_id, sort_order)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `)

    // 创建分享表
    await pool.execute(`
      CREATE TABLE IF NOT EXISTS shares (
        id INT AUTO_INCREMENT PRIMARY KEY,
        project_id INT NOT NULL,
        token VARCHAR(255) NOT NULL UNIQUE,
        expire_time TIMESTAMP NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `)

    console.log('✅ 数据库表创建成功')
  } catch (error) {
    console.error('❌ 数据库初始化失败:', error)
    throw error
  }
}

export { initDatabase }