import Database from 'better-sqlite3'
import path from 'path'
import { fileURLToPath } from 'url'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

// 创建SQLite数据库连接
const db = new Database(path.join(__dirname, '../../database.sqlite'), {
  verbose: console.log
})

// 设置UTF-8编码支持
db.pragma('encoding = "UTF-8"')
db.pragma('foreign_keys = ON')

// 测试数据库连接
const testSQLiteConnection = () => {
  try {
    db.exec('SELECT 1')
    console.log('✅ SQLite数据库连接成功')
  } catch (error) {
    console.error('❌ SQLite数据库连接失败:', error.message)
  }
}

export { db, testSQLiteConnection }