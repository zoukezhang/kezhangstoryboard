import bcrypt from 'bcryptjs'
import crypto from 'crypto'

// 密码加密
export const hashPassword = async (password) => {
  const salt = await bcrypt.genSalt(10)
  return bcrypt.hash(password, salt)
}

// 密码验证
export const verifyPassword = async (password, hashedPassword) => {
  return bcrypt.compare(password, hashedPassword)
}

// 生成随机字符串
export const generateRandomString = (length = 32) => {
  return crypto.randomBytes(length).toString('hex')
}

// 统一响应格式
export const createResponse = (code = 200, message = '成功', data = null) => {
  return {
    code,
    message,
    ...(data !== null && { data })
  }
}

// 成功响应
export const successResponse = (res, data = null, message = '操作成功') => {
  res.json(createResponse(200, message, data))
}

// 错误响应
export const errorResponse = (res, code = 500, message = '操作失败') => {
  res.status(code).json(createResponse(code, message))
}

// 检查用户权限
export const checkOwnership = (resourceUserId, currentUserId) => {
  return parseInt(resourceUserId) === parseInt(currentUserId)
}

// 文件扩展名验证
export const isValidImageExt = (filename) => {
  const allowedExts = ['.jpg', '.jpeg', '.png', '.gif', '.webp']
  const ext = filename.toLowerCase().substring(filename.lastIndexOf('.'))
  return allowedExts.includes(ext)
}