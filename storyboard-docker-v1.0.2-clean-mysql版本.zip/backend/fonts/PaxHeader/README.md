30 mtime=1756268408.701718421
57 LIBARCHIVE.xattr.com.apple.provenance=AQIA/BGTv9sFdcY
49 SCHILY.xattr.com.apple.provenance= ����u�
69 LIBARCHIVE.xattr.com.apple.lastuseddate#PS=QSqraAAAAAB4nTwsAAAAAA
59 SCHILY.xattr.com.apple.lastuseddate#PS=A*�h    x�<,    
