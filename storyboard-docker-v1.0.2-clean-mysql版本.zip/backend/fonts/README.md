# 字体文件说明

本目录包含项目PDF导出功能所需的字体文件，确保在不同环境下都能正确显示中文内容。

## 字体文件列表

### 1. Noto Sans CJK SC Regular (首选)
- **文件名**: NotoSansCJKsc-Regular.otf
- **文件大小**: ~16MB
- **描述**: Google 开源中文字体，支持简体中文
- **优势**: 开源字体，PDFKit兼容性最佳，中文显示效果优秀
- **适用**: 所有平台，无许可证限制

### 2. Hiragino Sans GB.ttc (备选)
- **文件大小**: ~23MB
- **描述**: 苹果系统自带的中文字体，支持简体中文、繁体中文
- **优势**: 中文显示效果最佳，字形美观
- **限制**: TTC格式，PDFKit不支持
- **适用**: macOS 和支持 TrueType Collection 的系统

### 3. Arial.ttf (基础备选)
- **文件大小**: ~773KB
- **描述**: 标准Arial字体，主要支持拉丁字符
- **优势**: 文件小，兼容性极佳
- **适用**: 所有平台，但不支持中文

## 字体加载顺序

系统会按以下顺序尝试加载字体：

1. **Noto Sans CJK SC Regular** - 最佳中文显示效果（首选）
2. **Arial.ttf** - 基础英文字体
3. **Helvetica** (内置) - 最后的备选方案

## 部署说明

### 开发环境
字体文件已包含在项目中，无需额外配置。

### 生产环境
1. 确保 `fonts/` 目录及其中的字体文件被正确部署
2. 验证字体文件的读取权限
3. 如需添加其他字体，请放置在此目录下并更新 `export.js` 中的字体路径

### Docker部署
在 Dockerfile 中确保字体目录被正确复制：
```dockerfile
COPY fonts/ /app/fonts/
```

## 许可证说明

- **Noto Sans CJK SC Regular**: Google 开源字体，免费使用
- **Hiragino Sans GB.ttc**: 苹果系统字体，仅供个人和开发使用
- **Arial.ttf**: 标准系统字体

**注意**: 在商业部署时，请确保遵守相应的字体许可证要求。

## 故障排除

### 中文显示为方框或问号
1. 检查字体文件是否存在
2. 验证文件路径是否正确
3. 确认文件读取权限

### 字体加载失败
查看控制台日志中的字体加载信息：
```
字体目录: /path/to/fonts
尝试加载的字体路径: [...]
找到字体文件: /path/to/font.ttc
中文字体加载成功: /path/to/font.ttc
```

### 添加新字体
1. 将字体文件放置在 `fonts/` 目录下
2. 在 `export.js` 的 `fontPaths` 数组中添加新路径
3. 重启应用程序

## 文件来源

这些字体文件来源：
- **Noto Sans CJK SC Regular**: Google Fonts (开源)
- **Hiragino Sans GB.ttc**: `/System/Library/Fonts/Hiragino Sans GB.ttc`
- **Arial.ttf**: `/System/Library/Fonts/Supplemental/Arial.ttf`

如需在其他系统上使用，请确保您有合法的字体文件使用权限。