#!/usr/bin/env node
/**
 * MySQL数据库初始化脚本
 * 用于创建分镜工具所需的所有数据库表
 */
import mysql from 'mysql2/promise'
import dotenv from 'dotenv'
import path from 'path'
import { fileURLToPath } from 'url'

// 设置文件路径，确保能正确加载.env文件
const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)
dotenv.config({ path: path.join(__dirname, '../.env') })

// 创建数据库连接池
const createPool = () => {
  return mysql.createPool({
    host: process.env.DB_HOST || 'localhost',
    port: process.env.DB_PORT || 3306,
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    database: process.env.DB_DATABASE || 'storyboard',
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0,
    charset: 'utf8mb4'
  })
}

// 数据库初始化函数 - 创建所有必要的表
const initDatabase = async (pool) => {
  try {
    console.log('📋 开始创建数据库表...')
    
    // 创建用户表
    console.log('   正在创建 users 表...')
    await pool.execute(`
      CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(50) NOT NULL,
        email VARCHAR(100) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL,
        register_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `)

    // 创建项目表
    console.log('   正在创建 projects 表...')
    await pool.execute(`
      CREATE TABLE IF NOT EXISTS projects (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        name VARCHAR(100) NOT NULL,
        shot_count INT DEFAULT 0,
        field_config TEXT,
        create_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        last_edit_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `)

    // 创建分镜表
    console.log('   正在创建 shots 表...')
    await pool.execute(`
      CREATE TABLE IF NOT EXISTS shots (
        id INT AUTO_INCREMENT PRIMARY KEY,
        project_id INT NOT NULL,
        sort_order INT NOT NULL DEFAULT 0,
        tag VARCHAR(100) DEFAULT '',
        description TEXT,
        image_url VARCHAR(500) DEFAULT '',
        duration TEXT DEFAULT '',
        shot_type TEXT DEFAULT '',
        dialogue TEXT DEFAULT '',
        sound_effect TEXT DEFAULT '',
        animation TEXT DEFAULT '',
        camera_movement TEXT DEFAULT '',
        scene TEXT DEFAULT '',
        character TEXT DEFAULT '',
        character_state TEXT DEFAULT '',
        narration TEXT DEFAULT '',
        shooting_angle TEXT DEFAULT '',
        create_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        update_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
        INDEX idx_project_sort (project_id, sort_order)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `)

    // 创建分享表
    console.log('   正在创建 shares 表...')
    await pool.execute(`
      CREATE TABLE IF NOT EXISTS shares (
        id INT AUTO_INCREMENT PRIMARY KEY,
        project_id INT NOT NULL,
        token VARCHAR(255) NOT NULL UNIQUE,
        expire_time TIMESTAMP NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `)

    console.log('✅ 数据库表创建成功')
  } catch (error) {
    console.error('❌ 数据库初始化失败:', error)
    throw error
  }
}

// 主函数
const runInitialization = async () => {
  console.log('=== 开始MySQL数据库初始化 ===')
  
  try {
    // 创建数据库连接池
    const pool = createPool()
    
    // 测试数据库连接
    console.log('🔌 正在测试数据库连接...')
    const connection = await pool.getConnection()
    console.log('✅ 数据库连接成功')
    connection.release()
    
    // 初始化数据库表
    await initDatabase(pool)
    
    console.log('\n✅ MySQL数据库初始化成功！')
    console.log('\n所有必要的表已创建：')
    console.log('1. users - 用户表（包含所有用户信息）')
    console.log('2. projects - 项目表（存储分镜项目基本信息）')
    console.log('3. shots - 分镜表（包含分镜内容、图片和所有自定义字段）')
    console.log('4. shares - 分享表（存储项目分享信息）')
    
    console.log('\n📝 数据库配置信息:')
    console.log(`   - 主机: ${process.env.DB_HOST || 'localhost'}`)
    console.log(`   - 端口: ${process.env.DB_PORT || 3306}`)
    console.log(`   - 数据库: ${process.env.DB_DATABASE || 'storyboard'}`)
    console.log(`   - 用户: ${process.env.DB_USER || 'root'}`)
    
    console.log('\n🚀 初始化完成！您现在可以启动应用程序了。')
    console.log('   后端启动命令: npm start')
    
  } catch (error) {
    console.error('\n❌ MySQL数据库初始化失败:', error.message)
    console.error('\n错误详情:', error)
    console.error('\n请检查以下几点:')
    console.error('1. MySQL服务是否正在运行')
    console.error('2. .env文件中的数据库配置是否正确')
    console.error('3. 数据库用户是否有足够的权限创建表')
    console.error('4. 确保安装了所有依赖: npm install')
    
    // 提供手动创建表的SQL语句提示
    console.error('\n💡 如果自动初始化失败，您可以手动创建表:')
    console.error('   1. 登录MySQL: mysql -u root -p')
    console.error('   2. 创建数据库: CREATE DATABASE IF NOT EXISTS storyboard;')
    console.error('   3. 使用数据库: USE storyboard;')
    console.error('   4. 然后运行上面显示的CREATE TABLE语句')
  }
}

// 运行初始化
runInitialization()