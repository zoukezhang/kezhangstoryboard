#!/bin/bash
echo "🛑 停止分镜故事板..."
docker-compose down
echo "✅ 服务已停止"
