# 分镜工具 - Docker部署指南

本文档提供了使用Docker和Docker Compose部署分镜工具的详细步骤。

## 环境要求
- Docker 20.10+ 
- Docker Compose 1.29+

## 部署步骤

### 1. 克隆项目代码
```bash
# 假设您已经有项目代码，如有需要请先克隆
# git clone <项目仓库地址>
cd /Users/zouyike/分镜工具开发_v1.0.2
```

### 2. 配置环境变量
复制环境变量示例文件并根据实际环境修改：
```bash
# 如果.env文件不存在，请创建它
cp .env.example .env

# 编辑.env文件，修改以下配置
# - DB_PASSWORD: MySQL root用户密码
# - DB_USER_PASSWORD: 应用数据库用户密码
# - JWT_SECRET: JWT密钥，生产环境必须修改为强密钥
# - CORS_ORIGIN: 前端域名，生产环境需设置为实际域名
nano .env
```

### 3. 构建并启动容器
```bash
docker-compose up -d --build
```

这个命令会：
- 构建前端和后端镜像
- 创建并启动三个容器：MySQL数据库、后端服务、前端服务
- 设置自动重启策略
- 配置健康检查确保服务正常运行

### 4. 访问应用
应用启动后，可以通过以下地址访问：
- 前端应用：http://localhost
- 后端API：http://localhost:3002/api

## 服务说明

### 容器服务
- **db**: MySQL 8.0 数据库服务
- **backend**: Node.js 后端服务（端口3002）
- **frontend**: Nginx 前端服务（端口80）

### 持久化数据
以下数据会被持久化保存：
- MySQL数据库数据：`mysql_data`卷
- MySQL配置：`mysql_config`卷
- 上传文件：`backend_uploads`卷

## 常用命令

### 查看容器状态
```bash
docker-compose ps
```

### 查看服务日志
```bash
# 查看所有服务日志
docker-compose logs

# 查看特定服务日志
docker-compose logs backend
```

### 停止服务
```bash
docker-compose down
```

### 停止并删除卷（谨慎使用，会丢失所有数据）
```bash
docker-compose down -v
```

## 生产环境注意事项

1. **修改默认密码**：务必修改.env中的所有默认密码，特别是DB_PASSWORD、DB_USER_PASSWORD和JWT_SECRET

2. **配置域名**：在生产环境中，设置CORS_ORIGIN为您的实际前端域名

3. **HTTPS配置**：生产环境应配置HTTPS，您可以：
   - 在Nginx配置中添加SSL证书
   - 使用反向代理（如Traefik、Nginx）处理HTTPS

4. **数据库备份**：定期备份MySQL数据库

5. **调整资源限制**：根据实际使用情况在docker-compose.yml中调整服务的资源限制

## 故障排除

### 数据库连接问题
如果后端无法连接到数据库，请检查：
- .env文件中的数据库密码是否正确
- 确认MySQL容器是否正常运行

### 前端无法访问后端API
如果前端无法访问后端API，请检查：
- Nginx配置中的代理设置
- 后端服务是否健康运行
- CORS_ORIGIN配置是否正确

### 端口冲突
如果端口80、3002或3306已被占用，请修改docker-compose.yml中的端口映射：
```yaml
# 例如修改前端端口
ports:
  - "8080:80"
```

## 组件说明

### 后端服务
- 基于Node.js + Express
- 提供RESTful API
- 使用MySQL存储数据
- 支持文件上传功能

### 前端服务
- 基于Vue 3 + Element Plus
- 使用Vite构建工具
- Nginx作为静态资源服务器和反向代理

### 数据库服务
- MySQL 8.0
- 自动创建storyboard数据库和storyboard_user用户