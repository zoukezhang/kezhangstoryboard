import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import api from '@/utils/api'

export const useUserStore = defineStore('user', () => {
  const user = ref(null)
  const token = ref(localStorage.getItem('token') || '')

  const isLoggedIn = computed(() => !!token.value)

  // 登录
  const login = async (credentials) => {
    try {
      console.log('开始登录请求:', credentials.email)
      const response = await api.post('/user/login', credentials)
      console.log('登录响应:', response.data)
      
      const { data } = response.data
      
      token.value = data.token
      user.value = data.user
      localStorage.setItem('token', data.token)
      
      return { success: true }
    } catch (error) {
      console.error('登录失败:', error)
      
      let errorMessage = '登录失败'
      
      if (error.response) {
        // 服务器响应了错误状态码
        const status = error.response.status
        const serverMessage = error.response.data?.message
        
        console.log('服务器错误:', { status, message: serverMessage, data: error.response.data })
        
        if (status === 401) {
          errorMessage = serverMessage || '邮箱或密码错误'
        } else if (status === 400) {
          errorMessage = serverMessage || '请求参数错误'
        } else if (status >= 500) {
          errorMessage = '服务器错误，请稍后重试'
        } else {
          errorMessage = serverMessage || `登录失败 (${status})`
        }
      } else if (error.request) {
        // 请求已发出但没有收到响应
        console.log('网络错误:', error.request)
        errorMessage = '网络连接失败，请检查网络连接'
      } else {
        // 设置请求时发生了一些事情，触发了一个错误
        console.log('请求错误:', error.message)
        errorMessage = error.message || '登录请求失败'
      }
      
      return { 
        success: false, 
        message: errorMessage
      }
    }
  }

  // 注册
  const register = async (userInfo) => {
    try {
      const response = await api.post('/user/register', userInfo)
      return { success: true, message: '注册成功' }
    } catch (error) {
      return { 
        success: false, 
        message: error.response?.data?.message || '注册失败' 
      }
    }
  }

  // 获取当前用户信息
  const getCurrentUser = async () => {
    try {
      const response = await api.get('/user/current')
      user.value = response.data.data
      return user.value
    } catch (error) {
      console.error('获取用户信息失败:', error)
      logout()
      return null
    }
  }

  // 修改密码
  const changePassword = async (passwordData) => {
    try {
      const response = await api.put('/user/password', passwordData)
      return { 
        success: true, 
        message: response.data.message || '密码修改成功' 
      }
    } catch (error) {
      return { 
        success: false, 
        message: error.response?.data?.message || '密码修改失败' 
      }
    }
  }

  // 退出登录
  const logout = () => {
    user.value = null
    token.value = ''
    localStorage.removeItem('token')
  }

  return {
    user,
    token,
    isLoggedIn,
    login,
    register,
    getCurrentUser,
    changePassword,
    logout
  }
})