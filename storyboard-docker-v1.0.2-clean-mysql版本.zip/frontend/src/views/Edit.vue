<template>
  <div class="edit-container">
    <!-- 顶部工具栏 -->
    <div class="toolbar">
      <div class="toolbar-left">
        <el-button :icon="ArrowLeft" @click="goBack">返回</el-button>
        <span class="project-title">{{ projectStore.currentProject?.name || '加载中...' }}</span>
      </div>
      <div class="toolbar-right">
        <el-button :icon="Setting" @click="showFieldConfig">字段配置</el-button>
        <el-button :icon="View" @click="preview">预览</el-button>
        <el-button :icon="Download" @click="exportPDF">导出PDF</el-button>
        <el-button :icon="Share" @click="shareProject">分享</el-button>
        <span class="save-status" :class="{ saving: isSaving }">
          {{ saveStatus }}
        </span>
      </div>
    </div>

    <!-- 视图切换工具栏 -->
    <div class="view-toolbar">
      <div class="view-toggle">
        <el-radio-group v-model="viewMode" @change="handleViewModeChange">
          <el-radio-button label="card">卡片视图</el-radio-button>
          <el-radio-button label="list">列表视图</el-radio-button>
          <el-radio-button label="slide">幻灯片视图</el-radio-button>
        </el-radio-group>
        <span class="view-mode-tip">
          <el-icon size="14" color="#909399"><InfoFilled /></el-icon>
          视图模式会自动保存
        </span>
      </div>
    </div>

    <div class="edit-content">
      <!-- 卡片视图模式 -->
      <template v-if="viewMode === 'card'">
        <!-- 左侧分镜列表 -->
        <div class="shots-sidebar">
        <div class="sidebar-header">
          <h3>分镜列表</h3>
        </div>
        <div class="shots-list" v-loading="shotStore.loading">
          <draggable 
            v-model="shotStore.shots" 
            @end="handleSortEnd"
            item-key="id"
            class="draggable-list"
          >
            <template #item="{ element, index }">
              <div 
                class="shot-item"
                :class="{ active: currentShotId === element.id }"
                @click="selectShot(element)"
              >
                <div class="shot-number">{{ index + 1 }}</div>
                <div class="shot-preview">
                  <img 
                    v-if="element.image_url" 
                    :src="getImageUrl(element.image_url)" 
                    alt="镜头预览"
                    class="preview-image"
                  />
                  <el-icon v-else size="40" color="#ccc"><picture /></el-icon>
                </div>
                <div class="shot-info">
                  <div class="shot-tag">{{ element.tag || '未命名' }}</div>
                  <div class="shot-desc">{{ element.description || '暂无描述' }}</div>
                </div>
                <el-button 
                  type="danger" 
                  size="small"
                  :icon="Delete"
                  @click.stop="deleteShot(element)"
                  class="delete-btn"
                />
              </div>
            </template>
          </draggable>
        </div>
      </div>

      <!-- 右侧编辑区 -->
      <div class="edit-area">
        <div v-if="currentShot" class="shot-editor">
          <div class="editor-header">
            <h3>编辑镜头 {{ currentShotIndex + 1 }}</h3>
          </div>
          
          <el-form :model="currentShot" label-width="80px" class="shot-form">
            <el-form-item label="镜号">
              <el-input :value="currentShotIndex + 1" disabled />
            </el-form-item>
            
            <el-form-item label="标签">
              <el-input 
                v-model="currentShot.tag" 
                placeholder="输入镜头标签"
                @input="debouncedSave"
              />
            </el-form-item>
            
            <el-form-item label="描述">
              <el-input 
                v-model="currentShot.description"
                type="textarea"
                :rows="4"
                placeholder="输入镜头描述"
                @input="debouncedSave"
              />
            </el-form-item>
            
            <!-- 动态字段 -->
            <el-form-item v-if="projectStore.currentFieldConfig.duration" label="时长">
              <el-input 
                v-model="currentShot.duration"
                placeholder="例：3秒"
                @input="debouncedSave"
              />
            </el-form-item>
            
            <el-form-item v-if="projectStore.currentFieldConfig.shot_type" label="镜头">
              <el-input 
                v-model="currentShot.shot_type"
                placeholder="例：远景、特写、中景"
                @input="debouncedSave"
              />
            </el-form-item>
            
            <el-form-item v-if="projectStore.currentFieldConfig.dialogue" label="台词">
              <el-input 
                v-model="currentShot.dialogue"
                type="textarea"
                :rows="3"
                placeholder="输入角色对话"
                @input="debouncedSave"
              />
            </el-form-item>
            
            <el-form-item v-if="projectStore.currentFieldConfig.sound_effect" label="音效">
              <el-input 
                v-model="currentShot.sound_effect"
                placeholder="例：背景音乐、环境声"
                @input="debouncedSave"
              />
            </el-form-item>
            
            <el-form-item v-if="projectStore.currentFieldConfig.animation" label="动效">
              <el-input 
                v-model="currentShot.animation"
                placeholder="例：淡入、缩放、平移"
                @input="debouncedSave"
              />
            </el-form-item>
            
            <el-form-item v-if="projectStore.currentFieldConfig.camera_movement" label="运镜">
              <el-input 
                v-model="currentShot.camera_movement"
                placeholder="例：推拉、摇移、跟焦"
                @input="debouncedSave"
              />
            </el-form-item>
            
            <el-form-item v-if="projectStore.currentFieldConfig.scene" label="场景">
              <el-input 
                v-model="currentShot.scene"
                placeholder="例：室内、户外、办公室"
                @input="debouncedSave"
              />
            </el-form-item>
            
            <el-form-item v-if="projectStore.currentFieldConfig.character" label="角色">
              <el-input 
                v-model="currentShot.character"
                placeholder="例：主角、配角A、群众"
                @input="debouncedSave"
              />
            </el-form-item>
            
            <el-form-item v-if="projectStore.currentFieldConfig.character_state" label="人物状态">
              <el-input 
                v-model="currentShot.character_state"
                placeholder="例：站立、坐下、走动"
                @input="debouncedSave"
              />
            </el-form-item>
            
            <el-form-item v-if="projectStore.currentFieldConfig.narration" label="旁白">
              <el-input 
                v-model="currentShot.narration"
                type="textarea"
                :rows="3"
                placeholder="输入旁白内容"
                @input="debouncedSave"
              />
            </el-form-item>
            
            <el-form-item v-if="projectStore.currentFieldConfig.shooting_angle" label="拍摄角度">
              <el-input 
                v-model="currentShot.shooting_angle"
                placeholder="例：仰视、俯视、平视"
                @input="debouncedSave"
              />
            </el-form-item>
            
            <el-form-item label="图片">
              <div class="image-upload">
                <div v-if="currentShot.image_url" class="image-preview">
                  <img :src="getImageUrl(currentShot.image_url)" alt="镜头图片" />
                  <div class="image-actions">
                    <el-button size="small" @click="uploadImage">替换图片</el-button>
                    <el-button size="small" type="danger" @click="deleteImage">删除图片</el-button>
                  </div>
                </div>
                <div v-else class="upload-placeholder" @click="uploadImage">
                  <el-icon size="40" color="#ccc"><plus /></el-icon>
                  <p>点击上传图片</p>
                </div>
              </div>
            </el-form-item>
          </el-form>
        </div>
        
        <div v-else class="no-selection">
          <el-icon size="60" color="#ccc"><edit /></el-icon>
          <p>请选择一个镜头进行编辑</p>
        </div>
      </div>
      </template>

      <!-- 列表视图模式 -->
      <template v-else-if="viewMode === 'list'">
        <div class="list-view-container">
          <ShotListView 
            :shots="shotStore.shots"
            :fieldConfig="projectStore.currentFieldConfig"
            @updateShot="handleShotUpdate"
            @deleteShot="deleteShot"
            @uploadImage="handleImageUpload"
            @sortShots="handleListSortEnd"
          />
        </div>
      </template>
      
      <!-- 幻灯片视图模式 -->
      <template v-else-if="viewMode === 'slide'">
        <div class="slide-view-container">
          <ShotSlideView 
            :shots="shotStore.shots"
            :fieldConfig="projectStore.currentFieldConfig"
          />
        </div>
      </template>
    </div>

    <!-- 底部操作区 -->
    <div v-if="viewMode !== 'slide'" class="bottom-actions">
      <el-button type="primary" :icon="Plus" @click="addShot">添加镜头</el-button>
      <el-button @click="addMultipleShots(5)">+5镜头</el-button>
      <el-button @click="addMultipleShots(10)">+10镜头</el-button>
      <el-divider direction="vertical" />
      <el-button type="success" :icon="Upload" @click="batchUploadImages">批量上传图片</el-button>
    </div>

    <!-- 文件上传组件 -->
    <input 
      ref="fileInput" 
      type="file" 
      accept="image/*" 
      style="display: none"
      @change="handleFileChange"
    />
    
    <!-- 批量上传文件组件 -->
    <input 
      ref="batchFileInput" 
      type="file" 
      accept="image/*" 
      multiple
      style="display: none"
      @change="handleBatchFileChange"
    />
    
    <!-- 字段配置对话框 -->
    <FieldConfigDialog
      v-model="showFieldConfigDialog"
      :project-id="projectId"
      :initial-config="projectStore.currentFieldConfig"
      @updated="handleFieldConfigUpdated"
    />
  </div>
</template>

<script setup>
import { ref, reactive, computed, onMounted, onUnmounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'
import { 
  ArrowLeft, View, Download, Share, Picture, Plus, Delete, Edit, Setting, Upload, InfoFilled
} from '@element-plus/icons-vue'
import draggable from 'vuedraggable'
import { useProjectStore } from '@/stores/project'
import { useShotStore } from '@/stores/shot'
import FieldConfigDialog from '@/components/FieldConfigDialog.vue'
import ShotListView from '@/components/ShotListView.vue'
import ShotSlideView from '@/components/ShotSlideView.vue'
import api from '@/utils/api'
import { debounce, getImageUrl } from '@/utils/common'

const route = useRoute()
const router = useRouter()

const projectStore = useProjectStore()
const shotStore = useShotStore()

const projectId = route.params.projectId
const loading = ref(false)
const isSaving = ref(false)
const saveStatus = ref('已保存')

// 视图模式：card 或 list，从localStorage读取用户上次的选择
const viewMode = ref(localStorage.getItem('shotViewMode') || 'card')

const currentShotId = ref(null)
const fileInput = ref(null)
const batchFileInput = ref(null)
const showFieldConfigDialog = ref(false)

const currentShot = computed(() => {
  return shotStore.shots.find(shot => shot.id === currentShotId.value)
})

const currentShotIndex = computed(() => {
  return shotStore.shots.findIndex(shot => shot.id === currentShotId.value)
})

// 防抖保存
const debouncedSave = debounce(() => {
  saveShot()
}, 500)

// 处理视图模式切换
const handleViewModeChange = (mode) => {
  viewMode.value = mode
  // 保存用户的视图模式选择到localStorage
  localStorage.setItem('shotViewMode', mode)
}

// 处理列表视图中的分镜更新
const handleShotUpdate = async (shotId, data) => {
  const result = await shotStore.updateShot(shotId, data)
  if (!result.success) {
    ElMessage.error(result.message)
  }
}

// 处理列表视图中的图片上传
const handleImageUpload = async (shotId, file) => {
  const result = await shotStore.uploadShotImage(shotId, file)
  if (result.success) {
    ElMessage.success(result.message)
  } else {
    ElMessage.error(result.message)
  }
}

// 处理列表视图中的排序
const handleListSortEnd = async (sortedIds) => {
  const result = await shotStore.updateShotsOrder(sortedIds)
  if (result.success) {
    ElMessage.success(result.message)
  } else {
    ElMessage.error(result.message)
    await fetchShots() // 重新获取列表
  }
}

// 显示字段配置对话框
const showFieldConfig = () => {
  showFieldConfigDialog.value = true
}

// 字段配置更新回调
const handleFieldConfigUpdated = (newConfig) => {
  console.log('接收到的新配置:', newConfig)
  
  // 确保使用深拷贝更新store，避免引用问题
  const configToUpdate = JSON.parse(JSON.stringify(newConfig))
  
  // 逐个属性更新，确保响应式更新
  Object.keys(configToUpdate).forEach(key => {
    projectStore.currentFieldConfig[key] = configToUpdate[key]
  })
  
  console.log('更新后的store配置:', projectStore.currentFieldConfig)
  ElMessage.success('字段配置已更新并应用')
}

// 获取项目信息
const fetchProjectInfo = async () => {
  const result = await projectStore.fetchProject(projectId)
  if (!result.success) {
    ElMessage.error(result.message)
  }
}

// 获取分镜列表
const fetchShots = async () => {
  const result = await shotStore.fetchShots(projectId)
  if (!result.success) {
    ElMessage.error(result.message)
  } else if (shotStore.shots.length > 0 && !currentShotId.value) {
    currentShotId.value = shotStore.shots[0].id
  }
}

// 选择镜头
const selectShot = (shot) => {
  currentShotId.value = shot.id
}

// 添加镜头
const addShot = async () => {
  const result = await shotStore.addShots(projectId, 1)
  if (result.success) {
    ElMessage.success(result.message)
  } else {
    ElMessage.error(result.message)
  }
}

// 批量添加镜头
const addMultipleShots = async (count) => {
  const result = await shotStore.addShots(projectId, count)
  if (result.success) {
    ElMessage.success(result.message)
  } else {
    ElMessage.error(result.message)
  }
}

// 删除镜头
const deleteShot = async (shot) => {
  try {
    await ElMessageBox.confirm(
      `确定要删除镜头${shotStore.shots.indexOf(shot) + 1}吗？`,
      '确认删除',
      {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }
    )
    
    const result = await shotStore.deleteShot(shot.id, projectId)
    if (result.success) {
      ElMessage.success(result.message)
      // 如果删除的是当前选中的镜头，重新选择第一个
      if (currentShotId.value === shot.id && shotStore.shots.length > 0) {
        currentShotId.value = shotStore.shots[0].id
      }
    } else {
      ElMessage.error(result.message)
    }
  } catch (error) {
    if (error !== 'cancel') {
      ElMessage.error('删除镜头失败')
    }
  }
}

// 保存镜头
const saveShot = async () => {
  if (!currentShot.value) return
  
  isSaving.value = true
  saveStatus.value = '保存中...'
  
  // 包含所有字段的数据
  const shotData = {
    tag: currentShot.value.tag || '',
    description: currentShot.value.description || '',
    duration: currentShot.value.duration || '',
    shot_type: currentShot.value.shot_type || '',
    dialogue: currentShot.value.dialogue || '',
    sound_effect: currentShot.value.sound_effect || '',
    animation: currentShot.value.animation || '',
    camera_movement: currentShot.value.camera_movement || '',
    scene: currentShot.value.scene || '',
    character: currentShot.value.character || '',
    character_state: currentShot.value.character_state || '',
    narration: currentShot.value.narration || '',
    shooting_angle: currentShot.value.shooting_angle || ''
  }
  
  const result = await shotStore.updateShot(currentShot.value.id, shotData)
  
  if (result.success) {
    saveStatus.value = '已保存'
  } else {
    saveStatus.value = '保存失败'
    ElMessage.error(result.message)
  }
  
  isSaving.value = false
  setTimeout(() => {
    if (saveStatus.value === '已保存') {
      saveStatus.value = ''
    }
  }, 2000)
}

// 处理拖拽排序
const handleSortEnd = async () => {
  const sortedIds = shotStore.shots.map(shot => shot.id)
  const result = await shotStore.updateShotsOrder(sortedIds)
  if (result.success) {
    ElMessage.success(result.message)
  } else {
    ElMessage.error(result.message)
    await fetchShots() // 重新获取列表
  }
}

// 上传图片
const uploadImage = () => {
  fileInput.value?.click()
}

// 处理文件选择
const handleFileChange = async (event) => {
  const file = event.target.files[0]
  if (!file) return
  
  // 检查文件类型
  if (!file.type.startsWith('image/')) {
    ElMessage.error('请选择图片文件')
    return
  }
  
  // 检查文件大小 (10MB)
  if (file.size > 10 * 1024 * 1024) {
    ElMessage.error('图片大小不能超过10MB')
    return
  }
  
  const result = await shotStore.uploadShotImage(currentShot.value.id, file)
  if (result.success) {
    ElMessage.success(result.message)
    // 更新当前镜头的图片URL
    const shotIndex = shotStore.shots.findIndex(s => s.id === currentShot.value.id)
    if (shotIndex !== -1) {
      shotStore.shots[shotIndex].image_url = result.data.image_url
    }
  } else {
    ElMessage.error(result.message)
  }
  
  // 清空文件输入
  event.target.value = ''
}

// 删除图片
const deleteImage = async () => {
  try {
    await ElMessageBox.confirm('确定要删除这张图片吗？', '确认删除', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning'
    })
    
    // 更新本地状态
    const shotIndex = shotStore.shots.findIndex(s => s.id === currentShot.value.id)
    if (shotIndex !== -1) {
      shotStore.shots[shotIndex].image_url = null
    }
    
    // 保存到服务器
    const result = await shotStore.updateShot(currentShot.value.id, {
      tag: currentShot.value.tag,
      description: currentShot.value.description,
      image_url: null
    })
    
    if (result.success) {
      ElMessage.success('图片删除成功')
    } else {
      ElMessage.error(result.message)
    }
  } catch (error) {
    if (error !== 'cancel') {
      ElMessage.error('删除图片失败')
    }
  }
}

// 批量上传图片
const batchUploadImages = () => {
  batchFileInput.value.click()
}

// 处理批量文件选择
const handleBatchFileChange = async (event) => {
  const files = Array.from(event.target.files)
  if (files.length === 0) return
  
  try {
    ElMessage.info(`开始批量上传 ${files.length} 张图片...`)
    
    // 先批量创建分镜（与图片数量相同）
    const addResult = await shotStore.addShots(projectId, files.length)
    if (!addResult.success) {
      ElMessage.error('批量创建分镜失败')
      return
    }
    
    // 获取最新的分镜列表
    await fetchShots()
    
    // 获取新创建的分镜（最后 files.length 个）
    const newShots = shotStore.shots.slice(-files.length)
    
    // 并发上传所有图片
    const uploadPromises = files.map(async (file, index) => {
      const shot = newShots[index]
      if (!shot) {
        console.error(`无法找到第 ${index + 1} 个分镜`)
        return
      }
      
      try {
        const formData = new FormData()
        formData.append('image', file)
        formData.append('projectId', projectId)
        formData.append('shotId', shot.id)
        
        const response = await api.post('/shot/upload-image', formData, {
          headers: {
            'Content-Type': 'multipart/form-data'
          }
        })
        
        // 更新分镜的图片URL
        shot.image_url = response.data.data.imageUrl
        
        return { success: true, shotIndex: index + 1 }
      } catch (error) {
        console.error(`第 ${index + 1} 张图片上传失败:`, error)
        return { success: false, shotIndex: index + 1, error }
      }
    })
    
    // 等待所有上传完成
    const results = await Promise.all(uploadPromises)
    
    // 统计结果
    const successCount = results.filter(r => r.success).length
    const failCount = results.length - successCount
    
    if (failCount === 0) {
      ElMessage.success(`成功上传 ${successCount} 张图片并创建对应分镜`)
    } else {
      ElMessage.warning(`成功上传 ${successCount} 张图片，${failCount} 张失败`)
    }
    
    // 选中第一个新创建的分镜
    if (newShots.length > 0) {
      currentShotId.value = newShots[0].id
    }
    
  } catch (error) {
    console.error('批量上传失败:', error)
    ElMessage.error('批量上传失败，请重试')
  } finally {
    // 清空文件输入
    event.target.value = ''
  }
}

// 返回项目列表
const goBack = () => {
  router.push('/projects')
}

// 预览
const preview = () => {
  router.push(`/preview/${projectId}`)
}

// 导出PDF
const exportPDF = async () => {
  try {
    const response = await api.get(`/export/project/${projectId}?format=pdf`, {
      responseType: 'blob'
    })
    
    const url = window.URL.createObjectURL(new Blob([response.data]))
    const link = document.createElement('a')
    link.href = url
    link.download = `${projectStore.currentProject?.name || '分镜故事板'}.pdf`
    link.click()
    window.URL.revokeObjectURL(url)
    
    ElMessage.success('导出成功')
  } catch (error) {
    console.error('导出失败:', error)
    ElMessage.error('导出失败')
  }
}

// 分享项目
const shareProject = async () => {
  try {
    console.log('开始创建分享链接...')
    const response = await api.post(`/share/create/${projectId}`)
    console.log('分享响应:', response.data)
    
    if (response.data && response.data.data && response.data.data.token) {
      const shareUrl = `${window.location.origin}/share/${response.data.data.token}`
      console.log('分享链接生成成功:', shareUrl)
      
      // 尝试复制到剪贴板
      try {
        await navigator.clipboard.writeText(shareUrl)
        ElMessage.success(`分享链接已复制到剪贴板\n${shareUrl}`)
      } catch (clipError) {
        console.warn('剪贴板复制失败，使用备用方案:', clipError)
        // 备用方案：使用传统的选中和复制方式
        const textArea = document.createElement('textarea')
        textArea.value = shareUrl
        document.body.appendChild(textArea)
        textArea.select()
        
        try {
          const successful = document.execCommand('copy')
          if (successful) {
            ElMessage.success(`分享链接已复制到剪贴板\n${shareUrl}`)
          } else {
            ElMessage.success(`分享链接生成成功，请手动复制\n${shareUrl}`)
          }
        } catch (execError) {
          console.error('传统复制方式也失败:', execError)
          ElMessage.success(`分享链接生成成功，请手动复制\n${shareUrl}`)
        } finally {
          document.body.removeChild(textArea)
        }
      }
    } else {
      console.error('分享响应数据格式错误:', response.data)
      ElMessage.error('分享链接格式错误')
    }
  } catch (error) {
    console.error('生成分享链接失败:', error)
    
    // 详细的错误处理
    if (error.response) {
      const status = error.response.status
      const message = error.response.data?.message || '服务器错误'
      console.error('错误响应:', { status, data: error.response.data })
      
      if (status === 401) {
        ElMessage.error('登录已过期，请重新登录')
      } else if (status === 403) {
        ElMessage.error('没有权限分享此项目')
      } else {
        ElMessage.error(`生成分享链接失败: ${message}`)
      }
    } else if (error.request) {
      console.error('网络错误:', error.request)
      ElMessage.error('网络连接失败，请检查网络连接')
    } else {
      console.error('未知错误:', error.message)
      ElMessage.error(`生成分享链接失败: ${error.message || '未知错误'}`)
    }
  }
}

onMounted(() => {
  fetchProjectInfo()
  fetchShots()
})
</script>

<style scoped>
.edit-container {
  height: 100vh;
  display: flex;
  flex-direction: column;
}

.view-toolbar {
  padding: 10px 20px;
  background: white;
  border-bottom: 1px solid #e4e7ed;
  display: flex;
  align-items: center;
  gap: 15px;
  flex-wrap: wrap;
}

.view-toggle {
  display: flex;
  align-items: center;
  gap: 12px;
  flex-wrap: wrap;
}

.view-mode-tip {
  display: flex;
  align-items: center;
  gap: 4px;
  font-size: 12px;
  color: #909399;
}

/* 视图切换工具栏手机端适配 */
@media (max-width: 768px) {
  .view-toolbar {
    padding: 8px 12px;
    justify-content: center;
    gap: 8px;
  }
  
  .view-toggle {
    gap: 8px;
    flex-direction: column;
    align-items: center;
  }
  
  .view-mode-tip {
    font-size: 11px;
    text-align: center;
  }
}

@media (max-width: 480px) {
  .view-toolbar {
    padding: 6px 8px;
  }
  
  .view-mode-tip {
    font-size: 10px;
  }
}

.list-view-container {
  flex: 1;
  padding: 20px;
  overflow: auto;
  background: #f5f5f5;
}

.slide-view-container {
  flex: 1;
  height: calc(100vh - 120px);
  background: #f5f5f5;
}

.toolbar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 10px 20px;
  background: white;
  border-bottom: 1px solid #e4e7ed;
  flex-wrap: wrap;
  min-height: 60px;
}

.toolbar-left {
  display: flex;
  align-items: center;
  gap: 15px;
  flex: 1;
  min-width: 0;
}

.project-title {
  font-size: 18px;
  font-weight: 600;
  color: #333;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  flex: 1;
  min-width: 0;
}

.toolbar-right {
  display: flex;
  align-items: center;
  gap: 10px;
  flex-shrink: 0;
  flex-wrap: wrap;
}

/* 手机端适配 */
@media (max-width: 768px) {
  .toolbar {
    padding: 8px 12px;
    flex-direction: column;
    gap: 8px;
    align-items: stretch;
  }
  
  .toolbar-left {
    justify-content: flex-start;
    gap: 10px;
  }
  
  .project-title {
    font-size: 16px;
    max-width: 200px;
  }
  
  .toolbar-right {
    justify-content: center;
    gap: 6px;
  }
  
  .toolbar-right .el-button {
    padding: 8px 12px;
    font-size: 12px;
  }
  
  .save-status {
    font-size: 12px;
    text-align: center;
    width: 100%;
  }
}

/* 更小屏幕适配 */
@media (max-width: 480px) {
  .toolbar {
    padding: 6px 8px;
  }
  
  .toolbar-left {
    gap: 8px;
  }
  
  .project-title {
    font-size: 14px;
    max-width: 150px;
  }
  
  .toolbar-right {
    gap: 4px;
  }
  
  .toolbar-right .el-button {
    padding: 6px 8px;
    font-size: 11px;
  }
  
  .toolbar-right .el-button span {
    display: none;
  }
}

.save-status {
  color: #67c23a;
  font-size: 14px;
}

.save-status.saving {
  color: #409eff;
}

.edit-content {
  flex: 1;
  display: flex;
  overflow: hidden;
}

.shots-sidebar {
  width: 300px;
  background: white;
  border-right: 1px solid #e4e7ed;
  display: flex;
  flex-direction: column;
}

/* 编辑区域手机端适配 */
@media (max-width: 768px) {
  .edit-content {
    flex-direction: column;
  }
  
  .shots-sidebar {
    width: 100%;
    max-height: 40vh;
    border-right: none;
    border-bottom: 1px solid #e4e7ed;
  }
  
  .edit-area {
    padding: 15px;
  }
  
  .list-view-container {
    padding: 10px;
  }
}

@media (max-width: 480px) {
  .shots-sidebar {
    max-height: 35vh;
  }
  
  .edit-area {
    padding: 10px;
  }
  
  .list-view-container {
    padding: 5px;
  }
}

.sidebar-header {
  padding: 15px 20px;
  border-bottom: 1px solid #e4e7ed;
}

.sidebar-header h3 {
  margin: 0;
  color: #333;
}

.shots-list {
  flex: 1;
  overflow-y: auto;
  padding: 10px;
}

.draggable-list {
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.shot-item {
  display: flex;
  align-items: center;
  padding: 10px;
  border: 1px solid #e4e7ed;
  border-radius: 6px;
  cursor: pointer;
  transition: all 0.3s ease;
  position: relative;
}

.shot-item:hover {
  border-color: #409eff;
}

.shot-item.active {
  border-color: #409eff;
  background: #f0f9ff;
}

.shot-number {
  width: 30px;
  height: 30px;
  background: #409eff;
  color: white;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: 600;
  margin-right: 10px;
}

.shot-preview {
  width: 60px;
  height: 45px;
  border: 1px solid #e4e7ed;
  border-radius: 4px;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-right: 10px;
  overflow: hidden;
}

.preview-image {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.shot-info {
  flex: 1;
  min-width: 0;
}

.shot-tag {
  font-weight: 600;
  color: #333;
  margin-bottom: 4px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.shot-desc {
  color: #666;
  font-size: 12px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.delete-btn {
  position: absolute;
  top: 5px;
  right: 5px;
  padding: 4px;
}

.edit-area {
  flex: 1;
  padding: 20px;
  overflow-y: auto;
}

.shot-editor {
  max-width: 600px;
}

.editor-header {
  margin-bottom: 20px;
}

.editor-header h3 {
  margin: 0;
  color: #333;
}

.shot-form {
  background: white;
  padding: 20px;
  border-radius: 8px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

.image-upload {
  width: 100%;
}

.image-preview {
  position: relative;
}

.image-preview img {
  width: 100%;
  max-width: 400px;
  border-radius: 8px;
}

.image-actions {
  margin-top: 10px;
  display: flex;
  gap: 10px;
}

.upload-placeholder {
  width: 200px;
  height: 150px;
  border: 2px dashed #e4e7ed;
  border-radius: 8px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition: border-color 0.3s ease;
}

.upload-placeholder:hover {
  border-color: #409eff;
}

.upload-placeholder p {
  margin: 10px 0 0 0;
  color: #999;
}

.no-selection {
  text-align: center;
  padding: 60px 20px;
  color: #999;
}

.no-selection p {
  margin-top: 20px;
  font-size: 16px;
}

.bottom-actions {
  padding: 15px 20px;
  background: white;
  border-top: 1px solid #e4e7ed;
  display: flex;
  gap: 10px;
  flex-wrap: wrap;
  justify-content: center;
}

/* 底部操作区手机端适配 */
@media (max-width: 768px) {
  .bottom-actions {
    padding: 12px 15px;
    gap: 8px;
  }
  
  .bottom-actions .el-button {
    flex: 1;
    min-width: 80px;
    font-size: 12px;
    padding: 8px 12px;
  }
}

@media (max-width: 480px) {
  .bottom-actions {
    padding: 10px;
    gap: 6px;
  }
  
  .bottom-actions .el-button {
    flex: 1;
    min-width: 70px;
    font-size: 11px;
    padding: 6px 8px;
  }
}
</style>