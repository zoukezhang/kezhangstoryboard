<template>
  <div class="editable-cell" @click="startEdit" :class="{ editing: isEditing }">
    <!-- 显示模式 -->
    <div v-if="!isEditing" class="display-mode">
      <span v-if="displayValue" class="cell-value">{{ displayValue }}</span>
      <span v-else class="cell-placeholder">{{ fieldDisplayName }}</span>
    </div>
    
    <!-- 编辑模式 -->
    <div v-else class="edit-mode">
      <!-- 单行输入 -->
      <el-input
        v-if="type === 'input'"
        ref="inputRef"
        v-model="editValue"
        size="small"
        @blur="finishEdit"
        @keyup.enter="finishEdit"
        @keyup.esc="cancelEdit"
      />
      
      <!-- 多行文本 -->
      <el-input
        v-else-if="type === 'textarea'"
        ref="textareaRef"
        v-model="editValue"
        type="textarea"
        :rows="2"
        size="small"
        @blur="finishEdit"
        @keyup.esc="cancelEdit"
      />
    </div>
  </div>
</template>

<script setup>
import { ref, computed, nextTick } from 'vue'
import { debounce } from '@/utils/common'

const props = defineProps({
  value: {
    type: String,
    default: ''
  },
  shotId: {
    type: [Number, String],
    required: true
  },
  field: {
    type: String,
    required: true
  },
  type: {
    type: String,
    default: 'input' // input 或 textarea
  },
  placeholder: {
    type: String,
    default: '点击编辑'
  }
})

const emit = defineEmits(['update', 'startEdit', 'endEdit'])

const isEditing = ref(false)
const editValue = ref('')
const originalValue = ref('')
const inputRef = ref(null)
const textareaRef = ref(null)

// 显示值
const displayValue = computed(() => {
  return props.value || ''
})

// 字段名称映射
const fieldNameMap = {
  'tag': '标签',
  'description': '描述',
  'duration': '时长',
  'shot_type': '镜头',
  'dialogue': '台词',
  'sound_effect': '音效',
  'animation': '动效',
  'camera_movement': '运镜',
  'scene': '场景',
  'character': '角色',
  'character_state': '人物状态',
  'narration': '旁白',
  'shooting_angle': '拍摄角度'
}

// 字段显示名称
const fieldDisplayName = computed(() => {
  return fieldNameMap[props.field] || props.field
})

// 开始编辑
const startEdit = async () => {
  if (isEditing.value) return
  
  isEditing.value = true
  editValue.value = props.value || ''
  originalValue.value = props.value || ''
  
  emit('startEdit', props.shotId, props.field)
  
  // 等待DOM更新后聚焦输入框
  await nextTick()
  const ref = props.type === 'textarea' ? textareaRef.value : inputRef.value
  if (ref) {
    ref.focus()
    // 选中所有文本
    if (ref.$refs?.input) {
      ref.$refs.input.select()
    } else if (ref.$refs?.textarea) {
      ref.$refs.textarea.select()
    }
  }
}

// 完成编辑
const finishEdit = () => {
  if (!isEditing.value) return
  
  // 只有当值发生变化时才触发更新
  if (editValue.value !== originalValue.value) {
    emit('update', props.shotId, props.field, editValue.value)
  }
  
  isEditing.value = false
  emit('endEdit', props.shotId, props.field)
}

// 取消编辑
const cancelEdit = () => {
  if (!isEditing.value) return
  
  editValue.value = originalValue.value
  isEditing.value = false
  emit('endEdit', props.shotId, props.field)
}
</script>

<style scoped>
.editable-cell {
  width: 100%;
  height: 130px; /* 与行高一致 */
  cursor: pointer;
  transition: all 0.2s ease;
  display: flex;
  align-items: center; /* 垂直居中 */
  box-sizing: border-box;
}

.editable-cell:hover:not(.editing) {
  background: #f0f9ff;
  border-radius: 4px;
}

.display-mode {
  padding: 16px 12px; /* 重新添加内边距 */
  min-height: 40px;
  word-wrap: break-word;
  word-break: break-all;
  overflow: hidden;
  text-overflow: ellipsis;
  max-height: 100px;
  width: 100%;
}

.cell-value {
  color: #303133;
  line-height: 1.4;
}

.cell-placeholder {
  color: #c0c4cc;
}

.edit-mode {
  width: 100%;
}

.editing {
  cursor: default;
}

/* Element Plus 输入框样式调整 */
.edit-mode :deep(.el-input) {
  --el-input-border-color: #409eff;
}

.edit-mode :deep(.el-input__wrapper) {
  box-shadow: 0 0 0 1px #409eff inset;
}

.edit-mode :deep(.el-textarea__inner) {
  border-color: #409eff;
  box-shadow: 0 0 0 1px #409eff inset;
  resize: none;
}
</style>