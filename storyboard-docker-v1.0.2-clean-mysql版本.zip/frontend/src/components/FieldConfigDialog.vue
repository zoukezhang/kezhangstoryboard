<template>
  <el-dialog
    v-model="visible"
    title="项目字段配置"
    width="500px"
    @close="handleClose"
  >
    <div class="field-config-content">
      <p class="config-description">
        选择您需要在分镜中显示的字段，这些设置将应用于整个项目的所有分镜。
      </p>
      
      <el-form :model="fieldConfig" label-width="80px">
        <el-form-item label="时长">
          <el-switch 
            v-model="fieldConfig.duration" 
            :loading="loading"
          />
          <span class="field-desc">用于记录镜头的时长信息</span>
        </el-form-item>
        
        <el-form-item label="镜头">
          <el-switch 
            v-model="fieldConfig.shot_type" 
            :loading="loading"
          />
          <span class="field-desc">用于记录镜头类型信息</span>
        </el-form-item>
        
        <el-form-item label="台词">
          <el-switch 
            v-model="fieldConfig.dialogue" 
            :loading="loading"
          />
          <span class="field-desc">用于记录角色对话内容</span>
        </el-form-item>
        
        <el-form-item label="音效">
          <el-switch 
            v-model="fieldConfig.sound_effect" 
            :loading="loading"
          />
          <span class="field-desc">用于记录音效信息</span>
        </el-form-item>
        
        <el-form-item label="动效">
          <el-switch 
            v-model="fieldConfig.animation" 
            :loading="loading"
          />
          <span class="field-desc">用于记录动画效果信息</span>
        </el-form-item>
        
        <el-form-item label="运镜">
          <el-switch 
            v-model="fieldConfig.camera_movement" 
            :loading="loading"
          />
          <span class="field-desc">用于记录镜头运动方式</span>
        </el-form-item>
        
        <el-form-item label="场景">
          <el-switch 
            v-model="fieldConfig.scene" 
            :loading="loading"
          />
          <span class="field-desc">用于记录场景信息</span>
        </el-form-item>
        
        <el-form-item label="角色">
          <el-switch 
            v-model="fieldConfig.character" 
            :loading="loading"
          />
          <span class="field-desc">用于记录角色信息</span>
        </el-form-item>
        
        <el-form-item label="人物状态">
          <el-switch 
            v-model="fieldConfig.character_state" 
            :loading="loading"
          />
          <span class="field-desc">用于记录人物状态信息</span>
        </el-form-item>
        
        <el-form-item label="旁白">
          <el-switch 
            v-model="fieldConfig.narration" 
            :loading="loading"
          />
          <span class="field-desc">用于记录旁白内容</span>
        </el-form-item>
        
        <el-form-item label="拍摄角度">
          <el-switch 
            v-model="fieldConfig.shooting_angle" 
            :loading="loading"
          />
          <span class="field-desc">用于记录拍摄角度信息</span>
        </el-form-item>
      </el-form>
    </div>
    
    <template #footer>
      <span class="dialog-footer">
        <el-button @click="handleClose">取消</el-button>
        <el-button 
          type="primary" 
          :loading="loading"
          @click="handleSave"
        >
          保存配置
        </el-button>
      </span>
    </template>
  </el-dialog>
</template>

<script setup>
import { ref, reactive, watch } from 'vue'
import { ElMessage } from 'element-plus'
import { useProjectStore } from '@/stores/project'

const props = defineProps({
  modelValue: {
    type: Boolean,
    default: false
  },
  projectId: {
    type: [String, Number],
    required: true
  },
  initialConfig: {
    type: Object,
    default: () => ({
      duration: false,
      shot_type: false,
      dialogue: false,
      sound_effect: false,
      animation: false,
      camera_movement: false,
      scene: false,
      character: false,
      character_state: false,
      narration: false,
      shooting_angle: false
    })
  }
})

const emit = defineEmits(['update:modelValue', 'updated'])

const projectStore = useProjectStore()
const visible = ref(false)
const loading = ref(false)

const fieldConfig = reactive({
  duration: false,
  shot_type: false,
  dialogue: false,
  sound_effect: false,
  animation: false,
  camera_movement: false,
  scene: false,
  character: false,
  character_state: false,
  narration: false,
  shooting_angle: false
})

// 监听显示状态
watch(() => props.modelValue, (newValue) => {
  visible.value = newValue
  if (newValue) {
    // 初始化配置
    Object.assign(fieldConfig, props.initialConfig)
  }
})

// 监听内部显示状态
watch(visible, (newValue) => {
  emit('update:modelValue', newValue)
})

// 保存配置
const handleSave = async () => {
  loading.value = true
  try {
    // 创建配置对象的深拷贝，确保对象引用发生变化
    const configToSave = JSON.parse(JSON.stringify(fieldConfig))
    console.log('准备保存的配置:', configToSave)
    
    const result = await projectStore.updateFieldConfig(props.projectId, configToSave)
    if (result.success) {
      ElMessage.success(result.message)
      console.log('配置保存成功:', configToSave)
      
      // 使用深拷贝确保传递一个全新的对象引用
      emit('updated', configToSave)
      
      // 先更新store再关闭对话框，确保数据一致性
      handleClose()
    } else {
      ElMessage.error(result.message)
      console.error('配置保存失败:', result.message)
    }
  } catch (error) {
    ElMessage.error('保存配置失败')
    console.error('保存字段配置异常:', error)
  } finally {
    loading.value = false
  }
}

// 关闭对话框
const handleClose = () => {
  visible.value = false
}
</script>

<style scoped>
.field-config-content {
  padding: 10px 0;
}

.config-description {
  margin-bottom: 20px;
  color: #666;
  font-size: 14px;
  line-height: 1.6;
}

.field-desc {
  margin-left: 10px;
  color: #999;
  font-size: 12px;
}

.dialog-footer {
  display: flex;
  justify-content: flex-end;
  gap: 10px;
}
</style>