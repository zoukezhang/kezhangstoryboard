# 快速开始

## 1. 系统要求
- Docker 20.10.0+
- Docker Compose 2.0.0+
- 2GB+ RAM, 5GB+ 存储空间

## 2. 部署步骤

```bash
# 1. 解压部署包
tar -xzf storyboard-docker-v1.0.2-clean.tar.gz
cd storyboard-docker-v1.0.2-clean

# 2. 配置环境变量
cp .env.example .env
nano .env  # 修改JWT_SECRET等配置

# 3. 运行部署脚本
./deploy.sh

# 4. 访问应用
# 前端: http://localhost
# 后端: http://localhost:3002
```

## 3. 常用命令

```bash
# 启动服务
./start.sh

# 停止服务
./stop.sh

# 查看日志
./logs.sh

# 查看服务状态
docker-compose ps
```
