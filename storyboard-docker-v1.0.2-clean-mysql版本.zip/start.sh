#!/bin/bash
echo "🚀 启动分镜故事板..."
docker-compose up -d
echo "✅ 服务已启动"
echo "前端: http://localhost"
echo "后端: http://localhost:3002"
