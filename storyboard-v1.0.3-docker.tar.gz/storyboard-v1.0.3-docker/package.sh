#!/bin/bash

# 分镜故事板应用打包脚本
# Version: 1.0.1

set -e

VERSION="1.0.1"
PACKAGE_NAME="storyboard-docker-v${VERSION}"
BUILD_DIR="./build"
PACKAGE_DIR="${BUILD_DIR}/${PACKAGE_NAME}"

echo "📦 开始打包分镜故事板 Docker 部署包..."

# 清理并创建构建目录
rm -rf "${BUILD_DIR}"
mkdir -p "${PACKAGE_DIR}"

echo "📁 复制必要文件..."

# 复制Docker配置文件
cp docker-compose.yml "${PACKAGE_DIR}/"
cp .env.production "${PACKAGE_DIR}/.env.example"

# 复制部署脚本
cp deploy.sh "${PACKAGE_DIR}/"
chmod +x "${PACKAGE_DIR}/deploy.sh"

# 复制文档
cp README.md "${PACKAGE_DIR}/"
cp DOCKER_DEPLOY.md "${PACKAGE_DIR}/"

# 复制前端代码和配置
echo "📱 复制前端文件..."
mkdir -p "${PACKAGE_DIR}/frontend"
cp -r frontend/src "${PACKAGE_DIR}/frontend/"
cp -r frontend/public "${PACKAGE_DIR}/frontend/"
cp frontend/package*.json "${PACKAGE_DIR}/frontend/"
cp frontend/vite.config.js "${PACKAGE_DIR}/frontend/"
cp frontend/index.html "${PACKAGE_DIR}/frontend/"
cp frontend/Dockerfile "${PACKAGE_DIR}/frontend/"
cp frontend/nginx.conf "${PACKAGE_DIR}/frontend/"
cp frontend/.dockerignore "${PACKAGE_DIR}/frontend/"

# 复制后端代码和配置
echo "🔧 复制后端文件..."
mkdir -p "${PACKAGE_DIR}/backend"
cp -r backend/src "${PACKAGE_DIR}/backend/"
cp -r backend/fonts "${PACKAGE_DIR}/backend/"
cp backend/package*.json "${PACKAGE_DIR}/backend/"
cp backend/Dockerfile "${PACKAGE_DIR}/backend/"
cp backend/.dockerignore "${PACKAGE_DIR}/backend/"
cp backend/.env.example "${PACKAGE_DIR}/backend/" 2>/dev/null || cp backend/.env "${PACKAGE_DIR}/backend/.env.example" 2>/dev/null || echo "# 请配置环境变量" > "${PACKAGE_DIR}/backend/.env.example"

# 创建必要目录
mkdir -p "${PACKAGE_DIR}/backend/uploads"
touch "${PACKAGE_DIR}/backend/uploads/.gitkeep"

# 创建版本信息文件
echo "📋 生成版本信息..."
cat > "${PACKAGE_DIR}/VERSION.txt" << EOF
分镜故事板 Docker 部署包
版本: ${VERSION}
打包时间: $(date)
Git提交: $(git rev-parse --short HEAD 2>/dev/null || echo "N/A")

包含内容:
- 前端应用 (Vue 3 + Vite)
- 后端API (Node.js + Express)
- 中文字体文件 (PDF导出支持)
- Docker配置文件
- 部署脚本和文档

部署说明请查看 DOCKER_DEPLOY.md
EOF

# 创建快速开始文件
cat > "${PACKAGE_DIR}/QUICKSTART.md" << 'EOF'
# 快速开始

## 1. 系统要求
- Docker 20.10.0+
- Docker Compose 2.0.0+
- 2GB+ RAM, 5GB+ 存储空间

## 2. 部署步骤

```bash
# 1. 解压部署包
tar -xzf storyboard-docker-v1.0.1.tar.gz
cd storyboard-docker-v1.0.1

# 2. 配置环境变量（可选）
cp .env.example .env
nano .env  # 修改JWT_SECRET等配置

# 3. 运行部署脚本
./deploy.sh

# 4. 访问应用
# 前端: http://localhost
# 后端: http://localhost:3002
```

## 3. 测试账号
- 邮箱: test@example.com  
- 密码: 123456

详细说明请查看 DOCKER_DEPLOY.md
EOF

# 创建启动脚本
cat > "${PACKAGE_DIR}/start.sh" << 'EOF'
#!/bin/bash
echo "🚀 启动分镜故事板..."
docker-compose up -d
echo "✅ 服务已启动"
echo "前端: http://localhost"
echo "后端: http://localhost:3002"
EOF

chmod +x "${PACKAGE_DIR}/start.sh"

# 创建停止脚本
cat > "${PACKAGE_DIR}/stop.sh" << 'EOF'
#!/bin/bash
echo "🛑 停止分镜故事板..."
docker-compose down
echo "✅ 服务已停止"
EOF

chmod +x "${PACKAGE_DIR}/stop.sh"

# 创建日志查看脚本
cat > "${PACKAGE_DIR}/logs.sh" << 'EOF'
#!/bin/bash
echo "📋 查看服务日志..."
docker-compose logs -f
EOF

chmod +x "${PACKAGE_DIR}/logs.sh"

# 打包
echo "🗜️  创建压缩包..."
cd "${BUILD_DIR}"
tar -czf "${PACKAGE_NAME}.tar.gz" "${PACKAGE_NAME}"

# 生成校验和
echo "🔐 生成校验和..."
sha256sum "${PACKAGE_NAME}.tar.gz" > "${PACKAGE_NAME}.sha256"

echo "✅ 打包完成！"
echo ""
echo "📦 部署包信息:"
echo "   文件名: ${PACKAGE_NAME}.tar.gz"
echo "   位置: ${PWD}/${PACKAGE_NAME}.tar.gz"
echo "   大小: $(ls -lh ${PACKAGE_NAME}.tar.gz | awk '{print $5}')"
echo ""
echo "🚀 部署说明:"
echo "   1. 将 ${PACKAGE_NAME}.tar.gz 上传到目标服务器"
echo "   2. 解压: tar -xzf ${PACKAGE_NAME}.tar.gz"
echo "   3. 进入目录: cd ${PACKAGE_NAME}"
echo "   4. 运行: ./deploy.sh"
echo ""
echo "📝 详细文档: DOCKER_DEPLOY.md"
echo "🎯 快速开始: QUICKSTART.md"