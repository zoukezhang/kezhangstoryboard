# 分镜故事板 v1.0.3 Docker安装说明

## 系统要求
- Docker 20.10+
- Docker Compose 1.29+

## 安装步骤

1. 确保已安装Docker和Docker Compose
   ```bash
   docker --version
   docker-compose --version
   ```

2. 配置环境变量
   ```bash
   # 复制环境变量示例文件
   cp .env.example .env
   
   # 编辑.env文件，修改以下配置
   # - DB_PASSWORD: MySQL root用户密码
   # - DB_USER_PASSWORD: 应用数据库用户密码
   # - JWT_SECRET: JWT密钥，生产环境必须修改为强密钥
   nano .env
   ```

3. 启动服务
   ```bash
   docker-compose up -d --build
   ```

4. 访问应用
   - 前端应用：http://localhost
   - 后端API：http://localhost:3002

## 服务说明
- **db**: MySQL 8.0 数据库服务
- **backend**: Node.js 后端服务（端口3002）
- **frontend**: Nginx 前端服务（端口80）

## 常用命令
```bash
# 查看服务状态
docker-compose ps

# 查看日志
docker-compose logs -f

# 停止服务
docker-compose down
```

## 注意事项
1. 首次启动可能需要几分钟时间初始化数据库
2. 请确保端口80和3002未被占用
3. 生产环境请务必修改.env中的默认密码
