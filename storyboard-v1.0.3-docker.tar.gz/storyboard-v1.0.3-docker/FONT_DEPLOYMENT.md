# 部署指南 - 字体文件配置

## 概述

本项目已将PDF导出所需的中文字体文件集成到项目中，确保在不同环境下都能正确显示中文内容，无需依赖系统字体。

## 字体文件位置

```
backend/fonts/
├── Hiragino Sans GB.ttc    # 苹果中文字体 (首选，但可能有兼容性问题)
├── Arial Unicode.ttf       # Unicode字体 (推荐，兼容性最佳)
├── Arial.ttf              # 基础英文字体 (备选)
└── README.md              # 字体说明文档
```

## 部署步骤

### 1. 开发环境
无需额外配置，字体文件已包含在项目中。

### 2. 生产环境部署

#### 传统部署
确保将 `backend/fonts/` 目录完整复制到生产服务器：

```bash
# 复制项目文件时确保包含字体目录
rsync -av --include='fonts/' backend/ production-server:/app/backend/
```

#### Docker部署
在 Dockerfile 中确保字体目录被正确复制：

```dockerfile
# 在 backend/Dockerfile 中添加
COPY fonts/ /app/fonts/
```

#### Docker Compose
如果使用 Docker Compose，确保字体文件在镜像构建时被包含。

### 3. 验证部署

部署后可以通过以下方式验证字体配置：

1. **检查字体文件存在**：
   ```bash
   ls -la backend/fonts/
   ```

2. **测试PDF导出**：
   导出一个包含中文的PDF，检查中文是否正确显示。

3. **查看服务器日志**：
   ```
   字体目录: /path/to/backend/fonts
   找到字体文件: /path/to/backend/fonts/Arial Unicode.ttf
   中文字体加载成功: /path/to/backend/fonts/Arial Unicode.ttf
   ```

## 字体加载逻辑

系统按以下顺序尝试加载字体：

1. **Hiragino Sans GB.ttc** - 最佳中文显示效果（苹果系统字体）
2. **Arial Unicode.ttf** - 良好的跨平台中文支持 ⭐ **推荐**
3. **Arial.ttf** - 基础英文字体
4. **Helvetica** (PDFKit内置) - 最后备选

## 故障排除

### 问题：字体文件不存在
**现象**：日志显示 "字体文件不存在"

**解决方案**：
1. 检查 `backend/fonts/` 目录是否存在
2. 验证字体文件是否被正确复制
3. 检查文件权限

### 问题：TTC字体兼容性
**现象**：日志显示 "this.font.createSubset is not a function"

**解决方案**：
这是 [Hiragino Sans GB.ttc](file:///Users/zouyike/分镜工具开发/backend/fonts/Hiragino%20Sans%20GB.ttc) 字体的已知问题，系统会自动回退到 [Arial Unicode.ttf](file:///Users/zouyike/分镜工具开发/backend/fonts/Arial%20Unicode.ttf)，无需额外处理。

### 问题：中文显示异常
**现象**：PDF中中文显示为方框或问号

**解决方案**：
1. 确认字体文件完整
2. 检查字体加载日志
3. 验证 PDFKit 版本兼容性

## 许可证注意事项

- 字体文件仅供开发和测试使用
- 商业部署时请确保遵守字体许可证要求
- 建议在生产环境中使用开源字体替代

## 环境特定注意事项

### macOS
- 完全支持所有字体
- [Hiragino Sans GB.ttc](file:///Users/zouyike/分镜工具开发/backend/fonts/Hiragino%20Sans%20GB.ttc) 可能有 PDFKit 兼容性问题

### Linux
- 推荐使用 [Arial Unicode.ttf](file:///Users/zouyike/分镜工具开发/backend/fonts/Arial%20Unicode.ttf)
- 可能需要安装额外的字体支持包

### Windows
- [Arial Unicode.ttf](file:///Users/zouyike/分镜工具开发/backend/fonts/Arial%20Unicode.ttf) 兼容性最佳
- 确保 Node.js 有字体文件读取权限

## 性能优化

字体文件较大（~23MB），建议：

1. **CDN加速**：如果可能，将字体文件放在CDN上
2. **缓存优化**：确保字体文件被适当缓存
3. **按需加载**：仅在需要生成PDF时加载字体

## 监控和日志

建议监控以下指标：
- 字体加载成功率
- PDF生成时间
- 字体文件访问错误

相关日志关键字：
- "中文字体加载成功"
- "字体文件不存在"
- "字体加载失败"