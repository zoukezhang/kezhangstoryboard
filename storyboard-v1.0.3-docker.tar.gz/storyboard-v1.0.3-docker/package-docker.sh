#!/bin/bash
# 分镜故事板应用 - Docker部署精简打包脚本
# 版本: v1.0.2

set -e

# 配置参数
VERSION="1.0.2"
PACKAGE_NAME="storyboard-docker-v${VERSION}-clean"
BUILD_DIR="./build"
PACKAGE_DIR="${BUILD_DIR}/${PACKAGE_NAME}"
WORKSPACE="/Users/zouyike/分镜工具开发_v1.0.2"

# 颜色定义
green="\033[32m"
yellow="\033[33m"
red="\033[31m"
reset="\033[0m"

# 开始信息
echo -e "${green}📦 开始打包分镜故事板 Docker 部署包 (v${VERSION})...${reset}"

echo -e "${yellow}ℹ️  版本: ${VERSION}"
echo -e "ℹ️  包名: ${PACKAGE_NAME}"
echo -e "ℹ️  构建目录: ${BUILD_DIR}${reset}"

# 清理并创建构建目录
rm -rf "${BUILD_DIR}/${PACKAGE_NAME}" "${BUILD_DIR}/${PACKAGE_NAME}.tar.gz" "${BUILD_DIR}/${PACKAGE_NAME}.md5"
mkdir -p "${PACKAGE_DIR}"

# 复制必要文件
echo -e "\n${green}📁 复制核心配置文件...${reset}"
cp -f docker-compose.yml "${PACKAGE_DIR}/"
cp -f .env.example "${PACKAGE_DIR}/"
cp -f README.docker.md "${PACKAGE_DIR}/README.md"
cp -f deploy.sh "${PACKAGE_DIR}/"
cp -f DATABASE_INIT_GUIDE.md "${PACKAGE_DIR}/"
chmod +x "${PACKAGE_DIR}/deploy.sh"

# 复制前端代码
echo -e "\n${green}📱 复制前端文件...${reset}"
mkdir -p "${PACKAGE_DIR}/frontend"
cp -r frontend/src "${PACKAGE_DIR}/frontend/"
cp -r frontend/public "${PACKAGE_DIR}/frontend/"
cp -f frontend/package.json "${PACKAGE_DIR}/frontend/"
cp -f frontend/package-lock.json "${PACKAGE_DIR}/frontend/"
cp -f frontend/vite.config.js "${PACKAGE_DIR}/frontend/"
cp -f frontend/index.html "${PACKAGE_DIR}/frontend/"
cp -f frontend/Dockerfile "${PACKAGE_DIR}/frontend/"
cp -f frontend/nginx.conf "${PACKAGE_DIR}/frontend/"
cp -f frontend/.dockerignore "${PACKAGE_DIR}/frontend/"

# 复制后端代码
echo -e "\n${green}🔧 复制后端文件...${reset}"
mkdir -p "${PACKAGE_DIR}/backend"
cp -r backend/src "${PACKAGE_DIR}/backend/"
cp -r backend/fonts "${PACKAGE_DIR}/backend/"
cp -f backend/package.json "${PACKAGE_DIR}/backend/"
cp -f backend/package-lock.json "${PACKAGE_DIR}/backend/"
cp -f backend/Dockerfile "${PACKAGE_DIR}/backend/"
cp -f backend/.dockerignore "${PACKAGE_DIR}/backend/"
cp -f backend/init-mysql-database.js "${PACKAGE_DIR}/backend/"

# 复制数据库初始化指南
cp -f DATABASE_INIT_GUIDE.md "${PACKAGE_DIR}/"

# 处理.env.example文件
if [ -f "backend/.env.example" ]; then
  cp -f backend/.env.example "${PACKAGE_DIR}/backend/"
elif [ -f "backend/.env" ]; then
  cp -f backend/.env "${PACKAGE_DIR}/backend/.env.example"
else
  echo "# 后端环境变量配置示例" > "${PACKAGE_DIR}/backend/.env.example"
  echo "NODE_ENV=production" >> "${PACKAGE_DIR}/backend/.env.example"
  echo "PORT=3002" >> "${PACKAGE_DIR}/backend/.env.example"
  echo "JWT_SECRET=your_jwt_secret_key_change_this_in_production" >> "${PACKAGE_DIR}/backend/.env.example"
  echo "# 在Docker环境中，DB_HOST会自动设置为'db'" >> "${PACKAGE_DIR}/backend/.env.example"
fi

# 创建必要目录
echo -e "\n${green}🗂️  创建必要目录...${reset}"
mkdir -p "${PACKAGE_DIR}/backend/uploads"
touch "${PACKAGE_DIR}/backend/uploads/.gitkeep"

# 创建版本信息文件
echo -e "\n${green}📋 生成版本信息...${reset}"
cat > "${PACKAGE_DIR}/VERSION.txt" << EOF
分镜故事板 Docker 部署包
版本: ${VERSION}
打包时间: $(date)

包含内容:
- 前端应用 (Vue 3 + Vite)
- 后端API (Node.js + Express)
- 中文字体文件 (PDF导出支持)
- Docker配置文件
- 部署脚本和文档

部署说明请查看 README.md
EOF

# 创建快速开始文件
echo -e "\n${green}🚀 创建快速开始文档...${reset}"
cat > "${PACKAGE_DIR}/QUICKSTART.md" << 'EOF'
# 快速开始

## 1. 系统要求
- Docker 20.10.0+
- Docker Compose 2.0.0+
- 2GB+ RAM, 5GB+ 存储空间

## 2. 部署步骤

```bash
# 1. 解压部署包
tar -xzf storyboard-docker-v1.0.2-clean.tar.gz
cd storyboard-docker-v1.0.2-clean

# 2. 配置环境变量
cp .env.example .env
nano .env  # 修改JWT_SECRET等配置

# 3. 运行部署脚本
./deploy.sh

# 4. 访问应用
# 前端: http://localhost
# 后端: http://localhost:3002
```

## 3. 常用命令

```bash
# 启动服务
./start.sh

# 停止服务
./stop.sh

# 查看日志
./logs.sh

# 查看服务状态
docker-compose ps
```
EOF

# 创建启动脚本
echo -e "\n${green}🔄 创建服务控制脚本...${reset}"
cat > "${PACKAGE_DIR}/start.sh" << 'EOF'
#!/bin/bash
echo "🚀 启动分镜故事板..."
docker-compose up -d
echo "✅ 服务已启动"
echo "前端: http://localhost"
echo "后端: http://localhost:3002"
EOF
chmod +x "${PACKAGE_DIR}/start.sh"

# 创建停止脚本
cat > "${PACKAGE_DIR}/stop.sh" << 'EOF'
#!/bin/bash
echo "🛑 停止分镜故事板..."
docker-compose down
echo "✅ 服务已停止"
EOF
chmod +x "${PACKAGE_DIR}/stop.sh"

# 创建日志查看脚本
cat > "${PACKAGE_DIR}/logs.sh" << 'EOF'
#!/bin/bash
echo "📋 查看服务日志..."
docker-compose logs -f
EOF
chmod +x "${PACKAGE_DIR}/logs.sh"

# 打包成压缩文件
echo -e "\n${green}🗜️  创建压缩包...${reset}"
cd "${BUILD_DIR}"
tar -czf "${PACKAGE_NAME}.tar.gz" "${PACKAGE_NAME}"

# 生成校验和
echo -e "\n${green}🔐 生成MD5校验和...${reset}"
md5sum "${PACKAGE_NAME}.tar.gz" > "${PACKAGE_NAME}.md5"

# 显示完成信息
PACKAGE_SIZE=$(ls -lh "${PACKAGE_NAME}.tar.gz" | awk '{print $5}')
MD5_SUM=$(cat "${PACKAGE_NAME}.md5" | awk '{print $1}')

cd "${WORKSPACE}"
echo -e "\n${green}✅ 打包完成！${reset}"
echo -e "\n${yellow}📦 部署包信息:${reset}"
echo -e "   ${green}文件名:${reset} ${PACKAGE_NAME}.tar.gz"
echo -e "   ${green}位置:${reset} ${BUILD_DIR}/${PACKAGE_NAME}.tar.gz"
echo -e "   ${green}大小:${reset} ${PACKAGE_SIZE}"
echo -e "   ${green}MD5:${reset} ${MD5_SUM}"
echo -e "\n${yellow}🚀 部署说明:${reset}"
echo -e "   1. 将 ${PACKAGE_NAME}.tar.gz 上传到目标服务器"
echo -e "   2. 解压: tar -xzf ${PACKAGE_NAME}.tar.gz"
echo -e "   3. 进入目录: cd ${PACKAGE_NAME}"
echo -e "   4. 配置环境: cp .env.example .env && nano .env"
echo -e "   5. 运行: ./deploy.sh"
echo -e "\n${yellow}📝 详细文档:${reset} README.md"
echo -e "${yellow}🎯 快速开始:${reset} QUICKSTART.md"
echo -e "\n${green}💡 提示:${reset} 部署包已排除node_modules和测试文件，确保轻量高效！"