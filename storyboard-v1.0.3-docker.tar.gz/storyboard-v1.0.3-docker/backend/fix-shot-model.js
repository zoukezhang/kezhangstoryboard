import fs from 'fs';
import path from 'path';

// 修复后的版本，正确处理字符串中的反引号

// 定义MySQLShot.js的新内容
const newFileContent = `import { pool } from '../config/database.js'

export class MySQLShot {
  // 添加分镜（支持批量）
  static async create(projectId, count = 1) {
    // 获取当前最大排序号
    const [maxRows] = await pool.execute(
      'SELECT COALESCE(MAX(sort_order), 0) as max_sort FROM shots WHERE project_id = ?',
      [projectId]
    )
    
    let currentSort = maxRows[0].max_sort
    const insertedIds = []
    
    // 批量插入分镜
    for (let i = 0; i < count; i++) {
      currentSort++
      const [result] = await pool.execute(
        'INSERT INTO shots (project_id, sort_order) VALUES (?, ?)',
        [projectId, currentSort]
      )
      insertedIds.push(result.insertId)
    }
    
    return insertedIds
  }

  // 获取项目的分镜列表
  static async findByProjectId(projectId) {
    // 使用双引号来避免反引号问题
    const sql = "SELECT id, sort_order, tag, description, image_url, duration, shot_type, dialogue, sound_effect, animation, camera_movement, scene, \`character\`, character_state, narration, shooting_angle, create_time, update_time FROM shots WHERE project_id = ? ORDER BY sort_order ASC";
    const [rows] = await pool.execute(sql, [projectId]);
    
    return rows
  }

  // 根据ID查找分镜
  static async findById(id) {
    const [rows] = await pool.execute('SELECT * FROM shots WHERE id = ?', [id])
    return rows[0] || null
  }

  // 更新分镜信息
  static async update(id, data) {
    const {
      tag = '',
      description = '',
      image_url,
      duration = null,
      shot_type = '',
      dialogue = '',
      sound_effect = '',
      animation = '',
      camera_movement = '',
      scene = '',
      character = '',
      character_state = '',
      narration = '',
      shooting_angle = ''
    } = data
    
    // 使用双引号并转义反引号
    let sql = "UPDATE shots SET tag = ?, description = ?, duration = ?, shot_type = ?, dialogue = ?, sound_effect = ?, animation = ?, camera_movement = ?, scene = ?, \`character\` = ?, character_state = ?, narration = ?, shooting_angle = ?, update_time = CURRENT_TIMESTAMP";
    let params = [tag, description, duration, shot_type, dialogue, sound_effect, animation, camera_movement, scene, character, character_state, narration, shooting_angle]
    
    if (image_url !== undefined) {
      sql += ', image_url = ?'
      params.push(image_url)
    }
    
    sql += ' WHERE id = ?'
    params.push(id)
    
    const [result] = await pool.execute(sql, params)
    return result.affectedRows > 0
  }

  // 更新分镜图片
  static async updateImage(id, imageUrl) {
    const [result] = await pool.execute(
      'UPDATE shots SET image_url = ?, update_time = CURRENT_TIMESTAMP WHERE id = ?',
      [imageUrl, id]
    )
    return result.affectedRows > 0
  }

  // 删除分镜
  static async delete(id) {
    const [result] = await pool.execute('DELETE FROM shots WHERE id = ?', [id])
    return result.affectedRows > 0
  }

  // 删除项目的所有分镜
  static async deleteByProjectId(projectId) {
    const [result] = await pool.execute('DELETE FROM shots WHERE project_id = ?', [projectId])
    return result.affectedRows > 0
  }

  // 重新排序分镜
  static async reorder(projectId, shotIds) {
    // 事务处理
    const connection = await pool.getConnection()
    
    try {
      await connection.beginTransaction()
      
      // 批量更新排序号
      for (let i = 0; i < shotIds.length; i++) {
        await connection.execute(
          'UPDATE shots SET sort_order = ?, update_time = CURRENT_TIMESTAMP WHERE id = ? AND project_id = ?',
          [i + 1, shotIds[i], projectId]
        )
      }
      
      await connection.commit()
      return true
    } catch (error) {
      await connection.rollback()
      throw error
    } finally {
      connection.release()
    }
  }
  
  // 根据分镜ID获取项目ID
  static async getProjectId(shotId) {
    try {
      const [rows] = await pool.execute(
        'SELECT project_id FROM shots WHERE id = ?',
        [shotId]
      )
      
      return rows.length > 0 ? rows[0].project_id : null
    } catch (error) {
      console.error('获取分镜所属项目ID失败:', error)
      return null
    }
  }
}`;

// 写入新文件内容
const filePath = path.join(process.cwd(), 'src', 'models', 'MySQLShot.js');

console.log(`正在写入文件: ${filePath}`);
fs.writeFileSync(filePath, newFileContent, 'utf8');
console.log('✅ MySQLShot.js文件已成功更新！');

// 创建一个简单的测试脚本来验证修复
const testScript = `import { pool } from '../config/database.js';
import { MySQLShot } from './MySQLShot.js';
import fs from 'fs';

async function testFix() {
  try {
    console.log('测试修复后的MySQLShot.js...');
    
    // 打印SQL查询语句（通过字符串查找）
    const fileContent = fs.readFileSync('./MySQLShot.js', 'utf8');
    const sqlMatch = fileContent.match(/static async findByProjectId.*?const sql = "(.*?)"/s);
    
    if (sqlMatch && sqlMatch[1]) {
      console.log('\n当前SQL查询语句:');
      console.log(sqlMatch[1]);
      console.log('\n是否包含错误的"characters"字段:', sqlMatch[1].includes('characters'));
      console.log('是否包含正确的"character"字段:', sqlMatch[1].includes('character'));
    }
    
    // 尝试一个实际的查询（假设项目ID为2）
    console.log('\n尝试实际查询（项目ID=2）:');
    try {
      const shots = await MySQLShot.findByProjectId(2);
      console.log('✅ 查询成功！返回了', shots.length, '个分镜');
    } catch (error) {
      console.error('❌ 查询失败:', error);
    }
    
  } catch (error) {
    console.error('测试过程中出错:', error);
  } finally {
    pool.end();
  }
}

testFix();`;

const testFilePath = path.join(process.cwd(), 'src', 'models', 'test-shot-fix.js');
fs.writeFileSync(testFilePath, testScript, 'utf8');
console.log('✅ 测试脚本已创建: src/models/test-shot-fix.js');
console.log('\n请运行以下命令测试修复:');
console.log('cd src/models && node test-shot-fix.js');
console.log('\n然后重启后端服务:');
console.log('npm run dev');