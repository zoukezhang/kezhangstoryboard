import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';

// 设置正确的路径
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

dotenv.config({ path: path.join(__dirname, '.env') });

import { pool } from './src/config/database.js';

/**
 * 为projects表添加缺失的field_config列
 */
const addFieldConfigColumn = async () => {
  try {
    console.log('=== 开始添加field_config列 ===');
    
    // 检查列是否已存在
    const [existingColumns] = await pool.execute(
      "SHOW COLUMNS FROM projects LIKE 'field_config'"
    );
    
    if (existingColumns.length > 0) {
      console.log('✅ field_config列已存在，无需添加');
    } else {
      // 添加新列
      await pool.execute(
        "ALTER TABLE projects ADD COLUMN field_config TEXT"
      );
      console.log('✅ 成功为projects表添加field_config列');
    }
    
  } catch (error) {
    console.error('❌ 添加field_config列失败:', error);
  } finally {
    await pool.end();
    console.log('=== 数据库连接已关闭 ===');
  }
};

addFieldConfigColumn();