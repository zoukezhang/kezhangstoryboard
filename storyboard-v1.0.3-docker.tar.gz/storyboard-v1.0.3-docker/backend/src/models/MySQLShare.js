import { pool } from '../config/database.js'

export class MySQLShare {
  // 创建分享链接
  static async create(projectId, token, expireTime) {
    // 将ISO格式时间转换为MySQL兼容的DATETIME格式
    const mysqlDateTime = new Date(expireTime).toISOString().slice(0, 19).replace('T', ' ')
    
    const [result] = await pool.execute(
      'INSERT INTO shares (project_id, token, expire_time) VALUES (?, ?, ?)',
      [projectId, token, mysqlDateTime]
    )
    return result.insertId
  }

  // 根据token查找分享记录
  static async findByToken(token) {
    const [rows] = await pool.execute(
      `SELECT s.*, p.name as project_name, p.user_id
       FROM shares s
       JOIN projects p ON s.project_id = p.id
       WHERE s.token = ? AND s.expire_time > NOW()`,
      [token]
    )
    return rows[0] || null
  }

  // 检查分享是否有效
  static async isValid(token) {
    const [rows] = await pool.execute(
      `SELECT COUNT(*) as count 
       FROM shares 
       WHERE token = ? AND expire_time > NOW()`,
      [token]
    )
    return rows[0].count > 0
  }

  // 删除过期的分享记录
  static async deleteExpired() {
    const [result] = await pool.execute(
      'DELETE FROM shares WHERE expire_time <= NOW()'
    )
    return result.affectedRows
  }

  // 获取项目的分享记录
  static async findByProjectId(projectId) {
    const [rows] = await pool.execute(
      `SELECT token, expire_time, created_at
       FROM shares 
       WHERE project_id = ? AND expire_time > NOW()
       ORDER BY created_at DESC`,
      [projectId]
    )
    return rows
  }
  
  // 删除项目的所有分享记录
  static async deleteByProjectId(projectId) {
    const [result] = await pool.execute(
      'DELETE FROM shares WHERE project_id = ?',
      [projectId]
    )
    return result.affectedRows
  }
}