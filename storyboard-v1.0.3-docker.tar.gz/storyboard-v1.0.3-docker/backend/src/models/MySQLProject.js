import { pool } from '../config/database.js'
import { MySQLShot } from './MySQLShot.js'

export class MySQLProject {
  // 创建项目
  static async create(userId, name, fieldConfig = null) {
    const defaultConfig = '{"duration":false,"shot_type":false,"dialogue":false,"sound_effect":false,"animation":false,"camera_movement":false,"scene":false,"character":false,"character_state":false,"narration":false,"shooting_angle":false}'
    const config = fieldConfig ? JSON.stringify(fieldConfig) : defaultConfig
    
    const [result] = await pool.execute(
      'INSERT INTO projects (user_id, name, field_config) VALUES (?, ?, ?)',
      [userId, name, config]
    )
    return result.insertId
  }

  // 获取用户的项目列表
  static async findByUserId(userId) {
    const [rows] = await pool.execute(`
      SELECT 
        id, 
        name, 
        shot_count, 
        field_config,
        create_time, 
        last_edit_time
      FROM projects 
      WHERE user_id = ? 
      ORDER BY last_edit_time DESC
    `, [userId])
    
    // 解析字段配置 JSON 并获取缩略图
    const projects = rows.map(project => ({
      ...project,
      field_config: project.field_config ? JSON.parse(project.field_config) : {
        duration: false,
        shot_type: false,
        dialogue: false,
        sound_effect: false,
        animation: false,
        camera_movement: false,
        scene: false,
        character: false,
        character_state: false,
        narration: false,
        shooting_angle: false
      }
    }))
    
    // 为每个项目获取缩略图
    for (const project of projects) {
      project.thumbnail = await MySQLProject.getThumbnail(project.id)
    }
    
    return projects
  }

  // 根据ID查找项目
  static async findById(id) {
    const [rows] = await pool.execute('SELECT * FROM projects WHERE id = ?', [id])
    const project = rows[0] || null
    
    if (project && project.field_config) {
      project.field_config = JSON.parse(project.field_config)
    }
    
    return project
  }

  // 检查项目是否属于用户
  static async belongsToUser(projectId, userId) {
    const [rows] = await pool.execute(
      'SELECT COUNT(*) as count FROM projects WHERE id = ? AND user_id = ?',
      [projectId, userId]
    )
    return rows[0].count > 0
  }

  // 更新项目名称
  static async updateName(id, name) {
    const [result] = await pool.execute(
      `UPDATE projects 
       SET name = ?, last_edit_time = CURRENT_TIMESTAMP 
       WHERE id = ?`,
      [name, id]
    )
    return result.affectedRows > 0
  }

  // 更新项目镜头数量
  static async updateShotCount(id) {
    const [countRows] = await pool.execute(
      'SELECT COUNT(*) as count FROM shots WHERE project_id = ?',
      [id]
    )
    
    await pool.execute(
      `UPDATE projects 
       SET shot_count = ?, last_edit_time = CURRENT_TIMESTAMP 
       WHERE id = ?`,
      [countRows[0].count, id]
    )
  }

  // 删除项目
  static async delete(id) {
    // 先删除相关的镜头
    await MySQLShot.deleteByProjectId(id)
    
    // 再删除项目
    const [result] = await pool.execute('DELETE FROM projects WHERE id = ?', [id])
    return result.affectedRows > 0
  }

  // 获取项目缩略图
  static async getThumbnail(projectId) {
    const [rows] = await pool.execute(
      `SELECT image_url FROM shots 
       WHERE project_id = ? AND image_url IS NOT NULL AND image_url != '' 
       ORDER BY sort_order ASC 
       LIMIT 1`,
      [projectId]
    )
    
    if (rows.length > 0 && rows[0].image_url) {
      return rows[0].image_url
    }
    
    return null
  }

  // 更新项目字段配置
  static async updateFieldConfig(id, fieldConfig) {
    const [result] = await pool.execute(
      `UPDATE projects 
       SET field_config = ?, last_edit_time = CURRENT_TIMESTAMP 
       WHERE id = ?`,
      [JSON.stringify(fieldConfig), id]
    )
    return result.affectedRows > 0
  }
  
  // 获取项目统计信息
  static async getStats(projectId) {
    try {
      // 获取分镜数量
      const [shotCountRows] = await pool.execute(
        'SELECT COUNT(*) as shot_count FROM shots WHERE project_id = ?',
        [projectId]
      )
      
      // 获取有图片的分镜数量
      const [imageCountRows] = await pool.execute(
        'SELECT COUNT(*) as image_count FROM shots WHERE project_id = ? AND image_url IS NOT NULL AND image_url != ""',
        [projectId]
      )
      
      // 获取项目创建时间和最后编辑时间
      const [timeRows] = await pool.execute(
        'SELECT create_time, last_edit_time FROM projects WHERE id = ?',
        [projectId]
      )
      
      const timeInfo = timeRows[0] || {};
      
      return {
        shot_count: shotCountRows[0].shot_count,
        image_count: imageCountRows[0].image_count,
        create_time: timeInfo.create_time,
        last_edit_time: timeInfo.last_edit_time
      }
    } catch (error) {
      console.error('获取项目统计信息失败:', error)
      // 发生错误时返回默认值
      return {
        shot_count: 0,
        image_count: 0
      }
    }
  }

  // 获取项目字段配置
  static async getFieldConfig(id) {
    try {
      const [rows] = await pool.execute(
        'SELECT field_config FROM projects WHERE id = ?',
        [id]
      )
      
      if (rows.length > 0 && rows[0].field_config) {
        return JSON.parse(rows[0].field_config)
      }
      
      // 返回默认配置
      return {
        duration: false,
        shot_type: false,
        dialogue: false,
        sound_effect: false,
        animation: false,
        camera_movement: false,
        scene: false,
        character: false,
        character_state: false,
        narration: false,
        shooting_angle: false
      }
    } catch (error) {
      console.error('获取项目字段配置失败:', error)
      // 发生错误时返回默认配置
      return {
        duration: false,
        shot_type: false,
        dialogue: false,
        sound_effect: false,
        animation: false,
        camera_movement: false,
        scene: false,
        character: false,
        character_state: false,
        narration: false,
        shooting_angle: false
      }
    }
  }
}