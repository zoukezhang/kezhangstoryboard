import express from 'express'
import multer from 'multer'
import path from 'path'
import { body, param } from 'express-validator'
import { fileURLToPath } from 'url'
import { MySQLShot as Shot } from '../models/MySQLShot.js';
import { MySQLProject as Project } from '../models/MySQLProject.js'
import { authenticateToken } from '../middleware/auth.js'
import { validateInput } from '../middleware/validation.js'
import { successResponse, errorResponse, checkOwnership, isValidImageExt } from '../utils/helpers.js'

// 获取当前文件路径
const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

const router = express.Router()

// 配置文件上传
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    // 使用环境变量配置的上传路径，如果未设置则使用默认路径
    const uploadPath = process.env.UPLOAD_PATH || './uploads';
    cb(null, uploadPath)
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9)
    const ext = path.extname(file.originalname)
    cb(null, file.fieldname + '-' + uniqueSuffix + ext)
  }
})

const upload = multer({
  storage: storage,
  limits: {
    fileSize: parseInt(process.env.MAX_FILE_SIZE) || 10 * 1024 * 1024 // 10MB
  },
  fileFilter: (req, file, cb) => {
    if (file.mimetype.startsWith('image/')) {
      cb(null, true)
    } else {
      cb(new Error('只支持上传图片文件'), false)
    }
  }
})

// 添加分镜
router.post('/add', [
  authenticateToken,
  body('project_id').isInt().withMessage('项目ID必须是数字'),
  body('count').optional().isInt({ min: 1, max: 50 }).withMessage('添加数量必须在1-50之间')
], validateInput, async (req, res) => {
  try {
    const { project_id, count = 1 } = req.body
    const userId = req.user.id

    // 检查项目是否属于当前用户
    const belongsToUser = await Project.belongsToUser(project_id, userId)
    if (!belongsToUser) {
      return errorResponse(res, 403, '无权操作此项目')
    }

    // 创建分镜
    const shotIds = await Shot.create(project_id, count)

    // 更新项目镜头数量
    await Project.updateShotCount(project_id)

    successResponse(res, { 
      shotIds,
      count: shotIds.length 
    }, `成功添加${shotIds.length}个镜头`)
  } catch (error) {
    console.error('添加分镜失败:', error)
    errorResponse(res, 500, '添加分镜失败，请重试')
  }
})

// 获取项目的分镜列表
router.get('/list/:projectId', [
  authenticateToken,
  param('projectId').isInt().withMessage('项目ID必须是数字')
], validateInput, async (req, res) => {
  try {
    const projectId = req.params.projectId
    const userId = req.user.id

    // 检查项目是否属于当前用户
    const belongsToUser = await Project.belongsToUser(projectId, userId)
    if (!belongsToUser) {
      return errorResponse(res, 403, '无权访问此项目')
    }

    const shots = await Shot.findByProjectId(projectId)
    
    successResponse(res, shots)
  } catch (error) {
    console.error('获取分镜列表失败:', error)
    errorResponse(res, 500, '获取分镜列表失败')
  }
})

// 更新分镜信息
router.put('/edit/:id', [
  authenticateToken,
  param('id').isInt().withMessage('分镜ID必须是数字'),
  body('tag').optional().isString().isLength({ max: 100 }).withMessage('标签长度不能超过100字符'),
  body('description').optional().isString().isLength({ max: 1000 }).withMessage('描述长度不能超过1000字符'),
  body('duration').optional().isString().isLength({ max: 50 }).withMessage('时长长度不能超过50字符'),
  body('shot_type').optional().isString().isLength({ max: 50 }).withMessage('镜头类型长度不能超过50字符'),
  body('dialogue').optional().isString().isLength({ max: 1000 }).withMessage('台词长度不能超过1000字符'),
  body('sound_effect').optional().isString().isLength({ max: 200 }).withMessage('音效长度不能超过200字符'),
  body('animation').optional().isString().isLength({ max: 200 }).withMessage('动效长度不能超过200字符'),
  body('camera_movement').optional().isString().isLength({ max: 200 }).withMessage('运镜长度不能超过200字符'),
  body('scene').optional().isString().isLength({ max: 100 }).withMessage('场景长度不能超过100字符'),
  body('character').optional().isString().isLength({ max: 100 }).withMessage('角色长度不能超过100字符'),
  body('character_state').optional().isString().isLength({ max: 100 }).withMessage('人物状态长度不能超过100字符'),
  body('narration').optional().isString().isLength({ max: 1000 }).withMessage('旁白长度不能超过1000字符'),
  body('shooting_angle').optional().isString().isLength({ max: 50 }).withMessage('拍摄角度长度不能超过50字符')
], validateInput, async (req, res) => {
  try {
    const shotId = req.params.id
    const userId = req.user.id
    const updateData = req.body

    // 获取分镜所属项目
    const projectId = await Shot.getProjectId(shotId)
    if (!projectId) {
      return errorResponse(res, 404, '分镜不存在')
    }

    // 检查项目是否属于当前用户
    const belongsToUser = await Project.belongsToUser(projectId, userId)
    if (!belongsToUser) {
      return errorResponse(res, 403, '无权操作此分镜')
    }

    // 更新分镜信息
    const updated = await Shot.update(shotId, updateData)
    if (!updated) {
      return errorResponse(res, 404, '分镜不存在或更新失败')
    }

    // 更新项目的最后编辑时间
    await Project.updateShotCount(projectId)

    successResponse(res, null, '分镜信息更新成功')
  } catch (error) {
    console.error('更新分镜失败:', error)
    errorResponse(res, 500, '更新分镜失败，请重试')
  }
})

// 上传分镜图片
router.post('/upload-image', [
  authenticateToken,
  upload.single('image')
], async (req, res) => {
  try {
    if (!req.file) {
      return errorResponse(res, 400, '请选择要上传的图片')
    }

    const shotId = req.body.shotId
    const userId = req.user.id

    if (!shotId) {
      return errorResponse(res, 400, '缺少分镜ID')
    }

    // 验证文件类型
    if (!isValidImageExt(req.file.originalname)) {
      return errorResponse(res, 400, '不支持的图片格式')
    }

    // 获取分镜所属项目
    const projectId = await Shot.getProjectId(shotId)
    if (!projectId) {
      return errorResponse(res, 404, '分镜不存在')
    }

    // 检查项目是否属于当前用户
    const belongsToUser = await Project.belongsToUser(projectId, userId)
    if (!belongsToUser) {
      return errorResponse(res, 403, '无权操作此分镜')
    }

    // 生成图片URL
    const imageUrl = `/uploads/${req.file.filename}`

    // 更新分镜图片
    const updated = await Shot.updateImage(shotId, imageUrl)
    if (!updated) {
      return errorResponse(res, 404, '分镜不存在')
    }

    // 更新项目的最后编辑时间
    await Project.updateShotCount(projectId)

    successResponse(res, { 
      image_url: imageUrl,
      filename: req.file.filename
    }, '图片上传成功')
  } catch (error) {
    console.error('上传图片失败:', error)
    errorResponse(res, 500, '图片上传失败，请重试')
  }
})

// 删除分镜
router.delete('/delete/:id', [
  authenticateToken,
  param('id').isInt().withMessage('分镜ID必须是数字')
], validateInput, async (req, res) => {
  try {
    const shotId = req.params.id
    const userId = req.user.id

    // 获取分镜所属项目
    const projectId = await Shot.getProjectId(shotId)
    if (!projectId) {
      return errorResponse(res, 404, '分镜不存在')
    }

    // 检查项目是否属于当前用户
    const belongsToUser = await Project.belongsToUser(projectId, userId)
    if (!belongsToUser) {
      return errorResponse(res, 403, '无权操作此分镜')
    }

    // 删除分镜
    const deleted = await Shot.delete(shotId)
    if (!deleted) {
      return errorResponse(res, 404, '分镜不存在')
    }

    // 更新项目镜头数量
    await Project.updateShotCount(projectId)

    successResponse(res, null, '分镜删除成功')
  } catch (error) {
    console.error('删除分镜失败:', error)
    errorResponse(res, 500, '删除分镜失败，请重试')
  }
})

// 更新分镜排序
router.put('/sort', [
  authenticateToken,
  body('sortedIds').isArray().withMessage('排序数据必须是数组'),
  body('sortedIds.*').isInt().withMessage('分镜ID必须是数字')
], validateInput, async (req, res) => {
  try {
    const { sortedIds } = req.body
    const userId = req.user.id

    if (sortedIds.length === 0) {
      return errorResponse(res, 400, '排序数据不能为空')
    }

    // 获取第一个分镜所属项目（假设所有分镜属于同一项目）
    const projectId = await Shot.getProjectId(sortedIds[0])
    if (!projectId) {
      return errorResponse(res, 404, '分镜不存在')
    }

    // 检查项目是否属于当前用户
    const belongsToUser = await Project.belongsToUser(projectId, userId)
    if (!belongsToUser) {
      return errorResponse(res, 403, '无权操作此项目')
    }

    // 验证所有分镜都属于该项目
    for (const shotId of sortedIds) {
      const belongs = await Shot.belongsToProject(shotId, projectId)
      if (!belongs) {
        return errorResponse(res, 400, '存在不属于该项目的分镜')
      }
    }

    // 更新排序
    await Shot.updateSort(sortedIds)

    // 更新项目的最后编辑时间
    await Project.updateShotCount(projectId)

    successResponse(res, null, '分镜排序更新成功')
  } catch (error) {
    console.error('更新分镜排序失败:', error)
    errorResponse(res, 500, '排序更新失败，请重试')
  }
})

export default router