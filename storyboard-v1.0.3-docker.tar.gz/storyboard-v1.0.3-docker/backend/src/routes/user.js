import express from 'express'
import { body } from 'express-validator'
import { MySQLUser as User } from '../models/MySQLUser.js'
import { authenticateToken, generateToken } from '../middleware/auth.js'
import { validateInput } from '../middleware/validation.js'
import { hashPassword, verifyPassword, successResponse, errorResponse } from '../utils/helpers.js'

const router = express.Router()

// 用户注册
router.post('/register', [
  body('username')
    .trim()
    .isLength({ min: 2, max: 50 })
    .withMessage('用户名长度必须在2-50个字符之间'),
  body('email')
    .isEmail()
    .normalizeEmail()
    .withMessage('请输入有效的邮箱地址'),
  body('password')
    .isLength({ min: 6 })
    .withMessage('密码长度至少为6位')
], validateInput, async (req, res) => {
  console.log('收到注册请求:', req.body)
  try {
    const { username, email, password } = req.body
    console.log('开始处理注册逻辑...')

    // 检查邮箱是否已存在
    console.log('检查邮箱是否存在:', email)
    const emailExists = await User.emailExists(email)
    if (emailExists) {
      console.log('邮箱已存在')
      return errorResponse(res, 400, '邮箱已被注册')
    }

    // 加密密码
    console.log('开始加密密码...')
    const hashedPassword = await hashPassword(password)
    console.log('密码加密完成')

    // 创建用户
    console.log('开始创建用户...')
    const userId = await User.create({
      username,
      email,
      password: hashedPassword
    })
    console.log('用户创建完成, ID:', userId)

    successResponse(res, { userId }, '注册成功')
  } catch (error) {
    console.error('用户注册失败:', error)
    errorResponse(res, 500, '注册失败，请重试')
  }
})

// 用户登录
router.post('/login', [
  body('email')
    .isEmail()
    .normalizeEmail()
    .withMessage('请输入有效的邮箱地址'),
  body('password')
    .notEmpty()
    .withMessage('密码不能为空')
], validateInput, async (req, res) => {
  try {
    const { email, password } = req.body

    // 查找用户
    const user = await User.findByEmail(email)
    if (!user) {
      return errorResponse(res, 401, '该邮箱尚未注册，请先注册账号')
    }

    // 验证密码
    const isValidPassword = await verifyPassword(password, user.password)
    if (!isValidPassword) {
      return errorResponse(res, 401, '密码错误，请检查后重试')
    }

    // 生成JWT token
    const token = generateToken({
      id: user.id,
      email: user.email,
      username: user.username
    })

    // 返回用户信息和token
    successResponse(res, {
      token,
      user: {
        id: user.id,
        username: user.username,
        email: user.email
      }
    }, '登录成功')
  } catch (error) {
    console.error('用户登录失败:', error)
    errorResponse(res, 500, '登录失败，请重试')
  }
})

// 获取当前用户信息
router.get('/current', authenticateToken, async (req, res) => {
  try {
    const user = await User.findById(req.user.id)
    if (!user) {
      return errorResponse(res, 404, '用户不存在')
    }

    // 获取用户统计信息
    const stats = await User.getStats(user.id)

    successResponse(res, {
      ...user,
      ...stats
    })
  } catch (error) {
    console.error('获取用户信息失败:', error)
    errorResponse(res, 500, '获取用户信息失败')
  }
})

// 修改密码
router.put('/password', [
  authenticateToken,
  body('currentPassword')
    .notEmpty()
    .withMessage('请输入当前密码'),
  body('newPassword')
    .isLength({ min: 6 })
    .withMessage('新密码长度至少为6位')
], validateInput, async (req, res) => {
  try {
    const { currentPassword, newPassword } = req.body
    const userId = req.user.id

    // 获取用户信息
    const user = await User.findByEmail(req.user.email)
    if (!user) {
      return errorResponse(res, 404, '用户不存在')
    }

    // 验证当前密码
    const isValidPassword = await verifyPassword(currentPassword, user.password)
    if (!isValidPassword) {
      return errorResponse(res, 401, '当前密码错误')
    }

    // 加密新密码
    const hashedNewPassword = await hashPassword(newPassword)

    // 更新密码
    const updated = await User.updatePassword(userId, hashedNewPassword)
    if (!updated) {
      return errorResponse(res, 500, '密码更新失败')
    }

    successResponse(res, null, '密码修改成功')
  } catch (error) {
    console.error('修改密码失败:', error)
    errorResponse(res, 500, '密码修改失败，请重试')
  }
})

// 退出登录（客户端处理，这里只做记录）
router.post('/logout', authenticateToken, (req, res) => {
  // 实际的退出登录由客户端删除token处理
  // 这里可以记录日志或进行其他清理工作
  successResponse(res, null, '退出登录成功')
})

export default router