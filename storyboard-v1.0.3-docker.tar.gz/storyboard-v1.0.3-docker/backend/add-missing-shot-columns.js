import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';

// 设置正确的路径
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

dotenv.config({ path: path.join(__dirname, '.env') });

import { pool } from './src/config/database.js';

/**
 * 为shots表添加缺失的字段
 */
const addMissingShotColumns = async () => {
  try {
    console.log('=== 开始为shots表添加缺失字段 ===');
    
    // 定义需要添加的字段
    const missingColumns = [
      { name: 'duration', type: 'INT DEFAULT 0' },
      { name: 'shot_type', type: 'VARCHAR(100) DEFAULT ""' },
      { name: 'dialogue', type: 'TEXT' },
      { name: 'sound_effect', type: 'TEXT' },
      { name: 'animation', type: 'TEXT' },
      { name: 'camera_movement', type: 'TEXT' },
      { name: 'scene', type: 'VARCHAR(255) DEFAULT ""' },
      { name: '`character`', type: 'VARCHAR(255) DEFAULT ""' },
      { name: 'character_state', type: 'TEXT' },
      { name: 'narration', type: 'TEXT' },
      { name: 'shooting_angle', type: 'TEXT' }
    ];
    
    // 逐个添加缺失的字段
    for (const column of missingColumns) {
      // 检查列是否已存在
      const [existingColumns] = await pool.execute(
        `SHOW COLUMNS FROM shots LIKE '${column.name.replace(/`/g, '')}'`
      );
      
      if (existingColumns.length > 0) {
        console.log(`✅ ${column.name}列已存在，无需添加`);
      } else {
        // 添加新列
        await pool.execute(
          `ALTER TABLE shots ADD COLUMN ${column.name} ${column.type}`
        );
        console.log(`✅ 成功为shots表添加${column.name}列`);
      }
    }
    
  } catch (error) {
    console.error('❌ 添加缺失字段失败:', error);
  } finally {
    await pool.end();
    console.log('=== 数据库连接已关闭 ===');
  }
};

addMissingShotColumns();