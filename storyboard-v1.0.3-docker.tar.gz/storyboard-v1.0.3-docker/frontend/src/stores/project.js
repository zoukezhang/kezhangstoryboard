import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import api from '@/utils/api'

export const useProjectStore = defineStore('project', () => {
  const projects = ref([])
  const currentProject = ref(null)
  const currentFieldConfig = ref({
    duration: false,
    shot_type: false,
    dialogue: false,
    sound_effect: false,
    animation: false,
    camera_movement: false,
    scene: false,
    character: false,
    character_state: false,
    narration: false,
    shooting_angle: false
  })
  const loading = ref(false)

  // 获取项目列表
  const fetchProjects = async () => {
    loading.value = true
    try {
      const response = await api.get('/project/list')
      projects.value = response.data.data || []
      return { success: true }
    } catch (error) {
      console.error('获取项目列表失败:', error)
      return { 
        success: false, 
        message: error.response?.data?.message || '获取项目列表失败' 
      }
    } finally {
      loading.value = false
    }
  }

  // 创建项目
  const createProject = async (name, fieldConfig = null) => {
    try {
      const payload = { name }
      if (fieldConfig) {
        payload.fieldConfig = fieldConfig
      }
      
      const response = await api.post('/project/create', payload)
      await fetchProjects() // 重新获取项目列表
      return { 
        success: true, 
        data: response.data.data,
        message: '项目创建成功' 
      }
    } catch (error) {
      console.error('创建项目失败:', error)
      return { 
        success: false, 
        message: error.response?.data?.message || '创建项目失败' 
      }
    }
  }

  // 获取单个项目信息
  const fetchProject = async (projectId) => {
    loading.value = true
    try {
      const response = await api.get(`/project/${projectId}`)
      currentProject.value = response.data.data
      
      // 更新当前字段配置
      if (response.data.data.field_config) {
        currentFieldConfig.value = response.data.data.field_config
      }
      
      return { success: true, data: response.data.data }
    } catch (error) {
      console.error('获取项目信息失败:', error)
      return { 
        success: false, 
        message: error.response?.data?.message || '获取项目信息失败' 
      }
    } finally {
      loading.value = false
    }
  }

  // 更新项目名称
  const updateProject = async (projectId, name) => {
    try {
      await api.put(`/project/update/${projectId}`, { name })
      await fetchProjects() // 重新获取项目列表
      return { success: true, message: '项目更新成功' }
    } catch (error) {
      console.error('更新项目失败:', error)
      return { 
        success: false, 
        message: error.response?.data?.message || '更新项目失败' 
      }
    }
  }

  // 删除项目
  const deleteProject = async (projectId) => {
    try {
      await api.delete(`/project/delete/${projectId}`)
      await fetchProjects() // 重新获取项目列表
      return { success: true, message: '项目删除成功' }
    } catch (error) {
      console.error('删除项目失败:', error)
      return { 
        success: false, 
        message: error.response?.data?.message || '删除项目失败' 
      }
    }
  }

  // 更新项目字段配置
  const updateFieldConfig = async (projectId, fieldConfig) => {
    try {
      console.log('Store接收的配置:', fieldConfig)
      
      // 对配置对象进行深拷贝，确保对象引用发生变化
      const configToSave = JSON.parse(JSON.stringify(fieldConfig))
      
      await api.put(`/project/field-config/${projectId}`, { fieldConfig: configToSave })
      
      // 创建一个新对象而不是直接赋值，确保Vue能够检测到变化
      currentFieldConfig.value = { ...configToSave }
      console.log('Store更新后的配置:', currentFieldConfig.value)
      
      return { success: true, message: '字段配置更新成功' }
    } catch (error) {
      console.error('更新字段配置失败:', error)
      return { 
        success: false, 
        message: error.response?.data?.message || '更新字段配置失败' 
      }
    }
  }

  // 获取项目字段配置
  const fetchFieldConfig = async (projectId) => {
    try {
      const response = await api.get(`/project/field-config/${projectId}`)
      currentFieldConfig.value = response.data.data
      return { success: true, data: response.data.data }
    } catch (error) {
      console.error('获取字段配置失败:', error)
      return { 
        success: false, 
        message: error.response?.data?.message || '获取字段配置失败' 
      }
    }
  }

  // 计算属性
  const projectCount = computed(() => projects.value.length)
  
  return {
    projects,
    currentProject,
    currentFieldConfig,
    loading,
    projectCount,
    fetchProjects,
    createProject,
    fetchProject,
    updateProject,
    deleteProject,
    updateFieldConfig,
    fetchFieldConfig
  }
})