<template>
  <div class="login-container">
    <div class="login-box">
      <div class="login-header">
        <h1>分镜故事板</h1>
        <p>登录您的账户</p>
      </div>
      
      <el-form ref="loginFormRef" :model="loginForm" :rules="rules" class="login-form">
        <el-form-item prop="email">
          <el-input
            v-model="loginForm.email"
            type="email"
            placeholder="请输入邮箱"
            size="large"
            :prefix-icon="User"
          />
        </el-form-item>
        
        <el-form-item prop="password">
          <el-input
            v-model="loginForm.password"
            type="password"
            placeholder="请输入密码"
            size="large"
            show-password
            :prefix-icon="Lock"
            @keyup.enter="handleLogin"
          />
        </el-form-item>
        
        <el-form-item>
          <el-button 
            type="primary" 
            size="large" 
            :loading="loading"
            @click="handleLogin"
            class="login-btn"
          >
            登录
          </el-button>
        </el-form-item>
      </el-form>
      
      <div class="register-link">
        还没有账户？
        <router-link to="/register" class="register-btn">立即注册</router-link>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive } from 'vue'
import { useRouter } from 'vue-router'
import { User, Lock } from '@element-plus/icons-vue'
import { ElMessage } from 'element-plus'
import { useUserStore } from '@/stores/user'

const router = useRouter()
const userStore = useUserStore()

const loginFormRef = ref()
const loading = ref(false)

const loginForm = reactive({
  email: '',
  password: ''
})

const rules = {
  email: [
    { required: true, message: '请输入邮箱', trigger: 'blur' },
    { type: 'email', message: '请输入正确的邮箱格式', trigger: 'blur' }
  ],
  password: [
    { required: true, message: '请输入密码', trigger: 'blur' },
    { min: 6, message: '密码长度至少6位', trigger: 'blur' }
  ]
}

const handleLogin = async () => {
  if (!loginFormRef.value) return
  
  await loginFormRef.value.validate(async (valid) => {
    if (valid) {
      loading.value = true
      try {
        console.log('开始登录操作...', loginForm.email)
        const result = await userStore.login(loginForm)
        console.log('登录结果:', result)
        
        if (result.success) {
          ElMessage.success('登录成功')
          router.push('/projects')
        } else {
          console.log('登录失败，显示错误信息:', result.message)
          
          // 显示具体的错误信息
          const errorMessage = result.message || '登录失败，请检查邮箱和密码'
          
          // 如果是未注册用户，显示更长时间的提示和引导
          if (errorMessage.includes('尚未注册')) {
            ElMessage({
              type: 'warning',
              duration: 6000,
              message: errorMessage + '，点击下方“立即注册”按钮创建账户',
              showClose: true
            })
          } else {
            ElMessage.error(errorMessage)
          }
        }
      } catch (error) {
        console.error('登录异常:', error)
        ElMessage.error('登录失败，请检查网络连接并重试')
      } finally {
        loading.value = false
      }
    } else {
      console.log('表单验证失败')
    }
  })
}
</script>

<style scoped>
.login-container {
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 100vh;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
}

.login-box {
  width: 400px;
  padding: 40px;
  background: white;
  border-radius: 10px;
  box-shadow: 0 15px 35px rgba(0, 0, 0, 0.1);
}

.login-header {
  text-align: center;
  margin-bottom: 30px;
}

.login-header h1 {
  color: #333;
  margin-bottom: 10px;
  font-size: 28px;
}

.login-header p {
  color: #666;
  font-size: 14px;
}

.login-form {
  margin-bottom: 20px;
}

.login-btn {
  width: 100%;
}

.register-link {
  text-align: center;
  color: #666;
  font-size: 14px;
  padding: 15px 0;
  border-top: 1px solid #f0f0f0;
  margin-top: 20px;
}

.register-btn {
  color: #409eff;
  text-decoration: none;
  font-weight: 500;
  padding: 5px 10px;
  border-radius: 4px;
  transition: all 0.3s ease;
  margin-left: 5px;
}

.register-btn:hover {
  background-color: #f0f9ff;
  text-decoration: none;
}
</style>