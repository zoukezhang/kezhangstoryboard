#!/bin/bash
echo "📋 查看服务日志..."
docker-compose logs -f
