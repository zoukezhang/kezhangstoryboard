# Docker 部署指南

## 版本信息
- **应用版本**: v1.0.0
- **Docker配置版本**: v1.0.0
- **更新日期**: 2025年8月24日

## 系统要求

### 最低配置
- **操作系统**: Linux, macOS, Windows (支持Docker)
- **内存**: 2GB RAM
- **存储**: 5GB 可用空间
- **Docker**: 20.10.0+
- **Docker Compose**: 2.0.0+

### 推荐配置
- **内存**: 4GB RAM 或更多
- **存储**: 10GB 可用空间
- **网络**: 稳定的网络连接

## 快速部署

### 1. 准备工作

```bash
# 检查Docker版本
docker --version
docker-compose --version

# 确保端口可用
sudo lsof -i :80 -i :3002
```

### 2. 部署应用

```bash
# 方法1: 使用部署脚本（推荐）
./deploy.sh

# 方法2: 手动部署
docker-compose up --build -d
```

### 3. 验证部署

```bash
# 检查服务状态
docker-compose ps

# 查看日志
docker-compose logs -f

# 测试应用
curl http://localhost/api/health
```

## 端口配置

| 服务 | 内部端口 | 外部端口 | 说明 |
|------|----------|----------|------|
| 前端 | 80 | 80 | Web界面访问 |
| 后端 | 3002 | 3002 | API服务 |

## 访问地址

- **前端应用**: http://localhost
- **后端API**: http://localhost:3002
- **健康检查**: http://localhost:3002/api/health
- **API文档**: http://localhost:3002/api/health

## 常用命令

### 服务管理

```bash
# 启动服务
docker-compose up -d

# 停止服务
docker-compose down

# 重启服务
docker-compose restart

# 查看状态
docker-compose ps

# 查看日志
docker-compose logs -f [service_name]
```

### 数据管理

```bash
# 备份数据卷
docker run --rm -v storyboard_backend_data:/data -v $(pwd):/backup alpine tar czf /backup/backup.tar.gz /data

# 恢复数据卷
docker run --rm -v storyboard_backend_data:/data -v $(pwd):/backup alpine tar xzf /backup/backup.tar.gz -C /

# 查看数据卷
docker volume ls
docker volume inspect storyboard_backend_uploads
```

### 镜像管理

```bash
# 重新构建镜像
docker-compose build --no-cache

# 清理无用镜像
docker system prune -f

# 查看镜像大小
docker images
```

## 环境变量配置

创建 `.env` 文件来自定义配置：

```env
# 安全配置
JWT_SECRET=your-super-secret-jwt-key-change-in-production

# 数据库配置（可选MySQL）
# DB_HOST=mysql
# DB_PORT=3306
# DB_USER=storyboard
# DB_PASSWORD=your-secure-password
# DB_DATABASE=storyboard

# 文件上传配置
MAX_FILE_SIZE=10485760

# 环境配置
NODE_ENV=production
```

## 故障排除

### 常见问题

1. **端口被占用**
   ```bash
   sudo lsof -i :80 -i :3002
   sudo killall -9 nginx  # 如果80端口被nginx占用
   ```

2. **权限问题**
   ```bash
   sudo chown -R $USER:$USER ./backend/uploads
   chmod 755 ./backend/uploads
   ```

3. **内存不足**
   ```bash
   # 增加交换空间
   sudo fallocate -l 2G /swapfile
   sudo chmod 600 /swapfile
   sudo mkswap /swapfile
   sudo swapon /swapfile
   ```

4. **网络连接问题**
   ```bash
   # 检查网络
   docker network ls
   docker network inspect storyboard_storyboard-network
   ```

### 日志分析

```bash
# 查看容器状态
docker-compose ps

# 查看详细日志
docker-compose logs --tail=100 backend
docker-compose logs --tail=100 frontend

# 实时日志监控
docker-compose logs -f
```

### 性能监控

```bash
# 查看资源使用
docker stats

# 查看容器信息
docker-compose exec backend df -h
docker-compose exec backend free -m
```

## 更新部署

### 更新应用

```bash
# 1. 停止现有服务
docker-compose down

# 2. 更新代码
git pull origin main

# 3. 重新构建并启动
docker-compose up --build -d

# 4. 验证更新
curl http://localhost/api/health
```

### 数据迁移

如需迁移到其他服务器：

```bash
# 1. 备份数据
./backup.sh

# 2. 传输文件到新服务器
rsync -avz ./backup.tar.gz user@newserver:/path/to/app/

# 3. 在新服务器上恢复
./restore.sh backup.tar.gz
./deploy.sh
```

## 安全配置

### 生产环境建议

1. **修改默认密钥**
   ```bash
   # 生成强密钥
   openssl rand -base64 32
   ```

2. **启用HTTPS**（可选）
   ```bash
   # 使用Let's Encrypt
   certbot --nginx -d your-domain.com
   ```

3. **防火墙配置**
   ```bash
   # 只开放必要端口
   sudo ufw allow 80
   sudo ufw allow 443
   sudo ufw enable
   ```

4. **定期备份**
   ```bash
   # 设置定时备份
   crontab -e
   # 添加: 0 2 * * * /path/to/backup.sh
   ```

## 支持与联系

如遇到部署问题，请：

1. 查看日志文件
2. 检查系统资源
3. 参考故障排除章节
4. 联系技术支持: 5349589@qq.com

---

**分镜故事板 v1.0.0** - Docker部署版本  
© 2025 科长分镜故事板