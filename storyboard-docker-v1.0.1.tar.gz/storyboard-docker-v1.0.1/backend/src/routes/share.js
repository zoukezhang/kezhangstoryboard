import express from 'express'
import { param } from 'express-validator'
import { SQLiteShare as Share } from '../models/SQLiteShare.js'
import { SQLiteProject as Project } from '../models/SQLiteProject.js'
import { SQLiteShot as Shot } from '../models/SQLiteShot.js'
import { authenticateToken } from '../middleware/auth.js'
import { validateInput } from '../middleware/validation.js'
import { successResponse, errorResponse, generateRandomString } from '../utils/helpers.js'

const router = express.Router()

// 创建分享链接
router.post('/create/:projectId', [
  authenticateToken,
  param('projectId').isInt().withMessage('项目ID必须是数字')
], validateInput, async (req, res) => {
  try {
    const projectId = req.params.projectId
    const userId = req.user.id

    // 检查项目是否属于当前用户
    const belongsToUser = await Project.belongsToUser(projectId, userId)
    if (!belongsToUser) {
      return errorResponse(res, 403, '无权分享此项目')
    }

    // 生成分享token
    const token = generateRandomString(32)
    
    // 设置过期时间（7天后）
    const expireTime = new Date()
    expireTime.setDate(expireTime.getDate() + 7)
    const expireTimeStr = expireTime.toISOString()

    // 创建分享记录
    const shareId = await Share.create(projectId, token, expireTimeStr)

    successResponse(res, {
      token,
      expire_time: expireTimeStr,
      share_url: `${req.protocol}://${req.get('host')}/share/${token}`
    }, '分享链接创建成功')
  } catch (error) {
    console.error('创建分享链接失败:', error)
    errorResponse(res, 500, '创建分享链接失败，请重试')
  }
})

// 通过分享token访问项目
router.get('/view/:token', [
  param('token').isLength({ min: 32, max: 64 }).withMessage('无效的分享链接')
], validateInput, async (req, res) => {
  try {
    const token = req.params.token

    // 查找分享记录
    const share = await Share.findByToken(token)
    if (!share) {
      return errorResponse(res, 404, '分享链接不存在或已过期')
    }

    // 获取项目和分镜数据
    const [project, shots] = await Promise.all([
      Project.findById(share.project_id),
      Shot.findByProjectId(share.project_id)
    ])

    if (!project) {
      return errorResponse(res, 404, '项目不存在')
    }

    // 返回公开的项目数据（不包含敏感信息）
    successResponse(res, {
      project: {
        id: project.id,
        name: project.name,
        shot_count: project.shot_count,
        create_time: project.create_time
      },
      shots: shots.map((shot, index) => ({
        id: shot.id,
        number: index + 1,
        tag: shot.tag,
        description: shot.description,
        image_url: shot.image_url ? `${req.protocol}://${req.get('host')}${shot.image_url}` : null
      })),
      share_info: {
        expire_time: share.expire_time
      }
    })
  } catch (error) {
    console.error('访问分享项目失败:', error)
    errorResponse(res, 500, '访问分享项目失败')
  }
})

// 获取项目的分享记录
router.get('/list/:projectId', [
  authenticateToken,
  param('projectId').isInt().withMessage('项目ID必须是数字')
], validateInput, async (req, res) => {
  try {
    const projectId = req.params.projectId
    const userId = req.user.id

    // 检查项目是否属于当前用户
    const belongsToUser = await Project.belongsToUser(projectId, userId)
    if (!belongsToUser) {
      return errorResponse(res, 403, '无权查看此项目的分享记录')
    }

    const shares = await Share.findByProjectId(projectId)
    
    successResponse(res, shares)
  } catch (error) {
    console.error('获取分享记录失败:', error)
    errorResponse(res, 500, '获取分享记录失败')
  }
})

// 清理过期的分享记录（定时任务接口）
router.delete('/cleanup', async (req, res) => {
  try {
    const deletedCount = await Share.deleteExpired()
    
    successResponse(res, { 
      deleted_count: deletedCount 
    }, `清理了${deletedCount}条过期分享记录`)
  } catch (error) {
    console.error('清理过期分享记录失败:', error)
    errorResponse(res, 500, '清理失败')
  }
})

export default router